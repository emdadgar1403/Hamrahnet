HamrahNet v0.5.17 — Screen Wake Discovery Test (experimental)

Changes:
- Adds PairingManager.refreshNsdDiscovery(), which refreshes NSD/mDNS only and leaves pairing/signaling ServerSockets intact.
- Registers a dynamic ACTION_SCREEN_ON receiver while the foreground network service is active.
- On screen wake, refreshes NSD after a short delay.
- The stable v0.5.14 project was not edited.

Important limitations:
- This is an experimental diagnostic patch, not proof that all Android OEM power-management behaviors are fixed.
- It does not forcibly keep Wi-Fi enabled if the device/router/OEM power policy disconnects Wi-Fi.
- Test with two devices, screen off for several minutes, then wake without opening the app. Confirm discovery returns automatically.
- Check Logcat tags HamrahNetService and HamrahNetNSD.
