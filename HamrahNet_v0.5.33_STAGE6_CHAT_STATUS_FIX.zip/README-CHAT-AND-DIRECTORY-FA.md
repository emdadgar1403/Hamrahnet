برای توضیحات تغییرات شناسه ارتباطی و زیرساخت ذخیره‌سازی چت، فایل `COMMUNICATION-ID-AND-CHAT-FOUNDATION-FA.md` را ببینید.
