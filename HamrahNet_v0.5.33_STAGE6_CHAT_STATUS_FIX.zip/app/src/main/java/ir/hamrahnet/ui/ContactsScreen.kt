package ir.hamrahnet.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import ir.hamrahnet.data.local.TrustedPeerEntity
import ir.hamrahnet.data.local.ChatMessageDao
import ir.hamrahnet.data.local.ChatMessageEntity
import kotlinx.coroutines.launch
import ir.hamrahnet.discovery.DiscoveredDevice
import ir.hamrahnet.security.ChatMessageCrypto


private data class ContactMeta(val nickname: String, val notes: String, val photoUri: String, val favorite: Boolean)
private fun readMeta(context: Context, fingerprint: String): ContactMeta {
    val p = context.getSharedPreferences("hamrahnet_contact_meta", Context.MODE_PRIVATE)
    val key = fingerprint.take(32)
    return ContactMeta(p.getString("${key}_nickname", "") ?: "", p.getString("${key}_notes", "") ?: "", p.getString("${key}_photo", "") ?: "", p.getBoolean("${key}_favorite", false))
}
private fun saveMeta(context: Context, fingerprint: String, meta: ContactMeta) {
    val p = context.getSharedPreferences("hamrahnet_contact_meta", Context.MODE_PRIVATE)
    val key = fingerprint.take(32)
    p.edit().putString("${key}_nickname", meta.nickname).putString("${key}_notes", meta.notes).putString("${key}_photo", meta.photoUri).putBoolean("${key}_favorite", meta.favorite).apply()
}
private fun clearMeta(context: Context, fingerprint: String) {
    val p = context.getSharedPreferences("hamrahnet_contact_meta", Context.MODE_PRIVATE)
    val key = fingerprint.take(32)
    p.edit().remove("${key}_nickname").remove("${key}_notes").remove("${key}_photo").remove("${key}_favorite").apply()
}

@Composable
internal fun ContactsScreen(
    peers: List<TrustedPeerEntity>, devices: List<DiscoveredDevice>, fileSelected: Boolean,
    selectedFingerprint: String? = null,
    openChatDirectly: Boolean = false,
    onBack: () -> Unit, onCall: (DiscoveredDevice) -> Unit, onVideoCall: (DiscoveredDevice) -> Unit,
    onTestSecureChannel: (DiscoveredDevice) -> Unit, onChooseFile: (DiscoveredDevice?) -> Unit,
    onSendFile: (DiscoveredDevice) -> Unit, onDelete: (String) -> Unit,
    chatDao: ChatMessageDao, onSendChat: (String, DiscoveredDevice?, String) -> Unit,
    onMarkConversationRead: (String, DiscoveredDevice?) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<TrustedPeerEntity?>(null) }
    var deleting by remember { mutableStateOf<TrustedPeerEntity?>(null) }
    var details by remember { mutableStateOf<TrustedPeerEntity?>(null) }
    var chatPeer by remember { mutableStateOf<TrustedPeerEntity?>(null) }
    LaunchedEffect(selectedFingerprint, peers, openChatDirectly) {
        if (selectedFingerprint != null) {
            val selected = peers.firstOrNull { it.fingerprint.equals(selectedFingerprint, true) }
            if (openChatDirectly && selected != null) {
                details = null
                chatPeer = selected
            } else {
                details = selected
            }
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مخاطبان", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("بازگشت") }
        }
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("جست‌وجوی نام، شناسه یا توضیحات") })
        if (peers.isEmpty()) Text("هنوز مخاطب مورد اعتمادی ثبت نشده است. ابتدا از صفحه اصلی دستگاه را جفت‌سازی کنید.")
        val visible = peers.map { it to readMeta(context, it.fingerprint) }.filter { (peer, meta) ->
            query.isBlank() || peer.displayName.contains(query, true) || peer.username.contains(query, true) || peer.fingerprint.contains(query, true) || meta.nickname.contains(query, true) || meta.notes.contains(query, true)
        }.sortedWith(compareByDescending<Pair<TrustedPeerEntity, ContactMeta>> { it.second.favorite }.thenBy { (it.second.nickname.ifBlank { it.first.displayName }).lowercase() })
        if (refresh < 0) Text("")
        visible.forEach { (peer, meta) ->
            val online = devices.firstOrNull { it.advertisedFingerprint.equals(peer.fingerprint, true) || it.username.equals(peer.username, true) }
            Card(onClick = { details = peer }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (meta.photoUri.isNotBlank()) ContactPhoto(meta.photoUri)
                        Column(Modifier.weight(1f)) {
                            Text((if (meta.favorite) "★ " else "") + meta.nickname.ifBlank { peer.displayName }, style = MaterialTheme.typography.titleMedium)
                            Text("@${peer.username}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text(if (online != null) "آنلاین" else "آفلاین", color = if (online != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (meta.notes.isNotBlank()) Text(meta.notes, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { deleting = peer }, modifier = Modifier.weight(1f)) { Text("حذف مخاطب") }
                        OutlinedButton(onClick = { editing = peer }, modifier = Modifier.weight(1f)) { Text("ویرایش") }
                        OutlinedButton(onClick = { if (meta.favorite) saveMeta(context, peer.fingerprint, meta.copy(favorite = false)) else saveMeta(context, peer.fingerprint, meta.copy(favorite = true)); refresh++ }, modifier = Modifier.weight(1f)) { Text(if (meta.favorite) "حذف از منتخب‌ها" else "★ منتخب") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { online?.let(onCall) }, enabled = online != null, modifier = Modifier.weight(1f)) { Text("تماس") }
                        Button(onClick = { online?.let(onSendFile) }, enabled = online != null && fileSelected, modifier = Modifier.weight(1f)) { Text("ارسال فایل") }
                    }
                }
            }
        }
    }
    editing?.let { peer ->
        var nickname by remember(peer.fingerprint) { mutableStateOf(readMeta(context, peer.fingerprint).nickname) }
        var notes by remember(peer.fingerprint) { mutableStateOf(readMeta(context, peer.fingerprint).notes) }
        var photo by remember(peer.fingerprint) { mutableStateOf(readMeta(context, peer.fingerprint).photoUri) }
        var favorite by remember(peer.fingerprint) { mutableStateOf(readMeta(context, peer.fingerprint).favorite) }
        val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) { try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; photo = uri.toString() }
        }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text("ویرایش مخاطب") }, text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("نام اصلی: ${peer.displayName}", style = MaterialTheme.typography.bodyMedium)
                Text("شناسه: @${peer.username}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(nickname, { nickname = it }, label = { Text("نام مستعار / نام نمایشی محلی") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, minLines = 2)
                OutlinedButton(onClick = { photoPicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (photo.isBlank()) "انتخاب تصویر مخاطب" else "تغییر تصویر مخاطب") }
                if (photo.isNotBlank()) { Text("تصویر انتخاب شده است", style = MaterialTheme.typography.bodySmall); TextButton(onClick = { photo = "" }) { Text("حذف تصویر") } }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("مخاطب منتخب", modifier = Modifier.weight(1f)); Switch(favorite, { favorite = it }) }
                Text("اثر انگشت: ${peer.fingerprint}", style = MaterialTheme.typography.labelSmall)
            }
        }, confirmButton = { Button(onClick = { saveMeta(context, peer.fingerprint, ContactMeta(nickname.trim(), notes.trim(), photo, favorite)); refresh++; editing = null }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = { editing = null }) { Text("انصراف") } })
    }
    deleting?.let { peer ->
        AlertDialog(onDismissRequest = { deleting = null }, title = { Text("حذف مخاطب؟") }, text = { Text("مخاطب از فهرست اعتماد این گوشی حذف می‌شود. برای ارتباط امن دوباره باید جفت‌سازی و تأیید کد انجام شود. این کار از گوشی مقابل چیزی حذف نمی‌کند.") }, confirmButton = { Button(onClick = { clearMeta(context, peer.fingerprint); onDelete(peer.fingerprint); deleting = null; details = null; refresh++ }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { deleting = null }) { Text("انصراف") } })
    }
    chatPeer?.let { peer ->
        val messages by chatDao.observeConversation(peer.fingerprint.lowercase()).collectAsState(initial = emptyList())
        var draft by remember(peer.fingerprint) { mutableStateOf("") }
        val online = devices.firstOrNull { it.advertisedFingerprint.equals(peer.fingerprint, true) || it.username.equals(peer.username, true) }
        LaunchedEffect(peer.fingerprint, online?.advertisedFingerprint, messages.map { it.messageId to it.status }) {
            onMarkConversationRead(peer.fingerprint, online)
        }
        Dialog(onDismissRequest = { chatPeer = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFFF1F6FF),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).imePadding().padding(bottom = 38.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("←", color = Color(0xFF1769E8), style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.clickable { chatPeer = null }.padding(end = 14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("همراه‌نت", color = Color(0xFF12315A), style = MaterialTheme.typography.titleMedium)
                            Text(if (online != null) "● آنلاین · ${peer.displayName}" else "○ آفلاین · ${peer.displayName}",
                                color = if (online != null) Color(0xFF159B70) else Color(0xFF718096), style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { online?.let(onCall) }, enabled = online != null) { Text("☎") }
                        TextButton(onClick = { online?.let(onVideoCall) }, enabled = online != null) { Text("▣") }
                    }
                    Column(
                        Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (messages.isEmpty()) {
                            Text("هنوز پیامی در این گفت‌وگو وجود ندارد.", color = Color(0xFF718096), style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 24.dp))
                        }
                        messages.forEach { item ->
                            val outgoing = item.direction == "OUTGOING"
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = if (outgoing) Alignment.End else Alignment.Start) {
                                Surface(
                                    color = if (outgoing) Color(0xFF1769E8) else Color.White,
                                    shape = RoundedCornerShape(20.dp),
                                    shadowElevation = 3.dp,
                                    modifier = Modifier.widthIn(max = 300.dp)
                                ) {
                                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(runCatching { ChatMessageCrypto.decrypt(item.body) }.getOrElse { "پیام رمزگذاری‌شده؛ بازیابی متن ناموفق بود." },
                                            color = if (outgoing) Color.White else Color(0xFF12315A), style = MaterialTheme.typography.bodyMedium)
                                        Text("${java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(item.createdAtEpochMs))}  ·  ${if (outgoing) when (item.status) { "DELIVERED" -> "تحویل شد ✓✓"; "READ" -> "خوانده شد ✓✓"; "SENDING" -> "در حال ارسال…"; "QUEUED" -> "در صف ارسال"; "FAILED" -> "ارسال ناموفق"; else -> "ارسال شد" } else if (item.status == "READ_PENDING" || item.status == "READ") "خوانده شد" else "دریافت شد"}",
                                            color = if (outgoing) Color(0xFFDCE9FF) else Color(0xFF718096), style = MaterialTheme.typography.labelSmall)
                                        if (item.status == "FAILED" && !item.error.isNullOrBlank()) Text(item.error, color = Color(0xFFB3261E), style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                        if (online == null) Text("مخاطب آفلاین است؛ پیام در صف امن ذخیره و پس از بازگشت ارتباط به‌طور خودکار ارسال می‌شود.",
                            color = Color(0xFF536B89), style = MaterialTheme.typography.bodySmall)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(onClick = { onChooseFile(online) }, enabled = online != null) { Text("📎", style = MaterialTheme.typography.titleLarge) }
                        OutlinedTextField(
                            value = draft, onValueChange = { if (it.length <= 4000) draft = it },
                            modifier = Modifier.weight(1f), placeholder = { Text("پیام…") },
                            maxLines = 4, shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedContainerColor = Color(0xFFE7EFF8), focusedContainerColor = Color(0xFFE7EFF8),
                                unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color(0xFF1769E8)
                            )
                        )
                        Button(onClick = { val text = draft.trim(); if (text.isNotEmpty()) { onSendChat(peer.fingerprint, online, text); draft = "" } },
                            enabled = draft.isNotBlank(), shape = RoundedCornerShape(50)) { Text("➤") }
                    }
                }
            }
        }
    }
    details?.let { peer ->
        val meta = readMeta(context, peer.fingerprint)
        val online = devices.firstOrNull { it.advertisedFingerprint.equals(peer.fingerprint, true) || it.username.equals(peer.username, true) }
        AlertDialog(onDismissRequest = { details = null }, title = { Text(meta.nickname.ifBlank { peer.displayName }) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("نام حساب: ${peer.displayName}")
                Text("شناسه: @${peer.username}")
                Text("وضعیت: ${if (online != null) "آنلاین" else "آفلاین"}")
                if (meta.notes.isNotBlank()) Text("توضیحات: ${meta.notes}")
                if (meta.photoUri.isNotBlank()) ContactPhoto(meta.photoUri)
                Text("اثر انگشت رمزنگاری‌شده:", style = MaterialTheme.typography.labelMedium)
                Text(peer.fingerprint, style = MaterialTheme.typography.bodySmall)
            }
        }, confirmButton = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { chatPeer = peer; details = null }, modifier = Modifier.fillMaxWidth()) { Text("گفت‌وگو / چت") }
                OutlinedButton(onClick = { online?.let(onTestSecureChannel) }, enabled = online != null, modifier = Modifier.fillMaxWidth()) { Text("آزمایش کانال رمزگذاری‌شده") }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { online?.let { onCall(it); details = null } }, enabled = online != null, modifier = Modifier.weight(1f)) { Text("تماس صوتی") }
                    Button(onClick = { online?.let { onVideoCall(it); details = null } }, enabled = online != null, modifier = Modifier.weight(1f)) { Text("تماس تصویری") }
                }
                OutlinedButton(onClick = { onChooseFile(online) }, modifier = Modifier.fillMaxWidth()) { Text(if (fileSelected) "انتخاب فایل دیگر" else "انتخاب فایل برای ارسال") }
                Button(onClick = { online?.let { if (fileSelected) onSendFile(it); details = null } }, enabled = online != null && fileSelected, modifier = Modifier.fillMaxWidth()) { Text("ارسال فایل") }
                TextButton(onClick = { details = null; editing = peer }, modifier = Modifier.fillMaxWidth()) { Text("ویرایش مخاطب") }
            }
        }, dismissButton = { TextButton(onClick = { details = null }) { Text("بستن") } })
    }
}

@Composable
private fun ContactPhoto(uriString: String) {
    val context = LocalContext.current
    val bitmap = remember(uriString) {
        try {
            val uri = Uri.parse(uriString)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 192)
            val opts = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtMost(16) }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts)?.asImageBitmap() }
        } catch (_: Exception) { null }
    }
    if (bitmap != null) Image(bitmap = bitmap, contentDescription = "تصویر مخاطب", modifier = Modifier.size(54.dp))
    else Text("👤", modifier = Modifier.padding(end = 8.dp))
}
