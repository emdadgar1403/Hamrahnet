package ir.hamrahnet.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// HamrahNet visual system: deep navy + restrained turquoise.
private val Turquoise = Color(0xFF25C7C3)
private val TurquoiseDark = Color(0xFF087E8B)
private val DesignBlue = Color(0xFF1769E8)

private val LightColors = lightColorScheme(
    primary = DesignBlue, onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE9FF), onPrimaryContainer = Color(0xFF102F62),
    secondary = Color(0xFF5479B8), onSecondary = Color.White,
    tertiary = Color(0xFF269B78), onTertiary = Color.White,
    background = Color(0xFFF1F6FF), onBackground = Color(0xFF172A46),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF172A46),
    surfaceVariant = Color(0xFFE7EFFB), onSurfaceVariant = Color(0xFF64748B),
    surfaceContainer = Color(0xFFF8FAFF), outline = Color(0xFFD8E2F1)
)

private val DarkColors = darkColorScheme(
    primary = Turquoise, onPrimary = Color(0xFF062326),
    primaryContainer = Color(0xFF12474B), onPrimaryContainer = Color(0xFFD7FAF7),
    secondary = Color(0xFF8DD9D5), onSecondary = Color(0xFF10383A),
    tertiary = Color(0xFF72D5AE), onTertiary = Color(0xFF073B2A),
    background = Color(0xFF07151D), onBackground = Color(0xFFEAF4F5),
    surface = Color(0xFF0D2028), onSurface = Color(0xFFEAF4F5),
    surfaceVariant = Color(0xFF1B3038), onSurfaceVariant = Color(0xFFB1C5C9),
    surfaceContainer = Color(0xFF142A33), outline = Color(0xFF29434B)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(9.dp), small = RoundedCornerShape(13.dp),
    medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

private val AppTypography = Typography().run {
    copy(
        headlineLarge = headlineLarge.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold),
        headlineMedium = headlineMedium.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold),
        titleLarge = titleLarge.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold),
        titleMedium = titleMedium.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold),
        titleSmall = titleSmall.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium),
        bodyLarge = bodyLarge.copy(fontFamily = FontFamily.SansSerif),
        bodyMedium = bodyMedium.copy(fontFamily = FontFamily.SansSerif),
        bodySmall = bodySmall.copy(fontFamily = FontFamily.SansSerif),
        labelLarge = labelLarge.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium),
        labelMedium = labelMedium.copy(fontFamily = FontFamily.SansSerif),
        labelSmall = labelSmall.copy(fontFamily = FontFamily.SansSerif)
    )
}

@Composable
fun HamrahNetTheme(darkTheme: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography, shapes = AppShapes, content = content
    )
}
