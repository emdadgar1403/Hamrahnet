package ir.hamrahnet.ui

import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.content.ContentResolver
import androidx.documentfile.provider.DocumentFile
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.InetSocketAddress
import java.net.Socket
import android.provider.OpenableColumns
import android.os.Build
import android.provider.Settings
import android.media.RingtoneManager
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.RadioButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.webrtc.SurfaceViewRenderer
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import ir.hamrahnet.data.local.LocalAccountEntity
import ir.hamrahnet.data.local.ChatMessageDao
import ir.hamrahnet.data.repository.AccountRepository
import ir.hamrahnet.data.repository.CreateAccountResult
import ir.hamrahnet.discovery.DiscoveredDevice
import ir.hamrahnet.pairing.PairingDirection
import ir.hamrahnet.pairing.PairingManager
import ir.hamrahnet.service.HamrahNetService
import ir.hamrahnet.call.LocalVoiceCallEngine
import ir.hamrahnet.pairing.PairingPrompt
import ir.hamrahnet.pairing.IncomingFileOffer
import ir.hamrahnet.pairing.FileTransferEngine
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun HamrahNetApp(repository: AccountRepository, pairingManager: PairingManager, themeMode: String, onThemeModeChange: (String) -> Unit) {
    val account by repository.account.collectAsState(initial = null)
    var initialized by remember { mutableStateOf(false) }
    LaunchedEffect(account) { initialized = true }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!initialized) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("همراه‌نت")
                Text("در حال آماده‌سازی…")
            }
        } else if (account == null) {
            CreateAccountScreen(repository)
        } else {
            HomeScreen(account = account!!, pairingManager = pairingManager, themeMode = themeMode, onThemeModeChange = onThemeModeChange)
        }
    }
}

@Composable
private fun CreateAccountScreen(repository: AccountRepository) {
    var displayName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("همراه‌نت", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("ارتباط آسان، امن و آفلاین", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(4.dp))
        Text("تماس و انتقال فایل در شبکه محلی؛ بدون نیاز به اینترنت", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(24.dp))
        Text("ساخت حساب محلی", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = displayName, onValueChange = { displayName = it; message = null }, label = { Text("نام نمایشی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = username, onValueChange = { username = it; message = null }, label = { Text("شناسه انگلیسی (۳ تا ۳۲ نویسه)") }, supportingText = { Text("حروف کوچک انگلیسی، عدد، نقطه، خط تیره و زیرخط") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = password, onValueChange = { password = it; message = null }, label = { Text("گذرواژه (حداقل ۸ نویسه)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = confirmPassword, onValueChange = { confirmPassword = it; message = null }, label = { Text("تکرار گذرواژه") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (password != confirmPassword) {
                    message = "گذرواژه و تکرار آن یکسان نیستند."
                } else {
                    busy = true
                    val secret = password.toCharArray()
                    scope.launch {
                        message = when (repository.createAccount(displayName, username, secret)) {
                            CreateAccountResult.Created -> "حساب محلی ساخته شد."
                            CreateAccountResult.UsernameAlreadyExists -> "این شناسه قبلاً ثبت شده است."
                            CreateAccountResult.InvalidInput -> "اطلاعات واردشده معتبر نیست."
                            is CreateAccountResult.Failure -> "ساخت حساب ناموفق بود؛ دوباره تلاش کنید."
                        }
                        password = ""
                        confirmPassword = ""
                        busy = false
                    }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "در حال ساخت…" else "ایجاد حساب محلی") }
        message?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(16.dp))
        Text("حساب در همین دستگاه ذخیره می‌شود. برای جفت‌سازی، نسخه همراه‌نت باید روی گوشی مقابل نیز اجرا باشد.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun HomeScreen(account: LocalAccountEntity, pairingManager: PairingManager, themeMode: String, onThemeModeChange: (String) -> Unit) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val devices by pairingManager.devices.collectAsState()
    val pendingPrompt by pairingManager.pendingPrompt.collectAsState()
    val status by pairingManager.status.collectAsState()
    val trustedPeers by pairingManager.trustedPeers.collectAsState(initial = emptyList())
    val voiceCall by pairingManager.voiceCall.collectAsState()
    val incomingFileOffer by pairingManager.incomingFileOffer.collectAsState()
    val fileTransferStatus by pairingManager.fileTransferStatus.collectAsState()
    val context = LocalContext.current
    var showAddPeerDialog by remember { mutableStateOf(false) }
    var showInviteQrDialog by remember { mutableStateOf(false) }
    val qrScanLauncher = rememberLauncherForActivityResult(ScanContract()) { result ->
        result.contents?.let { pairingManager.pairFromInvite(it) }
    }
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    var showFileTransfer by remember { mutableStateOf(false) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedFileSize by remember { mutableStateOf(0L) }
    var pendingChatFileTarget by remember { mutableStateOf<DiscoveredDevice?>(null) }
    var filePickerMessage by remember { mutableStateOf<String?>(null) }
    val filePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                var name = "hamrahnet-file"
                var size = -1L
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                        if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                    }
                }
                if (size < 0) {
                    context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { size = it.length }
                }
                // Some document providers incorrectly report zero for small, non-empty files.
                // Only in that ambiguous case, measure the actual readable stream; never trust
                // the metadata's zero value when the content says otherwise.
                if (size == 0L) {
                    var measured = 0L
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            measured += count
                            if (measured > FileTransferEngine.MAX_FILE_SIZE) break
                        }
                    }
                    size = measured
                }
                if (size !in 0..FileTransferEngine.MAX_FILE_SIZE) {
                    filePickerMessage = "اندازه فایل قابل تشخیص نیست یا از ۲ گیگابایت بیشتر است."
                } else {
                    selectedFileUri = uri
                    selectedFileName = name
                    selectedFileSize = size
                    filePickerMessage = null
                    val chatTarget = pendingChatFileTarget
                    pendingChatFileTarget = null
                    if (chatTarget != null) {
                        pairingManager.sendFileToPeer(chatTarget, uri, name, size)
                    } else {
                        showFileTransfer = true
                    }
                }
            } catch (e: Exception) {
                filePickerMessage = "خواندن اطلاعات فایل ناموفق بود."
            }
        }
    }
    var notificationsAllowed by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var fullScreenAllowed by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 34 ||
                context.getSystemService(NotificationManager::class.java)?.canUseFullScreenIntent() == true
        )
    }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> notificationsAllowed = granted }
    var showSettings by remember { mutableStateOf(false) }
    var showNetworkDiagnostics by remember { mutableStateOf(false) }
    var showContacts by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var selectedContactFingerprint by remember { mutableStateOf<String?>(null) }
    var preferredCallVideo by remember { mutableStateOf(false) }
    var showExitConfirmation by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }
    var openChatDirectly by remember { mutableStateOf(false) }
    BackHandler(enabled = true) {
        when {
            voiceCall.peer != null -> Unit // هنگام تماس، بازگشت نباید صفحه تماس را ببندد.
            showNetworkDiagnostics -> { showNetworkDiagnostics = false; selectedTab = 0 }
            showSettings -> { showSettings = false; selectedTab = 0 }
            showContacts -> { showContacts = false; selectedContactFingerprint = null; openChatDirectly = false; selectedTab = 0 }
            showFileTransfer -> { showFileTransfer = false; selectedTab = 0 }
            showHistory -> { showHistory = false; selectedTab = 0 }
            else -> Unit // در صفحهٔ خانه، خروج فقط از دکمهٔ «خروج» انجام می‌شود.
        }
    }
    val prefs = remember { context.getSharedPreferences("hamrahnet_preferences", Context.MODE_PRIVATE) }
    var historyRefresh by remember { mutableStateOf(0) }
    var activeHistoryStart by remember { mutableStateOf<Long?>(null) }
    var activeHistoryPeer by remember { mutableStateOf("") }
    var activeHistoryVideo by remember { mutableStateOf(false) }
    LaunchedEffect(voiceCall.peer?.username, voiceCall.isVideo, voiceCall.incoming) {
        val peer = voiceCall.peer
        if (peer != null && voiceCall.incoming == null) {
            if (activeHistoryStart == null) {
                activeHistoryStart = System.currentTimeMillis()
                activeHistoryPeer = peer.displayName.ifBlank { peer.username }
                activeHistoryVideo = voiceCall.isVideo
            }
        } else {
            val start = activeHistoryStart
            if (start != null) {
                val end = System.currentTimeMillis()
                val old = prefs.getString("call_history_v1", "").orEmpty()
                val row = listOf(end.toString(), activeHistoryPeer, if (activeHistoryVideo) "تصویری" else "صوتی", ((end-start)/1000).coerceAtLeast(0).toString()).joinToString("¦")
                prefs.edit().putString("call_history_v1", (row + "\n" + old).trim()).apply()
                historyRefresh++
                activeHistoryStart = null
                activeHistoryPeer = ""
            }
        }
    }
    var ringtoneTitle by remember { mutableStateOf(prefs.getString("ringtone_title", "زنگ پیش‌فرض دستگاه") ?: "زنگ پیش‌فرض دستگاه") }
    var receivedFolder by remember { mutableStateOf(prefs.getString("received_folder_label", "پوشه پیش‌فرض برنامه") ?: "پوشه پیش‌فرض برنامه") }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            val title = if (uri == null) "بدون صدا" else RingtoneManager.getRingtone(context, uri)?.getTitle(context) ?: "زنگ انتخاب‌شده"
            ringtoneTitle = title
            prefs.edit().putString("ringtone_title", title).putString("ringtone_uri", uri?.toString().orEmpty()).apply()
        }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            try { context.contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { }
            receivedFolder = uri.lastPathSegment?.substringAfterLast(':')?.ifBlank { "پوشه انتخاب‌شده" } ?: "پوشه انتخاب‌شده"
            prefs.edit().putString("received_folder_label", receivedFolder).putString("received_folder_uri", uri.toString()).apply()
        }
    }
    var pendingCallDevice by remember { mutableStateOf<DiscoveredDevice?>(null) }
    var pendingIncomingAnswer by remember { mutableStateOf(false) }
    var pendingVideoDevice by remember { mutableStateOf<DiscoveredDevice?>(null) }
    var pendingVideoAnswer by remember { mutableStateOf(false) }
    var permissionMessage by remember { mutableStateOf<String?>(null) }
    val microphonePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            pendingCallDevice?.let { pairingManager.startOutgoingVoiceCall(it) }
            if (pendingIncomingAnswer) pairingManager.acceptIncomingVoiceCall()
            permissionMessage = null
        } else {
            permissionMessage = "بدون مجوز میکروفون امکان برقراری تماس صوتی وجود ندارد."
        }
        pendingCallDevice = null
        pendingIncomingAnswer = false
    }

    val mediaPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val allowed = grants[Manifest.permission.RECORD_AUDIO] == true && grants[Manifest.permission.CAMERA] == true
        if (allowed) {
            pendingVideoDevice?.let { pairingManager.startOutgoingVideoCall(it) }
            if (pendingVideoAnswer) pairingManager.acceptIncomingVideoCall()
            permissionMessage = null
        } else {
            permissionMessage = "برای تماس تصویری، مجوز دوربین و میکروفون لازم است."
        }
        pendingVideoDevice = null
        pendingVideoAnswer = false
    }

    fun requestOutgoingVideoCall(device: DiscoveredDevice) {
        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val camera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (mic && camera) pairingManager.startOutgoingVideoCall(device) else {
            pendingVideoDevice = device
            mediaPermissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA))
        }
    }

    fun requestIncomingVideoAnswer() {
        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val camera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (mic && camera) pairingManager.acceptIncomingVideoCall() else {
            pendingVideoAnswer = true
            mediaPermissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA))
        }
    }

    fun requestOutgoingCall(device: DiscoveredDevice) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pairingManager.startOutgoingVoiceCall(device)
        } else {
            pendingCallDevice = device
            microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun requestIncomingAnswer() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pairingManager.acceptIncomingVoiceCall()
        } else {
            pendingIncomingAnswer = true
            microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    DisposableEffect(lifecycleOwner, account.id) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> HamrahNetService.start(context, account.displayName, account.username)
                else -> Unit
            }
            if (event == Lifecycle.Event.ON_START || event == Lifecycle.Event.ON_RESUME) {
                notificationsAllowed = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                fullScreenAllowed = Build.VERSION.SDK_INT < 34 ||
                    context.getSystemService(NotificationManager::class.java)?.canUseFullScreenIntent() == true
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            HamrahNetService.start(context, account.displayName, account.username)
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            // The foreground service owns discovery; disposing the UI must not stop networking.
        }
    }

    // Three primary destinations: Home (conversations), Calls, Settings.
    // Contacts remain reachable from Home without consuming a bottom-nav slot.
    fun navigateToTab(tab: Int) {
        selectedTab = tab.coerceIn(0, 2)
        showContacts = false
        showHistory = selectedTab == 1
        showFileTransfer = false
        showSettings = selectedTab == 2
        showNetworkDiagnostics = false
        selectedContactFingerprint = null
        openChatDirectly = false
    }

    if (voiceCall.peer != null && voiceCall.incoming == null) {
        ActiveCallScreen(
            pairingManager = pairingManager,
            callState = voiceCall,
            onHangUp = { pairingManager.endVoiceCall() }
        )
    } else if (showNetworkDiagnostics) {
        NetworkDiagnosticsScreen(
            pairingManager = pairingManager,
            trustedPeers = trustedPeers,
            onBack = { navigateToTab(0) }
        )
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            androidx.compose.foundation.layout.Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when {
                    showSettings -> SettingsScreen(
                        account = account,
                        themeMode = themeMode,
                        onThemeModeChange = onThemeModeChange,
                        ringtoneTitle = ringtoneTitle,
                        receivedFolder = receivedFolder,
                        onChooseRingtone = {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "انتخاب زنگ تماس")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, prefs.getString("ringtone_uri", null)?.let(Uri::parse))
                            }
                            ringtonePicker.launch(intent)
                        },
                        onChooseFolder = { folderPicker.launch(null) },
                        onOpenNetworkDiagnostics = { selectedTab = 2; showSettings = false; showNetworkDiagnostics = true },
                        onBack = { navigateToTab(0) }
                    )
                    showContacts -> ContactsScreen(
                        peers = trustedPeers,
                        devices = devices,
                        fileSelected = selectedFileUri != null,
                        selectedFingerprint = selectedContactFingerprint,
                        openChatDirectly = openChatDirectly,
                        onBack = { navigateToTab(0) },
                        onCall = {
                            if (preferredCallVideo) requestOutgoingVideoCall(it) else requestOutgoingCall(it)
                            preferredCallVideo = false
                        },
                        onVideoCall = { requestOutgoingVideoCall(it); preferredCallVideo = false },
                        onTestSecureChannel = { pairingManager.testSecureChannel(it) },
                        onChooseFile = { device -> pendingChatFileTarget = device; filePickerLauncher.launch(arrayOf("*/*")) },
                        onSendFile = { device -> selectedFileUri?.let { pairingManager.sendFileToPeer(device, it, selectedFileName, selectedFileSize) } },
                        onDelete = { pairingManager.forgetTrustedPeer(it) },
                        chatDao = (context.applicationContext as ir.hamrahnet.HamrahNetApplication).database.chatMessageDao(),
                        onSendChat = { fingerprint, device, body -> pairingManager.sendChatMessage(device, fingerprint, body) },
                        onMarkConversationRead = { fingerprint, device -> pairingManager.markConversationRead(fingerprint, device) }
                    )
                    showHistory -> CallHistoryScreen(
                        context = context,
                        refreshKey = historyRefresh,
                        onBack = { navigateToTab(0) },
                        onClear = { prefs.edit().remove("call_history_v1").apply(); historyRefresh++ }
                    )
                    showFileTransfer -> FileTransferScreen(
                        selectedFileName = selectedFileName,
                        selectedFileSize = selectedFileSize,
                        fileSelected = selectedFileUri != null,
                        status = fileTransferStatus,
                        message = filePickerMessage,
                        devices = devices,
                        onChooseFile = { filePickerLauncher.launch(arrayOf("*/*")) },
                        onSend = { device -> selectedFileUri?.let { pairingManager.sendFileToPeer(device, it, selectedFileName, selectedFileSize) } },
                        onBack = { navigateToTab(0) }
                    )
                    else -> ChatListScreen(
                        peers = trustedPeers,
                        devices = devices,
                        chatDao = (context.applicationContext as ir.hamrahnet.HamrahNetApplication).database.chatMessageDao(),
                        networkStatus = status,
                        onRefresh = { pairingManager.refreshDiscovery() },
                        onOpenConversation = { fingerprint ->
                            selectedContactFingerprint = fingerprint
                            openChatDirectly = true
                            selectedTab = 0
                            showContacts = true
                            showHistory = false
                            showFileTransfer = false
                            showSettings = false
                        },
                        onOpenContacts = { selectedTab = 0; showContacts = true; showHistory = false; showSettings = false; showNetworkDiagnostics = false },
                        onAddPeer = { showAddPeerDialog = true },
                        onInvite = { showInviteQrDialog = true },
                        onExit = { showExitConfirmation = true }
                    )
                }
            }
            HamrahNetBottomBar(selectedTab = selectedTab, onSelect = { navigateToTab(it) })
        }
    }

    if (showExitConfirmation) {
        AlertDialog(
            onDismissRequest = { showExitConfirmation = false },
            title = { Text("خروج از همراه‌نت؟") },
            text = { Text("برنامه بسته می‌شود. اگر تماس فعالی دارید، ابتدا آن را پایان دهید.") },
            confirmButton = { TextButton(onClick = { showExitConfirmation = false; context.findActivity()?.finish() }) { Text("خروج از برنامه") } },
            dismissButton = { TextButton(onClick = { showExitConfirmation = false }) { Text("انصراف") } }
        )
    }

    voiceCall.incoming?.let { incoming ->
        AlertDialog(
            onDismissRequest = { pairingManager.rejectIncomingVoiceCall() },
            title = { Text(if (incoming.isVideo) "تماس تصویری ورودی" else "تماس صوتی ورودی") },
            text = { Text("${incoming.device.displayName} (@${incoming.device.username}) با شما تماس می‌گیرد.${if (incoming.isVideo) " برای پاسخ، مجوز دوربین و میکروفون لازم است." else " برای پاسخ، مجوز میکروفون لازم است."}") },
            confirmButton = {
                Button(onClick = { if (incoming.isVideo) requestIncomingVideoAnswer() else requestIncomingAnswer() }) { Text("پاسخ‌دادن") }
            },
            dismissButton = {
                TextButton(onClick = { pairingManager.rejectIncomingVoiceCall() }) { Text("رد تماس") }
            }
        )
    }
    incomingFileOffer?.let { offer ->
        IncomingFileOfferDialog(
            offer = offer,
            onAccept = { pairingManager.respondToFileOffer(offer.id, true) },
            onReject = { pairingManager.respondToFileOffer(offer.id, false) }
        )
    }
    pendingPrompt?.let { prompt -> PairingApprovalDialog(prompt) { accepted -> pairingManager.respondToPairing(prompt.id, accepted) } }
    if (showAddPeerDialog) {
        AddPeerDialog(
            onDismiss = { showAddPeerDialog = false },
            onPairByIp = { host -> pairingManager.pairByAddress(host); showAddPeerDialog = false },
            onPairByNodeId = { nodeId ->
                val resolvedIp = resolveExternalNodeIp(context, nodeId)
                if (resolvedIp == null) {
                    android.widget.Toast.makeText(context, "شناسه پیدا نشد یا فایل node_directory.enc قابل رمزگشایی نیست. پوشهٔ .Hamrahnet را انتخاب و فایل را بررسی کنید.", android.widget.Toast.LENGTH_LONG).show()
                } else {
                    pairingManager.pairByAddress(resolvedIp)
                }
                showAddPeerDialog = false
            },
            onScanQr = {
                showAddPeerDialog = false
                qrScanLauncher.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE).setPrompt("کد QR دعوت همراه‌نت را اسکن کنید").setBeepEnabled(false).setOrientationLocked(false))
            },
            onShowQr = { showAddPeerDialog = false; showInviteQrDialog = true }
        )
    }
    if (showInviteQrDialog) PairInviteQrDialog(pairingManager) { showInviteQrDialog = false }
}


@Composable
private fun HamrahNetBottomBar(selectedTab: Int, onSelect: (Int) -> Unit) {
    val destinations = listOf(
        Triple("خانه", "⌂", 0),
        Triple("تماس‌ها", "☎", 1),
        Triple("تنظیمات", "⚙", 2)
    )
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            destinations.forEach { (label, symbol, index) ->
                val isSelected = selectedTab == index
                Column(
                    modifier = Modifier.weight(1f).clickable { onSelect(index) }.padding(vertical = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = symbol,
                        style = MaterialTheme.typography.titleLarge,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/** Resolves a numeric node ID from the user-authorized external CSV directory. */
private fun resolveExternalNodeIp(context: Context, nodeId: String): String? {
    if (!nodeId.matches(Regex("[0-9]{1,12}"))) return null
    return try {
        val prefs = context.getSharedPreferences("hamrahnet_node_directory", Context.MODE_PRIVATE)
        val treeUriText = prefs.getString("directory_tree_uri", null) ?: return null
        val treeUri = Uri.parse(treeUriText)
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        val encrypted = root.findFile("node_directory.enc") ?: return null
        if (!encrypted.isFile || !encrypted.canRead()) return null
        val payload = context.contentResolver.openInputStream(encrypted.uri)?.use { it.readBytes() } ?: return null
        val plaintext = decryptNodeDirectory(payload)
        plaintext.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .mapNotNull { line ->
                val parts = line.split(',', limit = 2).map { it.trim() }
                if (parts.size == 2 && parts[0] == nodeId) parts[1] else null
            }
            .firstOrNull { ip -> isValidNodeIp(ip) }
    } catch (_: Exception) {
        null
    }
}


/** HNENC1 file: UTF-8 prefix + 12-byte GCM nonce + authenticated ciphertext. */
private fun decryptNodeDirectory(fileBytes: ByteArray): String {
    val magic = "HNENC1:".toByteArray(Charsets.US_ASCII)
    require(fileBytes.size > magic.size + 12 + 16) { "Encrypted directory is too short" }
    require(fileBytes.copyOfRange(0, magic.size).contentEquals(magic)) { "Unsupported directory format" }
    val packed = android.util.Base64.decode(fileBytes.copyOfRange(magic.size, fileBytes.size), android.util.Base64.DEFAULT)
    require(packed.size > 12 + 16) { "Invalid encrypted payload" }
    val nonce = packed.copyOfRange(0, 12)
    val ciphertext = packed.copyOfRange(12, packed.size)
    val keyBytes = byteArrayOf(0x4a,0x6d,0x31,0x72,0x38,0x51,0x70,0x33,0x58,0x76,0x36,0x4b,0x32,0x6e,0x39,0x54,0x35,0x62,0x37,0x57,0x63,0x31,0x4a,0x38,0x71,0x34,0x5a,0x70,0x36,0x48,0x73,0x32)
    val key = javax.crypto.spec.SecretKeySpec(keyBytes, "AES")
    val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, javax.crypto.spec.GCMParameterSpec(128, nonce))
    cipher.updateAAD("HamrahNet-NodeDirectory-v1".toByteArray(Charsets.UTF_8))
    return cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
}

private fun isValidNodeIp(ip: String): Boolean {
    val validIpv4 = ip.matches(Regex("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) &&
        ip.split('.').all { it.toIntOrNull() in 0..255 }
    val validIpv6 = ip.contains(':') && ip.matches(Regex("[0-9a-fA-F:.]+"))
    return validIpv4 || validIpv6
}

@Composable
private fun AddPeerDialog(
    onDismiss: () -> Unit,
    onPairByIp: (String) -> Unit,
    onPairByNodeId: (String) -> Unit,
    onScanQr: () -> Unit,
    onShowQr: () -> Unit
) {
    val context = LocalContext.current
    var host by remember { mutableStateOf("") }
    var nodeId by remember { mutableStateOf("") }
    var directoryLabel by remember {
        mutableStateOf(context.getSharedPreferences("hamrahnet_node_directory", Context.MODE_PRIVATE)
            .getString("directory_tree_uri", null)?.let { "پوشهٔ جدول انتخاب شده است" } ?: "پوشهٔ جدول هنوز انتخاب نشده است")
    }
    val directoryPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.getSharedPreferences("hamrahnet_node_directory", Context.MODE_PRIVATE)
                    .edit().putString("directory_tree_uri", uri.toString()).apply()
                directoryLabel = "پوشهٔ جدول انتخاب شد؛ فایل node_directory.csv باید داخل آن باشد"
                android.widget.Toast.makeText(context, "دسترسی پوشه ذخیره شد.", android.widget.Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                directoryLabel = "ذخیرهٔ دسترسی پوشه ناموفق بود؛ دوباره انتخاب کنید"
            }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("جفت‌سازی با IP، شناسه یا QR") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .imePadding()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("IP شبکهٔ VPN یا LAN گوشی مقابل را وارد کنید. برای این مسیر مستقیم، هر دو گوشی باید نسخهٔ کاری سازگار HamrahNet را اجرا کنند؛ درگاه‌ها به‌صورت خودکار تنظیم می‌شوند.")
                Text("جدول خارجی: $directoryLabel", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { directoryPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    Text("انتخاب پوشهٔ .Hamrahnet")
                }
                Text("داخل پوشهٔ انتخاب‌شده، فایل node_directory.csv با قالب شناسه,IP قرار دهید.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = nodeId,
                    onValueChange = { nodeId = it.filter(Char::isDigit).take(12) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("شناسهٔ عددی نود") },
                    placeholder = { Text("مثلاً 1001") }
                )
                Button(
                    onClick = { onPairByNodeId(nodeId.trim()) },
                    enabled = nodeId.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("یافتن IP از جدول خارجی و جفت‌سازی") }
                androidx.compose.material3.HorizontalDivider()
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("یا آدرس IP دستگاه مقابل") },
                    placeholder = { Text("مثلاً 10.8.0.12") }
                )
                OutlinedButton(onClick = { if (host.isNotBlank()) onPairByIp(host.trim()) }, enabled = host.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("جفت‌سازی با IP مستقیم") }
                OutlinedButton(onClick = onScanQr, modifier = Modifier.fillMaxWidth()) { Text("اسکن QR دعوت") }
                TextButton(onClick = onShowQr, modifier = Modifier.fillMaxWidth()) { Text("نمایش QR دستگاه خودم") }
            }
        },
        confirmButton = { Button(onClick = { onPairByIp(host.trim()) }, enabled = host.isNotBlank()) { Text("درخواست جفت‌سازی") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun PairInviteQrDialog(pairingManager: PairingManager, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val addresses = remember { pairingManager.localAddressCandidates() }
    var selectedAddress by remember { mutableStateOf(addresses.firstOrNull().orEmpty()) }
    val inviteUri = remember(selectedAddress) { pairingManager.createInviteUri(selectedAddress).orEmpty() }
    val qrBitmap = remember(inviteUri) { createQrBitmap(inviteUri) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("دعوت امن با QR") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("آدرسی را انتخاب کنید که گوشی مقابل از طریق VPN یا شبکهٔ محلی به آن دسترسی دارد. برای VPN شرکت، معمولاً آدرس رابط VPN را انتخاب کنید.", style = MaterialTheme.typography.bodySmall)
                if (addresses.isEmpty()) {
                    Text("آدرس فعالی پیدا نشد. ابتدا VPN یا Wi-Fi را وصل و دوباره این پنجره را باز کنید.", color = MaterialTheme.colorScheme.error)
                } else {
                    addresses.forEach { address ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            RadioButton(selected = selectedAddress == address, onClick = { selectedAddress = address })
                            Text(address, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    if (qrBitmap != null) Image(qrBitmap.asImageBitmap(), contentDescription = "کد QR دعوت همراه‌نت", modifier = Modifier.size(220.dp))
                    Text("این QR شامل IP و اثرانگشت کلید عمومی دستگاه است؛ تأیید کد شش‌رقمی روی هر دو گوشی همچنان الزامی است.", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, inviteUri)
                        }
                        context.startActivity(Intent.createChooser(share, "اشتراک‌گذاری دعوت همراه‌نت"))
                    }, enabled = inviteUri.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("اشتراک‌گذاری لینک دعوت") }
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("بستن") } }
    )
}

private fun createQrBitmap(value: String): Bitmap? {
    if (value.isBlank()) return null
    return try {
        val size = 512
        val matrix = QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, size, size)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) pixels[y * size + x] = if (matrix[x, y]) AndroidColor.BLACK else AndroidColor.WHITE
        }
        Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, size, 0, 0, size, size)
        }
    } catch (_: Exception) { null }
}

private fun prefsSetting(context: Context, key: String): Boolean = context.getSharedPreferences("hamrahnet_preferences", Context.MODE_PRIVATE).getBoolean(key, true)
private fun savePrefsSetting(context: Context, key: String, value: Boolean) { context.getSharedPreferences("hamrahnet_preferences", Context.MODE_PRIVATE).edit().putBoolean(key, value).apply() }

@Composable
private fun CallHistoryScreen(context: Context, refreshKey: Int, onBack: () -> Unit, onClear: () -> Unit) {
    val prefs = remember(context) { context.getSharedPreferences("hamrahnet_preferences", Context.MODE_PRIVATE) }
    val rows = remember(refreshKey) { prefs.getString("call_history_v1", "").orEmpty().lines().filter { it.isNotBlank() }.mapNotNull { line ->
        val parts = line.split("¦")
        if (parts.size == 4) parts else null
    } }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تاریخچه تماس‌ها", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("بازگشت") }
        }
        if (rows.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("◷", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                    Text("هنوز تماسی ثبت نشده است", style = MaterialTheme.typography.titleMedium)
                    Text("تماس‌های تکمیل‌شده از این پس در این صفحه ذخیره می‌شوند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            rows.forEach { parts ->
                val time = parts[0].toLongOrNull() ?: 0L
                val dateText = java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(time))
                val duration = parts[3].toLongOrNull() ?: 0L
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.primaryContainer) { Text(if (parts[2] == "تصویری") "▣" else "☎", modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onPrimaryContainer) }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(parts[1], style = MaterialTheme.typography.titleMedium)
                            Text("تماس ${parts[2]} · $dateText", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("مدت: ${duration / 60} دقیقه و ${duration % 60} ثانیه", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            TextButton(onClick = onClear, modifier = Modifier.align(Alignment.End)) { Text("پاک‌کردن تاریخچه") }
        }
    }
}

@Composable
private fun QuickActionCard(title: String, subtitle: String, symbol: String, modifier: Modifier = Modifier, accent: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier.height(112.dp),
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.12f))
    ) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.Start
        ) {
            Text(symbol, style = MaterialTheme.typography.headlineMedium, color = accent)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    account: LocalAccountEntity,
    themeMode: String,
    onThemeModeChange: (String) -> Unit,
    ringtoneTitle: String,
    receivedFolder: String,
    onChooseRingtone: () -> Unit,
    onChooseFolder: () -> Unit,
    onOpenNetworkDiagnostics: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("تنظیمات", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                Text("تنظیمات برنامه", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onBack) { Text("بازگشت") }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("حساب این دستگاه", style = MaterialTheme.typography.titleMedium)
                Text(account.displayName, style = MaterialTheme.typography.bodyLarge)
                Text("@${account.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("زنگ تماس", style = MaterialTheme.typography.titleSmall)
                Surface(onClick = onChooseRingtone, shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("♫", color = Color(0xFF9B65F5), style = MaterialTheme.typography.headlineSmall)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(ringtoneTitle, style = MaterialTheme.typography.bodyMedium); Text("انتخاب زنگ پیش‌فرض", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text("›")
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("مسیر فایل‌های دریافتی", style = MaterialTheme.typography.titleSmall)
                Surface(onClick = onChooseFolder, shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("▣", color = Color(0xFFFF9B26), style = MaterialTheme.typography.headlineSmall)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(receivedFolder, style = MaterialTheme.typography.bodyMedium); Text("برای تغییر مسیر لمس کنید", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text("›")
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("نمایش و تم", style = MaterialTheme.typography.titleSmall)
                listOf("light" to "تم روشن", "dark" to "تم تیره").forEach { (value, label) ->
                    Row(Modifier.fillMaxWidth().clickable { onThemeModeChange(value) }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = themeMode == value, onClick = { onThemeModeChange(value) })
                        Text(label, modifier = Modifier.padding(start = 4.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("عیب‌یابی شبکه", style = MaterialTheme.typography.titleMedium)
                Text("بررسی IPهای محلی و VPN، آزمون دو درگاه TCP و کانال امن؛ بدون اتصال به سرور خارجی.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = onOpenNetworkDiagnostics, modifier = Modifier.fillMaxWidth()) { Text("باز کردن ابزار عیب‌یابی شبکه") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("سایر تنظیمات", style = MaterialTheme.typography.titleSmall)
                listOf("اعلان‌ها" to "setting_notifications", "لرزش هنگام تماس" to "setting_vibration", "اعلان دریافت فایل" to "setting_file_notification").forEach { (label, key) ->
                    var enabled by remember(key) { mutableStateOf(prefsSetting(context, key)) }
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⚙", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(end = 10.dp))
                        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = enabled, onCheckedChange = { enabled = it; savePrefsSetting(context, key, it) })
                    }
                }
            }
        }
        Text("همراه‌نت · نسخه آزمایشی", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun NetworkDiagnosticsScreen(
    pairingManager: PairingManager,
    trustedPeers: List<ir.hamrahnet.data.local.TrustedPeerEntity>,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var host by remember { mutableStateOf("") }
    var pairingPort by remember { mutableStateOf(PairingManager.PAIRING_PORT.toString()) }
    var signalPort by remember { mutableStateOf(PairingManager.SIGNAL_PORT.toString()) }
    var selectedFingerprint by remember { mutableStateOf("") }
    var networkSummary by remember { mutableStateOf("برای دریافت وضعیت شبکه، روی «بررسی وضعیت شبکه» بزنید.") }
    var addresses by remember { mutableStateOf(emptyList<String>()) }
    var pairingResult by remember { mutableStateOf("آزمون انجام نشده است.") }
    var signalResult by remember { mutableStateOf("آزمون انجام نشده است.") }
    var secureResult by remember { mutableStateOf("برای آزمون کانال امن، یک مخاطب جفت‌شده انتخاب کنید.") }
    var busy by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("") }
    val latestStatus by pairingManager.status.collectAsState()

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("عیب‌یابی شبکه", style = MaterialTheme.typography.titleLarge)
                Text("آزمون‌ها فقط به IP واردشده یا رابط‌های همین دستگاه متصل می‌شوند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onBack) { Text("بازگشت") }
        }
        Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("۱. وضعیت شبکه", style = MaterialTheme.typography.titleMedium)
            Button(enabled = !busy, onClick = {
                busy = true
                scope.launch {
                    val info = withContext(Dispatchers.IO) {
                        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                        val networks = cm.allNetworks
                        val vpn = networks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
                        val wifi = networks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
                        val internet = cm.activeNetwork?.let { cm.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) } == true
                        val ips = pairingManager.localAddressCandidates()
                        Triple("Wi-Fi: ${if (wifi) "شناسایی شد" else "شناسایی نشد"}\nرابط VPN: ${if (vpn) "شناسایی شد" else "شناسایی نشد"}\nقابلیت اینترنت در شبکه فعال: ${if (internet) "گزارش شده" else "گزارش نشده"}", ips, vpn)
                    }
                    networkSummary = info.first
                    addresses = info.second
                    report = "وضعیت شبکه\n${info.first}\nآدرس‌های محلی: ${info.second.joinToString(", ").ifBlank { "هیچ آدرسی پیدا نشد" }}"
                    busy = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "در حال بررسی…" else "بررسی وضعیت شبکه") }
            Text(networkSummary, style = MaterialTheme.typography.bodyMedium)
            Text("آدرس‌های محلی و VPN", style = MaterialTheme.typography.titleSmall)
            if (addresses.isEmpty()) Text("هنوز آدرسی فهرست نشده است.", style = MaterialTheme.typography.bodySmall)
            addresses.forEach { ip ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(ip, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { host = ip }) { Text("انتخاب برای آزمون") }
                }
            }
        } }
        Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("۲. آزمون اتصال به همتا", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(value = host, onValueChange = { host = it.trim() }, label = { Text("IP مقصد (IPv4 یا IPv6)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = pairingPort, onValueChange = { pairingPort = it.filter(Char::isDigit).take(5) }, label = { Text("درگاه TCP جفت‌سازی (پیش‌فرض 43871)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = signalPort, onValueChange = { signalPort = it.filter(Char::isDigit).take(5) }, label = { Text("درگاه TCP کانال امن (پیش‌فرض 43872)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(enabled = !busy && host.isNotBlank(), onClick = {
                val p1 = pairingPort.toIntOrNull(); val p2 = signalPort.toIntOrNull()
                if (p1 == null || p1 !in 1..65535 || p2 == null || p2 !in 1..65535) {
                    pairingResult = "درگاه جفت‌سازی نامعتبر است."; signalResult = "درگاه کانال امن نامعتبر است."
                } else {
                    busy = true
                    scope.launch {
                        val results = withContext(Dispatchers.IO) {
                            suspend fun probe(port: Int): String = try {
                                Socket().use { it.connect(InetSocketAddress(host.trim().removePrefix("[").removeSuffix("]"), port), 2500) }
                                "موفق: اتصال TCP به درگاه $port برقرار شد."
                            } catch (e: Exception) {
                                "ناموفق: درگاه $port در دسترس نیست (${e.javaClass.simpleName}: ${e.message ?: "بدون جزئیات"})."
                            }
                            probe(p1!!) to probe(p2!!)
                        }
                        pairingResult = results.first
                        signalResult = results.second
                        report = "آزمون اتصال به همتا\nمقصد: $host\n$pairingResult\n$signalResult\nتوجه: موفقیت TCP به‌تنهایی اثبات‌کننده عبور کامل ترافیک تماس یا فایل از VPN نیست."
                        busy = false
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("آزمون هر دو درگاه TCP") }
            Text(pairingResult, style = MaterialTheme.typography.bodySmall)
            Text(signalResult, style = MaterialTheme.typography.bodySmall)
        } }
        Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("۳. آزمون کانال امن", style = MaterialTheme.typography.titleMedium)
            Text("این آزمون فقط برای مخاطبی کار می‌کند که قبلاً با تأیید اثر انگشت جفت شده باشد.", style = MaterialTheme.typography.bodySmall)
            if (trustedPeers.isEmpty()) Text("مخاطب جفت‌شده‌ای روی این دستگاه ثبت نشده است.")
            trustedPeers.forEach { peer ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selectedFingerprint == peer.fingerprint, onClick = {
                        selectedFingerprint = peer.fingerprint
                        if (host.isBlank()) host = peer.lastHostAddress.orEmpty()
                        peer.lastPairingPort?.let { pairingPort = it.toString() }
                        peer.lastSignalPort?.let { signalPort = it.toString() }
                    })
                    Column(Modifier.weight(1f)) {
                        Text(peer.displayName.ifBlank { peer.username })
                        Text(peer.lastHostAddress ?: "IP ذخیره‌شده ندارد", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Button(enabled = !busy && host.isNotBlank() && selectedFingerprint.isNotBlank(), onClick = {
                val peer = trustedPeers.firstOrNull { it.fingerprint == selectedFingerprint }
                val p1 = pairingPort.toIntOrNull() ?: PairingManager.PAIRING_PORT
                val p2 = signalPort.toIntOrNull() ?: PairingManager.SIGNAL_PORT
                if (peer == null) secureResult = "مخاطب انتخاب‌شده پیدا نشد."
                else {
                    busy = true
                    secureResult = "درخواست آزمون امن ارسال شد؛ نتیجه را در وضعیت همراه‌نت بررسی کنید."
                    try {
                        val address = java.net.InetAddress.getByName(host.trim().removePrefix("[").removeSuffix("]"))
                        val device = DiscoveredDevice(
                            serviceName = "HamrahNet-Diagnostic-${peer.username}",
                            displayName = peer.displayName.ifBlank { peer.username },
                            username = peer.username,
                            host = address,
                            port = p1,
                            signalPort = p2,
                            advertisedFingerprint = peer.fingerprint
                        )
                        pairingManager.testSecureChannel(device)
                        secureResult = "آزمون کانال امن شروع شد؛ چند ثانیه بعد نتیجهٔ وضعیت همراه‌نت را بررسی کنید."
                    } catch (e: Exception) {
                        secureResult = "آدرس مقصد نامعتبر است: ${e.message ?: "خطا"}"
                    }
                    report = "آزمون کانال امن\nمخاطب: ${peer.displayName}\nنتیجه: $secureResult\nوضعیت همراه‌نت: $latestStatus"
                    busy = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("بررسی هویت / شروع اتصال مستقیم") }
            Text(secureResult, style = MaterialTheme.typography.bodySmall)
            Text("وضعیت همراه‌نت: $latestStatus", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } }
        Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("۴. گزارش عیب‌یابی", style = MaterialTheme.typography.titleMedium)
            Text("گزارش روی همین دستگاه ساخته می‌شود و خودکار به هیچ سروری ارسال نمی‌شود.", style = MaterialTheme.typography.bodySmall)
            Text(report.ifBlank { "پس از اجرای آزمون‌ها، نتیجه اینجا جمع‌بندی می‌شود." }, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val full = "همراه‌نت — گزارش عیب‌یابی\nزمان: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}\n$networkSummary\nIPها: ${addresses.joinToString()}\nمقصد: $host\n$pairingResult\n$signalResult\n$secureResult\nوضعیت برنامه: $latestStatus"
                    report = full
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("HamrahNet network diagnostics", full))
                }) { Text("ساخت و کپی گزارش") }
                OutlinedButton(onClick = { report = ""; pairingResult = "آزمون انجام نشده است."; signalResult = "آزمون انجام نشده است."; secureResult = "آزمون انجام نشده است." }) { Text("پاک‌سازی") }
            }
        } }
        Text("راهنمای تفسیر: شکست هر دو درگاه معمولاً به IP اشتباه، مسیر VPN یا فایروال مربوط است؛ موفقیت درگاه جفت‌سازی و شکست کانال امن می‌تواند از درگاه دوم، جفت‌سازی/اثر انگشت یا پروتکل امن باشد. آزمون از همین گوشی به IP خودش معادل آزمون بین دو گوشی نیست.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TrustedContactHomeCard(displayName: String, username: String, online: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            androidx.compose.material3.Surface(
                shape = androidx.compose.foundation.shape.CircleShape,
                color = if (online) Color(0xFF168A5B) else MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier.width(10.dp).height(10.dp)
            ) {}
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(displayName, style = MaterialTheme.typography.titleMedium)
                Text("@$username", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (online) "آنلاین در شبکهٔ محلی" else "آفلاین", style = MaterialTheme.typography.bodySmall, color = if (online) Color(0xFF168A5B) else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("مشاهدهٔ اقدامات  ›", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun DiscoveredDeviceCard(
    device: DiscoveredDevice,
    isTrusted: Boolean,
    onAction: () -> Unit,
    onCall: () -> Unit,
    onVideoCall: () -> Unit,
    fileSelected: Boolean,
    onSendFile: () -> Unit
) {
    Card {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(device.displayName, style = MaterialTheme.typography.titleMedium)
            Text(if (device.username.isNotBlank()) "@${device.username}" else "دستگاه همراه‌نت", style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                androidx.compose.material3.Surface(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    color = Color(0xFF168A5B),
                    modifier = Modifier.width(8.dp).height(8.dp)
                ) {}
                Text("آنلاین در شبکهٔ محلی", style = MaterialTheme.typography.bodySmall, color = Color(0xFF168A5B))
            }
            Text("${device.host.hostAddress}:${device.port}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onAction, modifier = Modifier.fillMaxWidth()) {
                Text(if (isTrusted) "آزمایش کانال رمزنگاری‌شده" else "درخواست جفت‌سازی امن")
            }
            if (isTrusted) {
                Button(onClick = onCall, modifier = Modifier.fillMaxWidth()) {
                    Text("تماس صوتی")
                }
                OutlinedButton(onClick = onVideoCall, modifier = Modifier.fillMaxWidth()) {
                    Text("تماس تصویری (آزمایشی)")
                }
                Button(
                    onClick = onSendFile,
                    enabled = fileSelected,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (fileSelected) "ارسال فایل" else "ابتدا فایل را انتخاب کنید")
                }
            }
        }
    }
}

@Composable
private fun IncomingFileOfferDialog(offer: IncomingFileOffer, onAccept: () -> Unit, onReject: () -> Unit) {
    AlertDialog(
        onDismissRequest = onReject,
        title = { Text("درخواست دریافت فایل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${offer.device.displayName} می‌خواهد این فایل را ارسال کند:")
                Text(offer.fileName, style = MaterialTheme.typography.titleMedium)
                Text("حجم: ${formatFileSize(offer.sizeBytes)}")
                Text("فایل فقط پس از تأیید شما دریافت می‌شود و پس از انتقال، صحت آن بررسی خواهد شد.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(onClick = onAccept) { Text("پذیرش و دریافت") } },
        dismissButton = { TextButton(onClick = onReject) { Text("رد درخواست") } }
    )
}

private fun formatFileSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes بایت"
    bytes < 1024L * 1024L -> "${bytes / 1024} کیلوبایت"
    bytes < 1024L * 1024L * 1024L -> "${bytes / (1024L * 1024L)} مگابایت"
    else -> "${bytes / (1024L * 1024L * 1024L)} گیگابایت"
}

@Composable
private fun ActiveCallScreen(
    pairingManager: PairingManager,
    callState: ir.hamrahnet.pairing.VoiceCallUiState,
    onHangUp: () -> Unit
) {
    var localRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    var remoteRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    val isVideo = callState.isVideo
    val darkBlue = Color(0xFF061A33)

    // Attach the renderers only when both views exist. Re-attaching on every AndroidView
    // update can disrupt the WebRTC video sink and cause the remote image to freeze.
    LaunchedEffect(localRenderer, remoteRenderer, isVideo) {
        if (isVideo && localRenderer != null && remoteRenderer != null) {
            pairingManager.attachVideoRenderers(localRenderer, remoteRenderer)
        }
    }

    androidx.compose.foundation.layout.Box(
        modifier = Modifier.fillMaxSize().background(if (isVideo) darkBlue else darkBlue)
    ) {
        if (isVideo) {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier.fillMaxSize()
                    .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("همراه‌نت", color = Color(0xFF8CCBFF), style = MaterialTheme.typography.titleMedium)
                Text(callState.peer?.displayName.orEmpty(), color = Color.White, style = MaterialTheme.typography.headlineSmall)
                Text(callState.status, color = Color(0xFFB9D7F4), style = MaterialTheme.typography.bodyMedium)

                // Keep the remote video at a moderate size rather than filling the whole screen.
                Card(
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false).height(280.dp),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF102A49))
                ) {
                    AndroidView(
                        factory = { ctx -> SurfaceViewRenderer(ctx).also { renderer ->
                            remoteRenderer = renderer
                            renderer.setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FIT)
                        } },
                        modifier = Modifier.fillMaxSize(),
                        update = { view ->
                            if (remoteRenderer !== view) remoteRenderer = view
                            view.setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FIT)
                        }
                    )
                }

                Card(
                    modifier = Modifier.width(104.dp).height(136.dp),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF102A49))
                ) {
                    AndroidView(
                        factory = { ctx -> SurfaceViewRenderer(ctx).also { renderer ->
                            localRenderer = renderer
                            renderer.setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FIT)
                        } },
                        modifier = Modifier.fillMaxSize(),
                        update = { view ->
                            if (localRenderer !== view) localRenderer = view
                            view.setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FIT)
                        }
                    )
                }

                // Compact icon-like controls sit below both previews and above system navigation.
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.IconButton(onClick = { pairingManager.toggleVoiceMute() }) {
                        Text(if (callState.muted) "🎙️" else "🔇", style = MaterialTheme.typography.titleLarge)
                    }
                    androidx.compose.material3.IconButton(onClick = { pairingManager.toggleCamera() }) {
                        Text(if (callState.cameraEnabled) "📷" else "🚫", style = MaterialTheme.typography.titleLarge)
                    }
                    androidx.compose.material3.IconButton(onClick = { pairingManager.switchCamera() }) {
                        Text("🔄", style = MaterialTheme.typography.titleLarge)
                    }
                    androidx.compose.material3.IconButton(onClick = onHangUp) {
                        Text("📞", style = MaterialTheme.typography.titleLarge, color = Color(0xFFFF5B65))
                    }
                }
            }
        } else {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, top = 28.dp, bottom = 44.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("همراه‌نت", color = Color(0xFF8CCBFF), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(34.dp))
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier.width(136.dp).height(136.dp)
                        .clip(androidx.compose.foundation.shape.CircleShape).background(Color(0xFF123B68)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(callState.peer?.displayName?.take(1) ?: "ه", color = Color.White, style = MaterialTheme.typography.displayLarge)
                }
                Spacer(Modifier.height(22.dp))
                Text(callState.peer?.displayName.orEmpty(), color = Color.White, style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text(callState.status, color = Color(0xFFB9D7F4), style = MaterialTheme.typography.bodyLarge)
                Text(voiceStateLabel(callState.engineState), color = Color(0xFFB9D7F4), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.weight(1f))
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.IconButton(
                        onClick = { pairingManager.toggleVoiceMute() },
                        enabled = callState.engineState in listOf(LocalVoiceCallEngine.State.CONNECTING, LocalVoiceCallEngine.State.CONNECTED)
                    ) { Text(if (callState.muted) "🎙️" else "🔇", style = MaterialTheme.typography.titleLarge) }
                    androidx.compose.material3.IconButton(onClick = onHangUp) {
                        Text("📞", style = MaterialTheme.typography.titleLarge, color = Color(0xFFFF5B65))
                    }
                }
            }
        }
    }
}

@Composable
private fun FileTransferScreen(
    selectedFileName: String,
    selectedFileSize: Long,
    fileSelected: Boolean,
    status: String,
    message: String?,
    devices: List<ir.hamrahnet.discovery.DiscoveredDevice>,
    onChooseFile: () -> Unit,
    onSend: (ir.hamrahnet.discovery.DiscoveredDevice) -> Unit,
    onBack: () -> Unit
) {
    androidx.compose.foundation.layout.Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("بازگشت") }
            Text("ارسال و دریافت فایل", style = MaterialTheme.typography.headlineSmall)
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("فایل انتخاب‌شده", style = MaterialTheme.typography.titleMedium)
                Text(if (fileSelected) selectedFileName else "هنوز فایلی انتخاب نشده است", style = MaterialTheme.typography.bodyLarge)
                if (fileSelected) Text("حجم: ${formatFileSize(selectedFileSize)}", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = onChooseFile, modifier = Modifier.fillMaxWidth()) { Text(if (fileSelected) "انتخاب فایل دیگر" else "انتخاب فایل") }
                message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("وضعیت انتقال", style = MaterialTheme.typography.titleMedium)
                Text(status, style = MaterialTheme.typography.bodyLarge)
                val percent = Regex("(\\d{1,3})٪").find(status)?.groupValues?.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 100)
                if (percent != null) {
                    androidx.compose.material3.LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("$percent٪", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
        Text("انتخاب مخاطب آنلاین", style = MaterialTheme.typography.titleMedium)
        if (devices.isEmpty()) {
            Text("در حال حاضر دستگاه آنلاینی برای ارسال پیدا نشده است. VPN یا LAN را روی هر دو گوشی وصل کنید و جست‌وجو را تازه‌سازی کنید؛ می‌توانید ابتدا با IP یا QR جفت‌سازی کنید.", style = MaterialTheme.typography.bodyMedium)
        } else {
            devices.forEach { device ->
                Card {
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                            Text(device.displayName, style = MaterialTheme.typography.titleMedium)
                            Text("@${device.username} · آنلاین", style = MaterialTheme.typography.bodySmall, color = Color(0xFF168A5B))
                        }
                        Button(onClick = { onSend(device) }, enabled = fileSelected) { Text("ارسال") }
                    }
                }
            }
        }
        Text("گیرنده باید دریافت فایل را صریحاً تأیید کند. تا پیش از تأیید، انتقال فایل آغاز نمی‌شود.", style = MaterialTheme.typography.bodySmall)
    }
}

private fun voiceStateLabel(state: LocalVoiceCallEngine.State): String = when (state) {
    LocalVoiceCallEngine.State.IDLE -> "آماده"
    LocalVoiceCallEngine.State.PREPARING -> "آماده‌سازی"
    LocalVoiceCallEngine.State.RINGING -> "در حال زنگ‌خوردن"
    LocalVoiceCallEngine.State.CONNECTING -> "در حال اتصال"
    LocalVoiceCallEngine.State.CONNECTED -> "متصل"
    LocalVoiceCallEngine.State.DISCONNECTED -> "ارتباط قطع شده است"
    LocalVoiceCallEngine.State.FAILED -> "ناموفق"
    LocalVoiceCallEngine.State.CLOSED -> "بسته"
}

@Composable
private fun PairingApprovalDialog(prompt: PairingPrompt, onDecision: (Boolean) -> Unit) {
    AlertDialog(
        onDismissRequest = { onDecision(false) },
        title = { Text(if (prompt.direction == PairingDirection.INCOMING) "درخواست جفت‌سازی ورودی" else "تأیید جفت‌سازی") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("دستگاه: ${prompt.displayName} (@${prompt.username})")
                Text("آدرس محلی: ${prompt.address}", style = MaterialTheme.typography.bodySmall)
                Text("کد تأیید", style = MaterialTheme.typography.titleMedium)
                Text(prompt.sasCode, style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                Text("کد باید دقیقاً با کد روی گوشی مقابل یکسان باشد. اگر کدها متفاوت‌اند یا امکان مقایسه ندارید، درخواست را رد کنید.")
            }
        },
        confirmButton = { Button(onClick = { onDecision(true) }) { Text("کد یکسان است؛ تأیید") } },
        dismissButton = { TextButton(onClick = { onDecision(false) }) { Text("رد درخواست") } }
    )
}

private fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}
