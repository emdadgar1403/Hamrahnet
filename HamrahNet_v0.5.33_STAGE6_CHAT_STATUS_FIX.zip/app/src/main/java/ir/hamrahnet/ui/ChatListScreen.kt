package ir.hamrahnet.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.hamrahnet.data.local.ChatMessageDao
import ir.hamrahnet.data.local.TrustedPeerEntity
import ir.hamrahnet.discovery.DiscoveredDevice

@Composable
internal fun ChatListScreen(
    peers: List<TrustedPeerEntity>,
    devices: List<DiscoveredDevice>,
    chatDao: ChatMessageDao,
    networkStatus: String,
    onRefresh: () -> Unit,
    onOpenConversation: (String) -> Unit,
    onOpenContacts: () -> Unit,
    onAddPeer: () -> Unit,
    onInvite: () -> Unit,
    onExit: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val onlineFingerprints = remember(devices) { devices.map { it.advertisedFingerprint.lowercase() }.toSet() }
    val visiblePeers = remember(peers, onlineFingerprints, query) {
        peers.filter { peer ->
            query.isBlank() || peer.displayName.contains(query, true) ||
                peer.username.contains(query, true) || peer.fingerprint.contains(query, true)
        }.sortedWith(
            compareByDescending<TrustedPeerEntity> { it.fingerprint.lowercase() in onlineFingerprints }
                .thenBy { it.displayName.lowercase() }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().height(68.dp)
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("همراه‌نت", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
                Text("ارتباط امن، مستقیم و خصوصی", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onExit) { Text("خروج") }
        }

        // Local network status banner
        Box(
            modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp)
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF174FC5), Color(0xFF16A8E0))))
                .padding(horizontal = 20.dp, vertical = 17.dp)
        ) {
            Surface(
                color = Color.White.copy(alpha = 0.16f),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth().clickable { onRefresh() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text("⌁", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (devices.isEmpty()) "آفلاین در شبکه محلی · در انتظار دستگاه‌ها"
                        else "آنلاین در شبکه محلی · ${devices.size} مخاطب در دسترس",
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(22.dp),
                placeholder = { Text("جست‌وجوی نام، شناسه یا توضیحات") },
                leadingIcon = { Text("⌕", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            )

            OutlinedButton(
                onClick = onAddPeer,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(22.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("＋  افزودن با شناسه یا IP")
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("مخاطبان", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = onOpenContacts) { Text("مدیریت مخاطبان") }
            }

            if (visiblePeers.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                        Text("＋", modifier = Modifier.padding(18.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.headlineLarge)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(if (peers.isEmpty()) "هنوز مخاطبی اضافه نشده است" else "مخاطبی پیدا نشد", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (peers.isEmpty()) "برای شروع، مخاطب را با شناسه یا QR اضافه کنید."
                        else "عبارت جست‌وجو را تغییر دهید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (peers.isEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onInvite) { Text("افزودن مخاطب با QR") }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(visiblePeers, key = { it.fingerprint }) { peer ->
                        val online = peer.fingerprint.lowercase() in onlineFingerprints ||
                            devices.any { it.username.equals(peer.username, true) }
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onOpenConversation(peer.fingerprint) },
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(peer.displayName.firstOrNull()?.toString() ?: "؟", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge)
                                    }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(peer.displayName.ifBlank { peer.username }, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("@${peer.username} · ${if (online) "آنلاین" else "آفلاین"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                }
                                Box(contentAlignment = Alignment.Center) {
                                    Surface(shape = CircleShape, color = if (online) Color(0xFF18B981) else MaterialTheme.colorScheme.outline, modifier = Modifier.size(11.dp)) {}
                                }
                                Spacer(Modifier.width(5.dp))
                                Text("♢", color = Color(0xFF18B981), style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
