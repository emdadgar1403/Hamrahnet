package ir.hamrahnet.signaling

import android.util.Base64
import ir.hamrahnet.data.local.TrustedPeerDao
import ir.hamrahnet.data.local.TrustedPeerEntity
import ir.hamrahnet.discovery.DiscoveredDevice
import ir.hamrahnet.pairing.DeviceIdentity
import ir.hamrahnet.pairing.PairingProtocol
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.runBlocking
import org.json.JSONObject

/**
 * Phase 3 foundation: authenticated, encrypted request/response signaling over the local network.
 *
 * Each connection uses fresh ECDH ephemeral keys. The stable Android Keystore identity signs
 * the handshake, and the remote identity must already exist in trusted_peers. Frames use
 * AES-GCM with transcript-bound AAD and strictly increasing per-direction sequence numbers.
 *
 * Authenticated encrypted one-message request/response channel. Call signaling payloads are
 * handled by the application callback; no payload is accepted before trusted identity checks.
 */
internal class SecureSignalingProtocol(
    private val identity: DeviceIdentity,
    private val peerDao: TrustedPeerDao
) {
    companion object {
        private const val VERSION = 1
        private const val MAX_LINE_BYTES = 64 * 1024
        private const val SOCKET_TIMEOUT_MS = 10_000
        private const val CLIENT_TO_SERVER = "client-to-server"
        private const val SERVER_TO_CLIENT = "server-to-client"
    }

    /** Compatibility overload that also advertises this device's signaling listener port. */
    fun ping(device: DiscoveredDevice, local: PairingProtocol.LocalIdentity, localSignalPort: Int): String {
        val response = sendMessage(
            device,
            local,
            localSignalPort,
            JSONObject().put("type", "ping").put("protocol", VERSION)
        )
        require(response.optString("type") == "pong" && response.optInt("protocol", -1) == VERSION) {
            "پاسخ کانال امن معتبر نیست."
        }
        return "کانال امن با ${device.displayName} برقرار شد."
    }

    fun ping(device: DiscoveredDevice, local: PairingProtocol.LocalIdentity): String {
        val response = sendMessage(device, local, JSONObject().put("type", "ping").put("protocol", VERSION))
        require(response.optString("type") == "pong" && response.optInt("protocol", -1) == VERSION) {
            "پاسخ کانال امن معتبر نیست."
        }
        return "کانال امن با ${device.displayName} برقرار شد."
    }

    /** Compatibility overload: include the sender's signaling port in the encrypted payload. */
    fun sendMessage(
        device: DiscoveredDevice,
        local: PairingProtocol.LocalIdentity,
        localSignalPort: Int,
        message: JSONObject
    ): JSONObject {
        require(localSignalPort in 1..65535) { "درگاه کانال امن محلی معتبر نیست." }
        val payload = JSONObject(message.toString()).put("signalPort", localSignalPort)
        return sendMessage(device, local, payload)
    }

    /** Send one authenticated encrypted signaling message to a trusted peer. */
    fun sendMessage(
        device: DiscoveredDevice,
        local: PairingProtocol.LocalIdentity,
        message: JSONObject
    ): JSONObject {
        require(device.signalPort in 1..65535) { "درگاه کانال امن دستگاه معتبر نیست." }
        val trusted = findTrustedPeer(device.advertisedFingerprint)
            ?: throw SecurityException("ابتدا این دستگاه را با کد تأیید جفت‌سازی کنید.")
        verifyStoredPeer(trusted)

        Socket().use { socket ->
            socket.connect(InetSocketAddress(device.host, device.signalPort), 5_000)
            socket.soTimeout = if (message.optString("type") == "file_offer") 120_000 else SOCKET_TIMEOUT_MS
            val input = socket.getInputStream()
            val output = socket.getOutputStream()
            val clientEphemeral = generateEphemeralKeyPair()
            val client = Hello(
                fingerprint = local.fingerprint,
                username = local.username,
                ephemeralPublicKey = b64(clientEphemeral.public.encoded),
                nonce = b64(randomBytes(32))
            )
            writeLine(output, JSONObject()
                .put("type", "secure_hello")
                .put("version", VERSION)
                .put("fingerprint", client.fingerprint)
                .put("username", client.username)
                .put("ephemeralKey", client.ephemeralPublicKey)
                .put("nonce", client.nonce)
                .put("signature", identity.sign(local.keyPair, clientHelloPayload(client))))

            val serverJson = readLine(input)
            require(serverJson.optString("type") == "secure_hello") { "پاسخ آغاز کانال امن نامعتبر است." }
            require(serverJson.optInt("version", -1) == VERSION) { "نسخه کانال امن سازگار نیست." }
            val server = Hello(
                fingerprint = serverJson.getString("fingerprint"),
                username = serverJson.getString("username"),
                ephemeralPublicKey = serverJson.getString("ephemeralKey"),
                nonce = serverJson.getString("nonce")
            )
            require(server.fingerprint.equals(trusted.fingerprint, ignoreCase = true)) {
                "هویت سرور با دستگاه مورد اعتماد مطابقت ندارد."
            }
            require(server.username == trusted.username) { "شناسه دستگاه مقابل با اطلاعات مورد اعتماد مطابقت ندارد." }
            val serverPublicKey = decodePublicKey(trusted)
            val transcript = transcript(client, server)
            require(identity.verify(serverPublicKey, serverHelloPayload(transcript), serverJson.getString("signature"))) {
                "امضای پاسخ کانال امن معتبر نیست."
            }
            val transcriptHash = sha256(transcript.toByteArray(Charsets.UTF_8))
            val transcriptHash64 = b64(transcriptHash)
            writeLine(output, JSONObject().put("type", "secure_finish")
                .put("signature", identity.sign(local.keyPair, finishPayload(transcriptHash64))))

            val keys = deriveKeys(clientEphemeral, server.ephemeralPublicKey, transcriptHash)
            writeEncrypted(output, message, keys.clientToServerKey, keys.clientToServerPrefix,
                CLIENT_TO_SERVER, transcriptHash64, sequence = 0L)
            return readEncrypted(input, keys.serverToClientKey, keys.serverToClientPrefix,
                SERVER_TO_CLIENT, transcriptHash64, expectedSequence = 0L)
        }
    }

    /**
     * Server-side entry point for a socket accepted by the dedicated signaling listener.
     * A connection is rejected unless the client's signing identity is already trusted.
     */
    /** Compatibility overload for handlers that need the sender endpoint for a reply. */
    fun serve(
        socket: Socket,
        local: PairingProtocol.LocalIdentity,
        localSignalPort: Int,
        onMessage: (fingerprint: String, username: String, remoteSignalPort: Int, remoteHost: java.net.InetAddress, message: JSONObject) -> JSONObject
    ) {
        require(localSignalPort in 1..65535) { "درگاه کانال امن محلی معتبر نیست." }
        val remoteHost = socket.inetAddress
        serve(socket, local) { fingerprint, username, message ->
            onMessage(fingerprint, username, message.optInt("signalPort", 0), remoteHost, message)
        }
    }

    fun serve(
        socket: Socket,
        local: PairingProtocol.LocalIdentity,
        onMessage: (fingerprint: String, username: String, message: JSONObject) -> JSONObject = { _, _, message ->
            if (message.optString("type") == "ping") JSONObject().put("type", "pong").put("protocol", VERSION)
            else JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "unsupported")
        }
    ) {
        socket.use {
            it.soTimeout = SOCKET_TIMEOUT_MS
            val input = it.getInputStream()
            val output = it.getOutputStream()

            val clientJson = readLine(input)
            require(clientJson.optString("type") == "secure_hello") { "نوع پیام کانال امن نامعتبر است." }
            require(clientJson.optInt("version", -1) == VERSION) { "نسخه کانال امن سازگار نیست." }
            val client = Hello(
                fingerprint = clientJson.getString("fingerprint"),
                username = clientJson.getString("username"),
                ephemeralPublicKey = clientJson.getString("ephemeralKey"),
                nonce = clientJson.getString("nonce")
            )
            val trusted = findTrustedPeer(client.fingerprint)
                ?: throw SecurityException("دستگاه درخواست‌دهنده مورد اعتماد نیست.")
            verifyStoredPeer(trusted)
            require(client.username == trusted.username) { "شناسه دستگاه درخواست‌دهنده معتبر نیست." }
            val clientPublicKey = decodePublicKey(trusted)
            require(identity.verify(clientPublicKey, clientHelloPayload(client), clientJson.getString("signature"))) {
                "امضای درخواست کانال امن معتبر نیست."
            }

            val serverEphemeral = generateEphemeralKeyPair()
            val server = Hello(
                fingerprint = local.fingerprint,
                username = local.username,
                ephemeralPublicKey = b64(serverEphemeral.public.encoded),
                nonce = b64(randomBytes(32))
            )
            val transcript = transcript(client, server)
            writeLine(output, JSONObject()
                .put("type", "secure_hello")
                .put("version", VERSION)
                .put("fingerprint", server.fingerprint)
                .put("username", server.username)
                .put("ephemeralKey", server.ephemeralPublicKey)
                .put("nonce", server.nonce)
                .put("signature", identity.sign(local.keyPair, serverHelloPayload(transcript))))

            val transcriptHash = sha256(transcript.toByteArray(Charsets.UTF_8))
            val transcriptHash64 = b64(transcriptHash)
            val finish = readLine(input)
            require(finish.optString("type") == "secure_finish") { "تأیید نهایی کانال امن دریافت نشد." }
            require(identity.verify(clientPublicKey, finishPayload(transcriptHash64), finish.getString("signature"))) {
                "امضای تأیید نهایی کانال امن معتبر نیست."
            }

            val keys = deriveKeys(serverEphemeral, client.ephemeralPublicKey, transcriptHash)
            val message = readEncrypted(input, keys.clientToServerKey, keys.clientToServerPrefix,
                CLIENT_TO_SERVER, transcriptHash64, expectedSequence = 0L)
            val response = onMessage(client.fingerprint, client.username, message)
            writeEncrypted(output, response,
                keys.serverToClientKey, keys.serverToClientPrefix,
                SERVER_TO_CLIENT, transcriptHash64, sequence = 0L)
        }
    }

    private fun findTrustedPeer(fingerprint: String): TrustedPeerEntity? =
        runBlocking { peerDao.findByFingerprint(fingerprint.lowercase()) }
            ?: runBlocking { peerDao.findByFingerprint(fingerprint) }

    private fun verifyStoredPeer(peer: TrustedPeerEntity) {
        val key = decodePublicKey(peer)
        require(identity.fingerprint(key).equals(peer.fingerprint, ignoreCase = true)) {
            "اثر انگشت کلید ذخیره‌شده معتبر نیست."
        }
    }

    private fun decodePublicKey(peer: TrustedPeerEntity): ByteArray =
        Base64.decode(peer.publicKeyBase64, Base64.NO_WRAP)

    private data class Hello(
        val fingerprint: String,
        val username: String,
        val ephemeralPublicKey: String,
        val nonce: String
    )

    private data class SessionKeys(
        val clientToServerKey: ByteArray,
        val serverToClientKey: ByteArray,
        val clientToServerPrefix: ByteArray,
        val serverToClientPrefix: ByteArray
    )

    private fun clientHelloPayload(client: Hello): ByteArray =
        "HamrahNet-SecureHello-v1\nclient\n${client.fingerprint}\n${client.username}\n${client.ephemeralPublicKey}\n${client.nonce}"
            .toByteArray(Charsets.UTF_8)

    private fun serverHelloPayload(transcript: String): ByteArray =
        "HamrahNet-SecureHello-v1\nserver\n$transcript".toByteArray(Charsets.UTF_8)

    private fun finishPayload(transcriptHash64: String): ByteArray =
        "HamrahNet-SecureFinish-v1\n$transcriptHash64".toByteArray(Charsets.UTF_8)

    private fun transcript(client: Hello, server: Hello): String = buildString {
        append("HamrahNet-SecureTranscript-v1\n")
        append(client.fingerprint).append('\n')
        append(client.username).append('\n')
        append(client.ephemeralPublicKey).append('\n')
        append(client.nonce).append('\n')
        append(server.fingerprint).append('\n')
        append(server.username).append('\n')
        append(server.ephemeralPublicKey).append('\n')
        append(server.nonce)
    }

    private fun generateEphemeralKeyPair(): KeyPair =
        KeyPairGenerator.getInstance("EC").apply {
            initialize(ECGenParameterSpec("secp256r1"))
        }.generateKeyPair()

    private fun deriveKeys(localEphemeral: KeyPair, remoteEphemeralBase64: String, salt: ByteArray): SessionKeys {
        val remoteKey = java.security.KeyFactory.getInstance("EC").generatePublic(
            java.security.spec.X509EncodedKeySpec(unb64(remoteEphemeralBase64))
        )
        val agreement = KeyAgreement.getInstance("ECDH")
        agreement.init(localEphemeral.private)
        agreement.doPhase(remoteKey, true)
        val sharedSecret = agreement.generateSecret()
        val prk = hmac(salt, sharedSecret)
        val material = hkdfExpand(prk, "HamrahNet-Signal-Keys-v1".toByteArray(Charsets.UTF_8), 72)
        sharedSecret.fill(0)
        prk.fill(0)
        return SessionKeys(
            clientToServerKey = material.copyOfRange(0, 32),
            serverToClientKey = material.copyOfRange(32, 64),
            clientToServerPrefix = material.copyOfRange(64, 68),
            serverToClientPrefix = material.copyOfRange(68, 72)
        ).also { material.fill(0) }
    }

    private fun writeEncrypted(
        output: OutputStream,
        message: JSONObject,
        key: ByteArray,
        noncePrefix: ByteArray,
        direction: String,
        transcriptHash64: String,
        sequence: Long
    ) {
        require(sequence >= 0) { "شماره توالی پیام نامعتبر است." }
        val iv = nonce(noncePrefix, sequence)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(aad(direction, sequence, transcriptHash64))
        val encrypted = cipher.doFinal(message.toString().toByteArray(Charsets.UTF_8))
        writeLine(output, JSONObject()
            .put("type", "secure_frame")
            .put("seq", sequence)
            .put("iv", b64(iv))
            .put("ciphertext", b64(encrypted)))
    }

    private fun readEncrypted(
        input: InputStream,
        key: ByteArray,
        noncePrefix: ByteArray,
        direction: String,
        transcriptHash64: String,
        expectedSequence: Long
    ): JSONObject {
        val frame = readLine(input)
        require(frame.optString("type") == "secure_frame") { "قالب پیام رمزنگاری‌شده نامعتبر است." }
        val sequence = frame.getLong("seq")
        require(sequence == expectedSequence) { "شماره توالی پیام نامعتبر یا تکراری است." }
        val iv = unb64(frame.getString("iv"))
        require(iv.size == 12 && iv.copyOfRange(0, 4).contentEquals(noncePrefix)) {
            "شناسه رمزنگاری پیام نامعتبر است."
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(aad(direction, sequence, transcriptHash64))
        val plain = cipher.doFinal(unb64(frame.getString("ciphertext")))
        return JSONObject(plain.toString(Charsets.UTF_8))
    }

    private fun nonce(prefix: ByteArray, sequence: Long): ByteArray {
        require(prefix.size == 4)
        val result = ByteArray(12)
        System.arraycopy(prefix, 0, result, 0, 4)
        for (i in 0 until 8) result[11 - i] = (sequence ushr (i * 8)).toByte()
        return result
    }

    private fun aad(direction: String, sequence: Long, transcriptHash64: String): ByteArray =
        "HamrahNet-Signal-v1\n$direction\n$sequence\n$transcriptHash64".toByteArray(Charsets.UTF_8)

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data)
    }

    private fun hkdfExpand(prk: ByteArray, info: ByteArray, length: Int): ByteArray {
        val output = ByteArrayOutputStream()
        var previous = ByteArray(0)
        var counter = 1
        while (output.size() < length) {
            previous = hmac(prk, previous + info + byteArrayOf(counter.toByte()))
            output.write(previous)
            counter++
        }
        return output.toByteArray().copyOf(length)
    }

    private fun randomBytes(size: Int): ByteArray = ByteArray(size).also { SecureRandom().nextBytes(it) }
    private fun sha256(bytes: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(bytes)
    private fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)
    private fun unb64(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP)

    private fun writeLine(output: OutputStream, json: JSONObject) {
        val bytes = (json.toString() + "\n").toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_LINE_BYTES) { "پیام بیش از اندازه بزرگ است." }
        output.write(bytes)
        output.flush()
    }

    private fun readLine(input: InputStream): JSONObject {
        val buffer = ByteArrayOutputStream()
        while (true) {
            val next = input.read()
            if (next == -1) throw EOFException("ارتباط پیش از تکمیل پیام بسته شد.")
            if (next == '\n'.code) break
            if (buffer.size() >= MAX_LINE_BYTES) throw IllegalArgumentException("پیام بیش از اندازه بزرگ است.")
            if (next != '\r'.code) buffer.write(next)
        }
        return JSONObject(buffer.toByteArray().toString(Charsets.UTF_8))
    }
}
