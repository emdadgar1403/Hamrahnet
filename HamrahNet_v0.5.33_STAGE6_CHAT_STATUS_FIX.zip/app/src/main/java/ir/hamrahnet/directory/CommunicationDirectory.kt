package ir.hamrahnet.directory

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.InetAddress

/**
 * Offline lookup from a user-entered communication ID to a reachable endpoint.
 * The ID is only an address-book key, never an identity, credential, or authorization token.
 */
data class DirectoryEntry(
    val id: String,
    val name: String,
    val host: String,
    val pairingPort: Int = DEFAULT_PAIRING_PORT,
    val signalPort: Int = DEFAULT_SIGNAL_PORT
) {
    companion object {
        const val DEFAULT_PAIRING_PORT = 43871
        const val DEFAULT_SIGNAL_PORT = 43872
    }
}

class CommunicationDirectory(private val context: Context) {
    fun lookup(idInput: String): DirectoryEntry? {
        val id = idInput.trim()
        require(id.matches(Regex("^[0-9]{4,12}$"))) { "شناسه ارتباطی باید عددی و بین ۴ تا ۱۲ رقم باشد." }
        val json = try {
            context.assets.open(ASSET_FILE).bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: IOException) {
            throw IOException("فایل فهرست ارتباطی پیدا نشد: $ASSET_FILE", e)
        }
        val peers = JSONObject(json).optJSONArray("peers") ?: return null
        for (i in 0 until peers.length()) {
            val item = peers.optJSONObject(i) ?: continue
            if (item.optString("id") == id) {
                val host = item.optString("host").trim()
                require(host.isNotBlank() && isIpLiteral(host)) { "آدرس IP ثبت‌شده برای این شناسه معتبر نیست؛ فهرست را اصلاح کنید." }
                val pairingPort = item.optInt("pairingPort", DirectoryEntry.DEFAULT_PAIRING_PORT)
                val signalPort = item.optInt("signalPort", DirectoryEntry.DEFAULT_SIGNAL_PORT)
                require(pairingPort in 1..65535 && signalPort in 1..65535) { "درگاه ثبت‌شده معتبر نیست." }
                return DirectoryEntry(id, item.optString("name", id), host, pairingPort, signalPort)
            }
        }
        return null
    }

    private fun isIpLiteral(value: String): Boolean = try {
        // Reject hostnames: the directory is intentionally an IP-to-endpoint mapping.
        val addr = InetAddress.getByName(value)
        addr.hostAddress.equals(value, ignoreCase = true) || value.contains(':') || value.matches(Regex("^[0-9.]+$"))
    } catch (_: Exception) { false }

    companion object { const val ASSET_FILE = "hamrahnet-peers.json" }
}
