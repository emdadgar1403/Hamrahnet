package ir.hamrahnet.call

import android.content.Context
import android.media.AudioManager
import android.media.AudioFocusRequest
import android.media.AudioAttributes
import android.os.Build
import android.util.Log
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.EglBase
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.MediaStream
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.StatsObserver
import org.webrtc.StatsReport
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import org.webrtc.audio.JavaAudioDeviceModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Phase 4 WebRTC audio core.
 *
 * Deliberately uses an empty ICE server list: this implementation is intended for direct
 * host-candidate connectivity on the same local Wi-Fi and does not contact STUN/TURN services.
 * Signaling messages must be transported by the authenticated encrypted HamrahNet channel;
 * this class itself does not open sockets or bypass pairing/trust checks.
 */
@Suppress("DEPRECATION")
class LocalVoiceCallEngine(context: Context, private val videoEnabled: Boolean = false) {
    companion object { private const val TAG = "HamrahNetVideo" }

    private fun writeDiagnostic(level: String, message: String) = CallDiagnosticLog.write(appContext, level, TAG, message)
    private fun logI(message: String) { Log.i(TAG, message); writeDiagnostic("I", message) }
    private fun logD(message: String) { Log.d(TAG, message); writeDiagnostic("D", message) }
    private fun logW(message: String) { Log.w(TAG, message); writeDiagnostic("W", message) }
    private fun logE(message: String) { Log.e(TAG, message); writeDiagnostic("E", message) }
    enum class State { IDLE, PREPARING, RINGING, CONNECTING, CONNECTED, DISCONNECTED, FAILED, CLOSED }

    private val appContext = context.applicationContext
    init { CallDiagnosticLog.start(appContext); logI("CALL_DIAG_ENGINE_CREATED videoEnabled=$videoEnabled sdk=${Build.VERSION.SDK_INT}") }
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var previousAudioMode: Int = AudioManager.MODE_NORMAL
    private var previousSpeakerphoneState: Boolean = false
    private var audioConfigured = false
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            // Keep call state intact; Android's route/focus may be restored by the system.
        }
    }
    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state.asStateFlow()

    @Volatile var onLocalIceCandidate: ((IceCandidate) -> Unit)? = null
    @Volatile var onError: ((String) -> Unit)? = null
    @Volatile var onLocalDescriptionReady: ((SessionDescription) -> Unit)? = null

    private val audioDeviceModule = JavaAudioDeviceModule.builder(appContext).createAudioDeviceModule()
    private val factory: PeerConnectionFactory
    private var peer: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var cameraCapturer: CameraVideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private val eglBase: EglBase? = if (videoEnabled) EglBase.create() else null
    private var localRenderer: SurfaceViewRenderer? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    @Volatile private var remoteVideoTrack: VideoTrack? = null
    @Volatile private var waitingForGathering = false
    private val diagnosticsExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "HamrahNet-WebRTC-Diagnostics").apply { isDaemon = true }
    }
    @Volatile private var diagnosticsTask: ScheduledFuture<*>? = null
    @Volatile private var localIceCandidateCount = 0
    @Volatile private var remoteDescriptionApplied = false

    private val observer = object : PeerConnection.Observer {
        override fun onSignalingChange(state: PeerConnection.SignalingState) {
            logI("CALL_EVENT signaling_state=$state")
        }
        override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
            logI("CALL_EVENT ice_connection_state=$state roleState=${_state.value} videoEnabled=$videoEnabled")
            if (state == PeerConnection.IceConnectionState.CONNECTED || state == PeerConnection.IceConnectionState.COMPLETED) {
                requestStatsSnapshot("ice_connected")
            }
            _state.value = when (state) {
                PeerConnection.IceConnectionState.CONNECTED,
                PeerConnection.IceConnectionState.COMPLETED -> State.CONNECTED
                PeerConnection.IceConnectionState.CHECKING,
                PeerConnection.IceConnectionState.NEW -> State.CONNECTING
                PeerConnection.IceConnectionState.DISCONNECTED -> State.DISCONNECTED
                PeerConnection.IceConnectionState.FAILED -> State.FAILED
                PeerConnection.IceConnectionState.CLOSED -> State.CLOSED
                else -> _state.value
            }
        }
        override fun onIceConnectionReceivingChange(receiving: Boolean) {
            logI("CALL_EVENT ice_receiving=$receiving")
        }
        override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {
            logI("CALL_EVENT ice_gathering_state=$state localCandidateCallbacks=$localIceCandidateCount")
            if (state == PeerConnection.IceGatheringState.COMPLETE && waitingForGathering) {
                waitingForGathering = false
                peer?.localDescription?.let {
                    logI("CALL_EVENT local_description_ready type=${it.type} ${describeSdp(it.description)}")
                    onLocalDescriptionReady?.invoke(it)
                }
            }
        }
        override fun onIceCandidate(candidate: IceCandidate) {
            localIceCandidateCount++
            logD("CALL_EVENT local_ice_candidate index=$localIceCandidateCount sdpMid=${candidate.sdpMid} line=${candidate.sdpMLineIndex} type=${candidate.sdp.substringAfter(" typ ", "unknown").substringBefore(' ')}")
            onLocalIceCandidate?.invoke(candidate)
        }
        override fun onIceCandidatesRemoved(candidates: Array<IceCandidate>) {
            logD("CALL_EVENT local_ice_candidates_removed count=${candidates.size}")
        }
        override fun onAddStream(stream: org.webrtc.MediaStream) {
            logD("onAddStream: audio=${stream.audioTracks.size}, video=${stream.videoTracks.size}")
            stream.videoTracks.firstOrNull()?.let { attachRemoteVideo(it) }
        }
        override fun onRemoveStream(stream: org.webrtc.MediaStream) {
            logI("CALL_EVENT remove_stream audio=${stream.audioTracks.size} video=${stream.videoTracks.size}")
        }
        override fun onDataChannel(channel: org.webrtc.DataChannel) = Unit
        override fun onRenegotiationNeeded() { logI("CALL_EVENT renegotiation_needed") }
        override fun onAddTrack(receiver: org.webrtc.RtpReceiver, streams: Array<out org.webrtc.MediaStream>) {
            logI("CALL_EVENT on_add_track kind=${receiver.track()?.kind()} trackId=${receiver.track()?.id()} streams=${streams.size}")
            (receiver.track() as? VideoTrack)?.let { attachRemoteVideo(it) }
        }
        override fun onTrack(transceiver: org.webrtc.RtpTransceiver) {
            val track = transceiver.receiver.track()
            logI("CALL_EVENT on_track kind=${track?.kind()} trackId=${track?.id()} mid=${transceiver.mid} direction=${transceiver.direction} currentDirection=${transceiver.currentDirection}")
            (track as? VideoTrack)?.let { attachRemoteVideo(it) }
        }
    }

    init {
        logI("CALL_EVENT engine_init videoEnabled=$videoEnabled sdk=${Build.VERSION.SDK_INT}")
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(appContext)
                .createInitializationOptions()
        )
        val factoryBuilder = PeerConnectionFactory.builder()
            .setAudioDeviceModule(audioDeviceModule)
        // Explicitly register video codecs. Without encoder/decoder factories, WebRTC
        // can create a video track while generating a rejected m-line (m=video 0).
        if (videoEnabled) {
            val eglContext = requireNotNull(eglBase) { "بستر EGL برای تماس تصویری آماده نیست." }.eglBaseContext
            factoryBuilder
                .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglContext, true, true))
                .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglContext))
        }
        factory = factoryBuilder.createPeerConnectionFactory()
    }

    /** Attach Android renderers after the Compose call screen is created. */
    @Synchronized fun attachRenderers(local: SurfaceViewRenderer?, remote: SurfaceViewRenderer?) {
        val egl = eglBase ?: return
        if (local != null && localRenderer !== local) {
            try { localRenderer?.let { videoTrack?.removeSink(it) } } catch (_: Exception) { }
            localRenderer = local
            local.init(egl.eglBaseContext, null)
            logI("CALL_EVENT local_renderer_initialized")
            local.setMirror(true)
            local.setEnableHardwareScaler(true)
            videoTrack?.addSink(local)
        }
        if (remote != null && remoteRenderer !== remote) {
            try { remoteRenderer?.let { remoteVideoTrack?.removeSink(it) } } catch (_: Exception) { }
            remoteRenderer = remote
            remote.init(egl.eglBaseContext, null)
            logI("CALL_EVENT remote_renderer_initialized existingTrack=${remoteVideoTrack != null}")
            remote.setMirror(false)
            remote.setEnableHardwareScaler(true)
            remoteVideoTrack?.let { track ->
                track.setEnabled(true)
                track.addSink(remote)
                logI("Remote video renderer attached to existing track")
            }
        }
    }

    fun switchCamera(): Boolean {
        val capturer = cameraCapturer ?: return false
        return try { capturer.switchCamera(null); true } catch (_: Exception) { false }
    }

    fun setVideoEnabled(enabled: Boolean) { videoTrack?.setEnabled(enabled) }

    /** Prepare audio and create a peer connection for an outgoing call. */
    fun startOutgoingCall() {
        check(peer == null) { "تماس دیگری در حال اجراست." }
        logI("CALL_EVENT start_outgoing videoEnabled=$videoEnabled")
        configureAudioForCall()
        _state.value = State.PREPARING
        createPeer()
        val source = factory.createAudioSource(MediaConstraints())
        audioSource = source
        val track = factory.createAudioTrack("hamrahnet-audio", source)
        audioTrack = track
        track.setEnabled(true)
        peer?.addTrack(track, listOf("hamrahnet-media-stream"))
        if (videoEnabled) addLocalVideoTrack()
        _state.value = State.CONNECTING
        peer?.createOffer(sdpObserver(onCreate = { offer -> setLocalAndWaitForIce(offer) }), createSdpConstraints())
    }

    /** Prepare a peer for an incoming offer, then create an answer. */
    fun acceptOffer(offerSdp: String) {
        check(peer == null) { "تماس دیگری در حال اجراست." }
        logI("CALL_EVENT accept_offer videoEnabled=$videoEnabled ${describeSdp(offerSdp)}")
        configureAudioForCall()
        _state.value = State.PREPARING
        createPeer()
        val source = factory.createAudioSource(MediaConstraints())
        audioSource = source
        val track = factory.createAudioTrack("hamrahnet-audio", source)
        audioTrack = track
        track.setEnabled(true)
        peer?.addTrack(track, listOf("hamrahnet-media-stream"))
        // In Unified Plan, apply the remote offer before adding the local video track.
        // This lets WebRTC match the local sender to the offered video transceiver instead
        // of creating a separate transceiver that can leave the negotiated m-line stopped.
        val offer = SessionDescription(SessionDescription.Type.OFFER, offerSdp)
        peer?.setRemoteDescription(sdpObserver(onSet = {
            remoteDescriptionApplied = true
            logI("CALL_EVENT remote_offer_set_success")
            _state.value = State.RINGING
            requestStatsSnapshot("remote_offer_set")
            try {
                if (videoEnabled) addLocalVideoTrack()
                logI("CALL_EVENT answer_preparation videoEnabled=$videoEnabled ${peer?.transceivers?.joinToString(";") { t -> "mid=${t.mid},kind=${t.receiver.track()?.kind()},direction=${t.direction},currentDirection=${t.currentDirection},stopped=${t.isStopped}" }}")
                peer?.createAnswer(sdpObserver(onCreate = { answer -> setLocalAndWaitForIce(answer) }), createSdpConstraints())
            } catch (e: Exception) {
                logE("CALL_EVENT answer_preparation_failed error=${e.javaClass.simpleName}:${e.message}")
                reportError("آماده‌سازی پاسخ تماس ناموفق بود: ${e.message ?: "خطای WebRTC"}")
            }
        }), offer)
    }

    /** Apply the answer received through the encrypted signaling layer. */
    fun acceptAnswer(answerSdp: String) {
        val current = peer ?: error("تماسی برای دریافت پاسخ وجود ندارد.")
        logI("CALL_EVENT accept_answer ${describeSdp(answerSdp)}")
        current.setRemoteDescription(sdpObserver(onSet = {
            remoteDescriptionApplied = true
            logI("CALL_EVENT remote_answer_set_success")
            _state.value = State.CONNECTING
            requestStatsSnapshot("remote_answer_set")
        }),
            SessionDescription(SessionDescription.Type.ANSWER, answerSdp))
    }

    /** Add an ICE candidate received through the encrypted signaling layer. */
    fun addRemoteIceCandidate(candidate: IceCandidate) {
        val current = peer ?: error("تماس هنوز آماده نیست.")
        val accepted = current.addIceCandidate(candidate)
        logI("CALL_EVENT remote_ice_candidate_added accepted=$accepted sdpMid=${candidate.sdpMid} line=${candidate.sdpMLineIndex}")
        if (!accepted) reportError("نامزد ICE دریافتی پذیرفته نشد.")
    }

    fun setMuted(muted: Boolean) { audioTrack?.setEnabled(!muted) }

    fun endCall() {
        logI("CALL_EVENT end_call state=${_state.value} remoteTrack=${remoteVideoTrack != null} remoteDescriptionApplied=$remoteDescriptionApplied localIceCandidateCallbacks=$localIceCandidateCount")
        diagnosticsTask?.cancel(true)
        diagnosticsTask = null
        waitingForGathering = false
        try { peer?.close() } catch (_: Exception) { }
        try { peer?.dispose() } catch (_: Exception) { }
        peer = null
        try { audioTrack?.dispose() } catch (_: Exception) { }
        audioTrack = null
        try { localRenderer?.let { videoTrack?.removeSink(it) } } catch (_: Exception) { }
        try { remoteRenderer?.let { remoteVideoTrack?.removeSink(it) } } catch (_: Exception) { }
        try { cameraCapturer?.stopCapture() } catch (_: Exception) { }
        try { cameraCapturer?.dispose() } catch (_: Exception) { }
        cameraCapturer = null
        try { videoTrack?.dispose() } catch (_: Exception) { }
        videoTrack = null
        try { videoSource?.dispose() } catch (_: Exception) { }
        videoSource = null
        try { surfaceTextureHelper?.dispose() } catch (_: Exception) { }
        surfaceTextureHelper = null
        try { localRenderer?.release() } catch (_: Exception) { }
        try { remoteRenderer?.release() } catch (_: Exception) { }
        localRenderer = null
        remoteRenderer = null
        remoteVideoTrack = null
        remoteDescriptionApplied = false
        localIceCandidateCount = 0
        try { audioSource?.dispose() } catch (_: Exception) { }
        audioSource = null
        restoreAudioAfterCall()
        _state.value = State.IDLE
    }

    fun release() {
        endCall()
        factory.dispose()
        audioDeviceModule.release()
        try { eglBase?.release() } catch (_: Exception) { }
        diagnosticsExecutor.shutdownNow()
        _state.value = State.CLOSED
    }

    private fun addLocalVideoTrack() {
        val egl = eglBase ?: return
        val enumerator = Camera2Enumerator(appContext)
        val cameraName = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
            ?: enumerator.deviceNames.firstOrNull()
            ?: throw IllegalStateException("دوربینی در دستگاه پیدا نشد.")
        val capturer = enumerator.createCapturer(cameraName, null) as? CameraVideoCapturer
            ?: throw IllegalStateException("راه‌اندازی دوربین ناموفق بود.")
        cameraCapturer = capturer
        val helper = SurfaceTextureHelper.create("HamrahNet-Camera", egl.eglBaseContext)
        surfaceTextureHelper = helper
        val source = factory.createVideoSource(capturer.isScreencast)
        videoSource = source
        capturer.initialize(helper, appContext, source.capturerObserver)
        logI("CALL_EVENT local_camera_start name=$cameraName frontFacing=${enumerator.isFrontFacing(cameraName)} resolution=640x480 fps=24")
        capturer.startCapture(640, 480, 24)
        val track = factory.createVideoTrack("hamrahnet-video", source)
        videoTrack = track
        track.setEnabled(true)
        val sender = peer?.addTrack(track, listOf("hamrahnet-media-stream"))
        logI("CALL_EVENT local_video_track_added trackId=${track.id()} senderCreated=${sender != null}")
        localRenderer?.let { track.addSink(it) }
    }

    @Synchronized private fun attachRemoteVideo(track: VideoTrack) {
        // WebRTC may deliver both onAddTrack and onTrack for the same receiver.
        // Ensure the received track is enabled and bind it even if the UI renderer is created later.
        track.setEnabled(true)
        val previous = remoteVideoTrack
        if (previous !== track) {
            try { remoteRenderer?.let { previous?.removeSink(it) } } catch (_: Exception) { }
            remoteVideoTrack = track
            logI("CALL_EVENT remote_video_track_attached trackId=${track.id()} rendererReady=${remoteRenderer != null} enabled=${track.enabled()}")
            remoteRenderer?.let { renderer ->
                try { track.addSink(renderer) } catch (e: Exception) { run { Log.e(TAG, "Could not attach remote video renderer", e); writeDiagnostic("E", "Could not attach remote video renderer: ${e.javaClass.simpleName}: ${e.message}") } }
            }
        }
    }

    private fun createSdpConstraints(): MediaConstraints = MediaConstraints().apply {
        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
        if (videoEnabled) mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
    }

    private fun configureAudioForCall() {
        if (audioConfigured) return
        previousAudioMode = audioManager.mode
        previousSpeakerphoneState = audioManager.isSpeakerphoneOn
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(attributes)
                    .setOnAudioFocusChangeListener(audioFocusListener)
                    .setAcceptsDelayedFocusGain(false)
                    .build()
                audioManager.requestAudioFocus(audioFocusRequest!!)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(audioFocusListener, AudioManager.STREAM_VOICE_CALL, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            }
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = true
            audioConfigured = true
        } catch (e: Exception) {
            reportError("تنظیم مسیر صدای تماس ناموفق بود: ${e.message ?: "خطای صوتی"}")
        }
    }

    private fun restoreAudioAfterCall() {
        if (!audioConfigured) return
        try {
            audioManager.isSpeakerphoneOn = previousSpeakerphoneState
            audioManager.mode = previousAudioMode
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(audioFocusListener)
            }
        } catch (_: Exception) { }
        audioConfigured = false
    }

    private fun createPeer() {
        logI("CALL_EVENT create_peer iceServers=0 sdpSemantics=UNIFIED_PLAN videoEnabled=$videoEnabled")
        val config = PeerConnection.RTCConfiguration(emptyList()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_ONCE
        }
        peer = factory.createPeerConnection(config, observer)
            ?: throw IllegalStateException("ساخت اتصال WebRTC ناموفق بود.").also { reportError(it.message ?: "خطای WebRTC") }
        logI("CALL_EVENT peer_created")
        startPeriodicStats()
    }

    private fun setLocalAndWaitForIce(description: SessionDescription) {
        waitingForGathering = true
        logI("CALL_EVENT set_local_description type=${description.type} ${describeSdp(description.description)}")
        peer?.setLocalDescription(sdpObserver(onSet = {
            logI("CALL_EVENT local_description_set_success type=${description.type}")
            // Some implementations complete gathering immediately; check both states.
            val current = peer
            if (waitingForGathering && current?.iceGatheringState() == PeerConnection.IceGatheringState.COMPLETE) {
                waitingForGathering = false
                current.localDescription?.let {
                    logI("CALL_EVENT local_description_ready type=${it.type} ${describeSdp(it.description)}")
                    onLocalDescriptionReady?.invoke(it)
                }
            }
        }), description)
    }

    private fun sdpObserver(onCreate: ((SessionDescription) -> Unit)? = null, onSet: (() -> Unit)? = null) =
        object : SdpObserver {
            override fun onCreateSuccess(description: SessionDescription) {
                logI("CALL_EVENT sdp_created type=${description.type} ${describeSdp(description.description)}")
                onCreate?.invoke(description)
            }
            override fun onSetSuccess() {
                logD("CALL_EVENT sdp_set_success")
                onSet?.invoke()
            }
            override fun onCreateFailure(error: String) {
                logE("CALL_EVENT sdp_create_failed error=$error")
                reportError("ساخت SDP ناموفق بود: $error")
            }
            override fun onSetFailure(error: String) {
                logE("CALL_EVENT sdp_set_failed error=$error")
                reportError("ثبت SDP ناموفق بود: $error")
            }
        }

    private fun describeSdp(sdp: String): String {
        val audioSections = Regex("(?m)^m=audio ").findAll(sdp).count()
        val videoSections = Regex("(?m)^m=video ").findAll(sdp).count()
        val candidates = Regex("(?m)^a=candidate:").findAll(sdp).count()
        val endOfCandidates = Regex("(?m)^a=end-of-candidates\\s*$").findAll(sdp).count()
        return "sdpChars=${sdp.length} audioM=$audioSections videoM=$videoSections embeddedCandidates=$candidates endOfCandidates=$endOfCandidates"
    }

    private fun startPeriodicStats() {
        diagnosticsTask?.cancel(true)
        diagnosticsTask = diagnosticsExecutor.scheduleAtFixedRate({ requestStatsSnapshot("periodic") }, 3, 5, TimeUnit.SECONDS)
    }

    private fun requestStatsSnapshot(reason: String) {
        val current = peer ?: return
        try {
            current.getStats(object : StatsObserver {
                override fun onComplete(reports: Array<StatsReport>) {
                    val selected = reports.filter { report ->
                        report.type == "ssrc" || report.type == "inbound-rtp" || report.type == "outbound-rtp" ||
                            report.type == "candidate-pair" || report.type == "transport"
                    }
                    for (report in selected) {
                        val values = report.values.filter { value ->
                            value.name in setOf("kind", "mediaType", "googTrackId", "bytesReceived", "bytesSent",
                                "packetsReceived", "packetsSent", "framesReceived", "framesDecoded", "framesEncoded",
                                "framesSent", "codecId", "state", "selected", "nominated", "requestsReceived",
                                "responsesReceived", "currentRoundTripTime", "availableIncomingBitrate", "availableOutgoingBitrate")
                        }.joinToString(",") { "${it.name}=${it.value}" }
                        if (values.isNotBlank()) logI("CALL_STATS reason=$reason type=${report.type} id=${report.id} $values")
                    }
                }
            }, null)
        } catch (e: Exception) {
            logW("CALL_EVENT stats_request_failed reason=$reason error=${e.javaClass.simpleName}:${e.message}")
        }
    }

    private fun reportError(message: String) {
        logE("CALL_EVENT engine_error message=$message")
        _state.value = State.FAILED
        onError?.invoke(message)
    }
}
