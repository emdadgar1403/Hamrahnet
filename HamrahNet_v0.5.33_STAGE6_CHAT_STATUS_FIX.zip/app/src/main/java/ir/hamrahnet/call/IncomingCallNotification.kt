package ir.hamrahnet.call

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ir.hamrahnet.MainActivity

/** Posts a high-priority incoming-call notification and requests the system full-screen UI. */
object IncomingCallNotification {
    const val EXTRA_SHOW_INCOMING_CALL = "ir.hamrahnet.extra.SHOW_INCOMING_CALL"

    private const val TAG = "HamrahNetIncomingCall"
    private const val CHANNEL_ID = "hamrahnet_incoming_calls"
    private const val NOTIFICATION_ID = 5202

    fun show(context: Context, callerName: String) {
        val appContext = context.applicationContext
        createChannel(appContext)

        val openCallIntent = Intent(appContext, MainActivity::class.java).apply {
            action = "ir.hamrahnet.action.SHOW_INCOMING_CALL"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_SHOW_INCOMING_CALL, true)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            appContext,
            NOTIFICATION_ID,
            openCallIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(appContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("تماس صوتی ورودی")
            .setContentText("تماس از ${callerName.take(80)}")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                appContext.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS is not granted; cannot show incoming-call notification")
                return
            }
            NotificationManagerCompat.from(appContext).notify(NOTIFICATION_ID, notification)
            if (Build.VERSION.SDK_INT >= 34) {
                val manager = appContext.getSystemService(NotificationManager::class.java)
                if (manager != null && !manager.canUseFullScreenIntent()) {
                    Log.w(TAG, "Full-screen intent access is disabled in system settings")
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Could not post incoming-call notification", e)
        }
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context.applicationContext).cancel(NOTIFICATION_ID)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "تماس‌های ورودی همراه‌نت",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "نمایش و پاسخ به تماس صوتی ورودی همراه‌نت"
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            // The app already plays its own ring tone; avoid playing a second notification sound.
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }
}
