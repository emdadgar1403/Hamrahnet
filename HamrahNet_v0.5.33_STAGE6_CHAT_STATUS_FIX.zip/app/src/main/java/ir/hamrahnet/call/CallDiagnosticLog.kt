package ir.hamrahnet.call

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.BufferedWriter
import java.io.File
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Writes call diagnostics to app-private storage and, when available, Downloads/HamrahNet. */
internal object CallDiagnosticLog {
    private const val TAG = "HamrahNetVideo"
    private val lock = Any()
    @Volatile private var initialized = false
    private var privateWriter: BufferedWriter? = null
    private var publicWriter: BufferedWriter? = null
    private var publicUri: Uri? = null
    private var privateFile: File? = null

    /** Call when the call engine is created so a file exists before the first call event. */
    fun start(context: Context) {
        synchronized(lock) {
            if (!initialized) initialize(context.applicationContext)
            appendLocked("# logger_start=${now()}")
        }
    }

    fun write(context: Context, level: String, sourceTag: String, message: String) {
        val line = "${now()} [$level] [$sourceTag] $message"
        synchronized(lock) {
            if (!initialized) initialize(context.applicationContext)
            appendLocked(line)
            // Storage failure must be visible even if the custom file could not be opened.
            if (privateWriter == null && publicWriter == null) {
                Log.e(TAG, "CALL_DIAG_NO_FILE_WRITER; lastMessage=$message")
            }
        }
    }

    private fun initialize(context: Context) {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(Date())
        val displayName = "HamrahNet-call-$stamp-${android.os.Process.myPid()}.txt"
        val header = "# HamrahNet WebRTC diagnostics\n# started=${now()}\n# deviceSdk=${Build.VERSION.SDK_INT}\n# app-private and public copies are attempted independently."
        // Private copy is the reliable fallback and needs no storage permission.
        try {
            val dir = File(context.filesDir, "diagnostics")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("mkdirs failed: ${dir.absolutePath}")
            val f = File(dir, displayName)
            privateWriter = BufferedWriter(OutputStreamWriter(f.outputStream(), Charsets.UTF_8))
            privateFile = f
            privateWriter?.write(header); privateWriter?.newLine(); privateWriter?.flush()
            Log.i(TAG, "CALL_DIAG_PRIVATE_FILE path=${f.absolutePath}")
        } catch (e: Exception) {
            privateWriter = null
            Log.e(TAG, "CALL_DIAG_PRIVATE_CREATE_FAILED ${e.javaClass.simpleName}: ${e.message}")
        }
        // Public copy is best-effort; a failure here does not disable the private copy.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HamrahNet")
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("MediaStore insert returned null")
                val stream = context.contentResolver.openOutputStream(uri, "w")
                    ?: throw IllegalStateException("openOutputStream returned null")
                publicUri = uri
                publicWriter = BufferedWriter(OutputStreamWriter(stream, Charsets.UTF_8))
                publicWriter?.write(header); publicWriter?.newLine(); publicWriter?.flush()
                Log.i(TAG, "CALL_DIAG_PUBLIC_FILE path=Download/HamrahNet/$displayName uri=$uri")
            } catch (e: Exception) {
                Log.e(TAG, "CALL_DIAG_PUBLIC_CREATE_FAILED ${e.javaClass.simpleName}: ${e.message}")
                try { publicWriter?.close() } catch (_: Exception) { }
                publicWriter = null
                try { publicUri?.let { context.contentResolver.delete(it, null, null) } } catch (_: Exception) { }
                publicUri = null
            }
        } else {
            Log.i(TAG, "CALL_DIAG_PUBLIC_FILE_UNAVAILABLE sdk=${Build.VERSION.SDK_INT}; use app-private file path")
        }
        initialized = privateWriter != null || publicWriter != null
        if (!initialized) Log.e(TAG, "CALL_DIAG_INIT_FAILED no writable destination")
    }

    private fun appendLocked(line: String) {
        var wrote = false
        try { privateWriter?.apply { write(line); newLine(); flush() }; if (privateWriter != null) wrote = true }
        catch (e: Exception) { Log.e(TAG, "CALL_DIAG_PRIVATE_WRITE_FAILED ${e.javaClass.simpleName}: ${e.message}"); try { privateWriter?.close() } catch (_: Exception) { }; privateWriter = null }
        try { publicWriter?.apply { write(line); newLine(); flush() }; if (publicWriter != null) wrote = true }
        catch (e: Exception) { Log.e(TAG, "CALL_DIAG_PUBLIC_WRITE_FAILED ${e.javaClass.simpleName}: ${e.message}"); try { publicWriter?.close() } catch (_: Exception) { }; publicWriter = null }
        if (!wrote) Log.e(TAG, "CALL_DIAG_WRITE_FAILED privatePath=${privateFile?.absolutePath ?: "unavailable"} publicUri=${publicUri ?: "unavailable"}")
    }

    fun close() {
        synchronized(lock) {
            try { privateWriter?.flush(); privateWriter?.close() } catch (_: Exception) { }
            try { publicWriter?.flush(); publicWriter?.close() } catch (_: Exception) { }
            privateWriter = null; publicWriter = null; publicUri = null; privateFile = null; initialized = false
        }
    }

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
}
