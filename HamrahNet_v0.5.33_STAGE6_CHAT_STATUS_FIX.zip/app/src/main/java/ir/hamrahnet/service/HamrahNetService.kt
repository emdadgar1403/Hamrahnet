package ir.hamrahnet.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import ir.hamrahnet.HamrahNetApplication
import ir.hamrahnet.MainActivity
import ir.hamrahnet.R

/** Keeps local discovery and signaling alive while the Activity is not visible. */
class HamrahNetService : Service() {
    companion object {
        const val ACTION_START = "ir.hamrahnet.service.START"
        const val ACTION_STOP = "ir.hamrahnet.service.STOP"
        const val ACTION_CALL_ACTIVE = "ir.hamrahnet.service.CALL_ACTIVE"
        const val EXTRA_CALL_ACTIVE = "call_active"
        const val EXTRA_DISPLAY_NAME = "display_name"
        const val EXTRA_USERNAME = "username"

        private const val TAG = "HamrahNetService"
        private const val CHANNEL_ID = "hamrahnet_availability"
        private const val NOTIFICATION_ID = 5201

        fun start(context: Context, displayName: String, username: String) {
            val intent = Intent(context, HamrahNetService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_DISPLAY_NAME, displayName)
                putExtra(EXTRA_USERNAME, username)
            }
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        }

        fun setCallActive(context: Context, active: Boolean) {
            val intent = Intent(context, HamrahNetService::class.java).apply {
                action = ACTION_CALL_ACTIVE
                putExtra(EXTRA_CALL_ACTIVE, active)
            }
            try { context.startService(intent) } catch (e: Exception) {
                Log.w(TAG, "Could not update foreground service call state", e)
            }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val pairingManager by lazy { (application as HamrahNetApplication).pairingManager }
    private val connectivityManager by lazy {
        getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var serviceStarted = false
    private var callActive = false
    @Volatile private var presenceWakeLock: PowerManager.WakeLock? = null
    private val networkRefreshRunnable = Runnable {
        if (serviceStarted) {
            Log.i(TAG, "Default network changed; refreshing local discovery while preserving direct sockets")
            pairingManager.refreshDiscovery()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopNetworkService()
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_CALL_ACTIVE) {
            callActive = intent.getBooleanExtra(EXTRA_CALL_ACTIVE, false)
            startAsForeground()
            return START_REDELIVER_INTENT
        }

        // Enter foreground state immediately; Android requires this shortly after startForegroundService().
        startAsForeground()

        val displayName = intent?.getStringExtra(EXTRA_DISPLAY_NAME)
        val username = intent?.getStringExtra(EXTRA_USERNAME)
        if (!displayName.isNullOrBlank() && !username.isNullOrBlank()) {
            serviceStarted = true
            acquirePresenceWakeLock()
            pairingManager.start(displayName, username)
            registerWifiNetworkCallback()
        } else {
            Log.w(TAG, "Start requested without account details; keeping service foreground until relaunch")
        }
        return START_REDELIVER_INTENT
    }

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            if (callActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            // Video calls must promote the already-running foreground service to the camera
            // type as well. Declaring FOREGROUND_SERVICE_CAMERA in the manifest is not enough:
            // the active type must include CAMERA so capture can continue when the Activity
            // is no longer visible (Android 14/15 camera foreground-service rules).
            if (callActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                checkSelfPermission(android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 1, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, HamrahNetService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("همراه‌نت فعال است")
            .setContentText(if (callActive) "تماس فعال است؛ صدا و در صورت تماس تصویری دوربین در حال اجراست" else "حضور LAN/VPN در پس‌زمینه فعال است؛ ممکن است مصرف باتری بیشتر شود")
            .setContentIntent(openAppPendingIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "توقف سرویس", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "فعال‌بودن همراه‌نت در پس‌زمینه",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "برای کشف دستگاه‌های محلی و آماده‌بودن سرویس تماس"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun registerWifiNetworkCallback() {
        if (networkCallback != null) return
        // The default route may be a VPN rather than Wi-Fi. Observe default-network changes
        // instead of watching Wi-Fi alone so VPN up/down events refresh mDNS and peer probes.
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                mainHandler.removeCallbacks(networkRefreshRunnable)
                mainHandler.postDelayed(networkRefreshRunnable, 1_200L)
            }

            override fun onLost(network: Network) {
                mainHandler.removeCallbacks(networkRefreshRunnable)
                mainHandler.postDelayed(networkRefreshRunnable, 1_200L)
            }
        }
        try {
            connectivityManager.registerDefaultNetworkCallback(callback)
            networkCallback = callback
        } catch (e: Exception) {
            Log.w(TAG, "Could not register default network callback", e)
        }
    }

    private fun stopNetworkService() {
        serviceStarted = false
        callActive = false
        networkCallback?.let {
            try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) { }
        }
        networkCallback = null
        mainHandler.removeCallbacksAndMessages(null)
        pairingManager.stop()
        releasePresenceWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    /**
     * Keep the CPU awake while the user-visible foreground presence service is enabled.
     * This helps the probe loop and listening sockets survive screen-off CPU sleep; Android
     * Doze/VPN routing policies may still delay or block network traffic.
     */
    private fun acquirePresenceWakeLock() {
        if (presenceWakeLock?.isHeld == true) return
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            presenceWakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "$packageName:HamrahNetPresence"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
            Log.i(TAG, "Presence partial wake lock acquired; screen-off availability may use more battery")
        } catch (e: Exception) {
            presenceWakeLock = null
            Log.w(TAG, "Could not acquire presence wake lock", e)
        }
    }

    private fun releasePresenceWakeLock() {
        try {
            presenceWakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            Log.w(TAG, "Could not release presence wake lock", e)
        } finally {
            presenceWakeLock = null
        }
    }

    override fun onDestroy() {
        stopNetworkService()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
