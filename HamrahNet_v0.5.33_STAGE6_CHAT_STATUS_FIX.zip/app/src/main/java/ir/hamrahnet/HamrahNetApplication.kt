package ir.hamrahnet

import android.app.Activity
import android.app.Application
import android.os.Bundle
import ir.hamrahnet.data.local.HamrahNetDatabase
import ir.hamrahnet.data.repository.AccountRepository
import ir.hamrahnet.pairing.PairingManager
import java.util.concurrent.atomic.AtomicInteger

class HamrahNetApplication : Application(), Application.ActivityLifecycleCallbacks {
    private val startedActivities = AtomicInteger(0)
    @Volatile var isAppInForeground: Boolean = false
        private set

    val database: HamrahNetDatabase by lazy { HamrahNetDatabase.create(this) }
    val accountRepository: AccountRepository by lazy { AccountRepository(database.localAccountDao()) }
    val pairingManager: PairingManager by lazy { PairingManager(this, database.trustedPeerDao(), database.chatMessageDao()) }

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(this)
    }

    override fun onActivityStarted(activity: Activity) {
        isAppInForeground = startedActivities.incrementAndGet() > 0
    }

    override fun onActivityStopped(activity: Activity) {
        isAppInForeground = startedActivities.updateAndGet { (it - 1).coerceAtLeast(0) } > 0
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
    override fun onActivityResumed(activity: Activity) = Unit
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit
}
