package ir.hamrahnet

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlinx.coroutines.delay
import ir.hamrahnet.call.IncomingCallNotification
import ir.hamrahnet.ui.HamrahNetApp
import ir.hamrahnet.ui.theme.HamrahNetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prepareForIncomingCall(intent)
        val app = application as HamrahNetApplication
        setContent {
            val prefs = getSharedPreferences("hamrahnet_preferences", MODE_PRIVATE)
            var themeMode by remember { mutableStateOf(prefs.getString("theme_mode", "light") ?: "light") }
            var showSplash by rememberSaveable {
                mutableStateOf(intent?.getBooleanExtra(IncomingCallNotification.EXTRA_SHOW_INCOMING_CALL, false) != true)
            }
            LaunchedEffect(Unit) {
                if (showSplash) {
                    delay(2200)
                    showSplash = false
                }
            }
            val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
            HamrahNetTheme(darkTheme = when (themeMode) { "dark" -> true; "light" -> false; else -> false }) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    if (showSplash) {
                        HamrahNetSplashScreen()
                    } else {
                        HamrahNetApp(
                            repository = app.accountRepository,
                            pairingManager = app.pairingManager,
                            themeMode = themeMode,
                            onThemeModeChange = { mode ->
                                themeMode = mode
                                prefs.edit().putString("theme_mode", mode).apply()
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        prepareForIncomingCall(intent)
    }

    private fun prepareForIncomingCall(intent: Intent?) {
        if (intent?.getBooleanExtra(IncomingCallNotification.EXTRA_SHOW_INCOMING_CALL, false) != true) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
    }
}


@androidx.compose.runtime.Composable
private fun HamrahNetSplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF073B91), Color(0xFF087BE8), Color(0xFF062A68))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier.size(132.dp).clip(RoundedCornerShape(30.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = ir.hamrahnet.R.drawable.hamrahnet_icon_background),
                    contentDescription = null,
                    modifier = Modifier.size(132.dp)
                )
                Image(
                    painter = painterResource(id = ir.hamrahnet.R.drawable.hamrahnet_icon_foreground),
                    contentDescription = "آیکون همراه‌نت",
                    modifier = Modifier.size(132.dp)
                )
            }
            Spacer(Modifier.height(22.dp))
            Text(
                text = "همراه‌نت",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "HamrahNet",
                color = Color(0xFFE0F4FF),
                fontSize = 19.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "ارتباط آسان، امن، آفلاین",
                color = Color(0xFFD4E9FF),
                fontSize = 13.sp
            )
        }
    }
}
