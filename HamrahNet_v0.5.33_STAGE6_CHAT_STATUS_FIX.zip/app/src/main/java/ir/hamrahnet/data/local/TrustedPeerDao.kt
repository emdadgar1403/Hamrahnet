package ir.hamrahnet.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TrustedPeerDao {
    @Query("SELECT * FROM trusted_peers ORDER BY displayName COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<TrustedPeerEntity>>

    @Query("SELECT * FROM trusted_peers WHERE fingerprint = :fingerprint COLLATE NOCASE LIMIT 1")
    suspend fun findByFingerprint(fingerprint: String): TrustedPeerEntity?

    @Query("DELETE FROM trusted_peers WHERE fingerprint = :fingerprint")
    suspend fun deleteByFingerprint(fingerprint: String)

    @Query("UPDATE trusted_peers SET lastHostAddress = :hostAddress, lastPairingPort = :pairingPort, lastSignalPort = :signalPort WHERE fingerprint = :fingerprint")
    suspend fun updateEndpoint(fingerprint: String, hostAddress: String, pairingPort: Int, signalPort: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(peer: TrustedPeerEntity)
}
