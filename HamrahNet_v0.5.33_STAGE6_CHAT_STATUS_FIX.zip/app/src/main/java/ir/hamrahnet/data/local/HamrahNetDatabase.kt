package ir.hamrahnet.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [LocalAccountEntity::class, TrustedPeerEntity::class, ChatMessageEntity::class],
    version = 4,
    exportSchema = false
)
abstract class HamrahNetDatabase : RoomDatabase() {
    abstract fun localAccountDao(): LocalAccountDao
    abstract fun trustedPeerDao(): TrustedPeerDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """CREATE TABLE IF NOT EXISTS trusted_peers (
                        fingerprint TEXT NOT NULL PRIMARY KEY,
                        displayName TEXT NOT NULL,
                        username TEXT NOT NULL,
                        publicKeyBase64 TEXT NOT NULL,
                        pairedAtEpochMs INTEGER NOT NULL
                    )""".trimIndent()
                )
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE trusted_peers ADD COLUMN lastHostAddress TEXT")
                db.execSQL("ALTER TABLE trusted_peers ADD COLUMN lastPairingPort INTEGER")
                db.execSQL("ALTER TABLE trusted_peers ADD COLUMN lastSignalPort INTEGER")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS chat_messages (
                    messageId TEXT NOT NULL PRIMARY KEY,
                    peerFingerprint TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    body TEXT NOT NULL,
                    createdAtEpochMs INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    error TEXT
                )""".trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chat_messages_peerFingerprint_createdAtEpochMs ON chat_messages(peerFingerprint, createdAtEpochMs)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chat_messages_peerFingerprint_status ON chat_messages(peerFingerprint, status)")
            }
        }

        fun create(context: Context): HamrahNetDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                HamrahNetDatabase::class.java,
                "hamrahnet.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build()
    }
}
