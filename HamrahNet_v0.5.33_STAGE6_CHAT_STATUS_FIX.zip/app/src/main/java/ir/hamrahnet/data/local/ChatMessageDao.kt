package ir.hamrahnet.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE peerFingerprint = :fingerprint ORDER BY createdAtEpochMs ASC")
    fun observeConversation(fingerprint: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY createdAtEpochMs DESC")
    fun observeAllLatestFirst(): Flow<List<ChatMessageEntity>>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE peerFingerprint = :fingerprint AND direction = 'INCOMING' AND status = 'RECEIVED'")
    fun observeUnreadCount(fingerprint: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(message: ChatMessageEntity): Long

    @Query("SELECT * FROM chat_messages WHERE messageId = :messageId LIMIT 1")
    suspend fun findById(messageId: String): ChatMessageEntity?

    @Query("SELECT * FROM chat_messages")
    suspend fun getAllForEncryptionMigration(): List<ChatMessageEntity>

    @Query("UPDATE chat_messages SET body = :encryptedBody WHERE messageId = :messageId")
    suspend fun updateEncryptedBody(messageId: String, encryptedBody: String)

    @Query("SELECT * FROM chat_messages WHERE direction = 'OUTGOING' AND status IN ('QUEUED','SENDING','FAILED') ORDER BY createdAtEpochMs ASC")
    suspend fun getPendingOutgoing(): List<ChatMessageEntity>

    @Query("SELECT * FROM chat_messages WHERE direction = 'INCOMING' AND status = 'READ_PENDING' ORDER BY createdAtEpochMs ASC")
    suspend fun getPendingReadReceipts(): List<ChatMessageEntity>

    @Query("SELECT messageId FROM chat_messages WHERE peerFingerprint = :fingerprint AND direction = 'INCOMING' AND status = 'RECEIVED'")
    suspend fun getUnreadIncomingIds(fingerprint: String): List<String>

    @Query("UPDATE chat_messages SET status = :status, error = :error WHERE messageId = :messageId")
    suspend fun updateStatus(messageId: String, status: String, error: String? = null)

    @Query("UPDATE chat_messages SET status = 'READ_PENDING' WHERE peerFingerprint = :fingerprint AND direction = 'INCOMING' AND status = 'RECEIVED'")
    suspend fun markConversationRead(fingerprint: String)
}
