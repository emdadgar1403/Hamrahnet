package ir.hamrahnet.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trusted_peers")
data class TrustedPeerEntity(
    @PrimaryKey val fingerprint: String,
    val displayName: String,
    val username: String,
    val publicKeyBase64: String,
    val pairedAtEpochMs: Long,
    val lastHostAddress: String? = null,
    val lastPairingPort: Int? = null,
    val lastSignalPort: Int? = null
)
