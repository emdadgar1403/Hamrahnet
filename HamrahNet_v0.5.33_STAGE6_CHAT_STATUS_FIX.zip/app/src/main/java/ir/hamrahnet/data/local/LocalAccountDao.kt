package ir.hamrahnet.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LocalAccountDao {
    @Query("SELECT * FROM local_accounts ORDER BY createdAtEpochMs DESC LIMIT 1")
    fun observeAccount(): Flow<LocalAccountEntity?>

    @Query("SELECT * FROM local_accounts WHERE username = :username LIMIT 1")
    suspend fun findByUsername(username: String): LocalAccountEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(account: LocalAccountEntity)

    @Query("SELECT COUNT(*) FROM local_accounts")
    suspend fun count(): Int
}
