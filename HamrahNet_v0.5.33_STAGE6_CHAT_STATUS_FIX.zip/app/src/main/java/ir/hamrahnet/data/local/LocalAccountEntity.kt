package ir.hamrahnet.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "local_accounts")
data class LocalAccountEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val username: String,
    val passwordSalt: String,
    val passwordHash: String,
    val createdAtEpochMs: Long
)
