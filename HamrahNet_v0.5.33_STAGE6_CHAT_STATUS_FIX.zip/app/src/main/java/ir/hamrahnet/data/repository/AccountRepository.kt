package ir.hamrahnet.data.repository

import ir.hamrahnet.data.local.LocalAccountDao
import ir.hamrahnet.data.local.LocalAccountEntity
import ir.hamrahnet.security.PasswordHasher
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

sealed interface CreateAccountResult {
    data object Created : CreateAccountResult
    data object UsernameAlreadyExists : CreateAccountResult
    data object InvalidInput : CreateAccountResult
    data class Failure(val message: String) : CreateAccountResult
}

class AccountRepository(private val dao: LocalAccountDao) {
    val account: Flow<LocalAccountEntity?> = dao.observeAccount()

    suspend fun createAccount(displayName: String, username: String, password: CharArray): CreateAccountResult {
        val name = displayName.trim()
        val user = username.trim().lowercase()
        if (name.length !in 2..48 || !user.matches(Regex("[a-z0-9._-]{3,32}")) || password.size < 8) {
            password.fill('\u0000')
            return CreateAccountResult.InvalidInput
        }
        return try {
            if (dao.findByUsername(user) != null) {
                CreateAccountResult.UsernameAlreadyExists
            } else {
                val credentials = withContext(Dispatchers.Default) { PasswordHasher.hash(password) }
                dao.insert(
                    LocalAccountEntity(
                        id = UUID.randomUUID().toString(),
                        displayName = name,
                        username = user,
                        passwordSalt = credentials.first,
                        passwordHash = credentials.second,
                        createdAtEpochMs = System.currentTimeMillis()
                    )
                )
                CreateAccountResult.Created
            }
        } catch (e: Exception) {
            CreateAccountResult.Failure(e.message ?: "خطای ناشناخته")
        } finally {
            password.fill('\u0000')
        }
    }
}
