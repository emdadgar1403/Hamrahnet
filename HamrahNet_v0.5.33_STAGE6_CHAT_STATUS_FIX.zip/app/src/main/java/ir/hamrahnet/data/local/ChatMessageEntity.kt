package ir.hamrahnet.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Locally persisted direct-chat message. Status is never set to SENT merely because it was queued. */
@Entity(
    tableName = "chat_messages",
    indices = [Index(value = ["peerFingerprint", "createdAtEpochMs"]), Index(value = ["peerFingerprint", "status"])]
)
data class ChatMessageEntity(
    @PrimaryKey val messageId: String,
    val peerFingerprint: String,
    val direction: String, // INCOMING or OUTGOING
    val body: String,
    val createdAtEpochMs: Long,
    val status: String, // QUEUED, SENDING, SENT, DELIVERED, READ, FAILED, RECEIVED
    val error: String? = null
)
