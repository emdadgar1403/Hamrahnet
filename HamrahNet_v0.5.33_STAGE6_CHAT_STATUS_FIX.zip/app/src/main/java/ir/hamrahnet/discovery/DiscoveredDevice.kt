package ir.hamrahnet.discovery

import java.net.InetAddress

data class DiscoveredDevice(
    val serviceName: String,
    val displayName: String,
    val username: String,
    val host: InetAddress,
    val port: Int,
    /** Separate listener for authenticated encrypted signaling. */
    val signalPort: Int,
    /** Advertised for UI filtering only; the cryptographic handshake verifies the actual key. */
    val advertisedFingerprint: String
) {
    val stableId: String get() = "$serviceName|${host.hostAddress}|$port"
}
