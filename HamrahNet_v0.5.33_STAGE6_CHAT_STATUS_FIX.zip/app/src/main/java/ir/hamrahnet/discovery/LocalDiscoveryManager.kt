package ir.hamrahnet.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/** NSD/mDNS discovery for _hamrahnet._tcp. */
class LocalDiscoveryManager(context: Context, private val onDevicesChanged: (List<DiscoveredDevice>) -> Unit) {
    companion object {
        const val SERVICE_TYPE = "_hamrahnet._tcp."
        private const val TAG = "HamrahNetNSD"
    }

    private val appContext = context.applicationContext
    private val nsd = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = appContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val running = AtomicBoolean(false)
    private val devices = linkedMapOf<String, DiscoveredDevice>()
    private val resolving = mutableSetOf<String>()
    private var multicastLock: WifiManager.MulticastLock? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    @Volatile private var restartAfterStop = false

    fun start(displayName: String, username: String, port: Int, fingerprint: String, signalPort: Int) {
        if (!running.compareAndSet(false, true)) return
        acquireMulticastLockIfNeeded()
        val service = NsdServiceInfo().apply {
            serviceName = "HamrahNet-${username.take(18)}-${fingerprint.take(8)}"
            serviceType = SERVICE_TYPE
            this.port = port

            setAttribute("v", "1")
            setAttribute("dn", displayName.take(48))
            setAttribute("un", username.take(32))
            setAttribute("fp", fingerprint)
            setAttribute("sp", signalPort.toString())

        }
        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                Log.i(TAG, "Service registered: ${serviceInfo.serviceName}")
            }
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "Service registration failed: $errorCode")
            }
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = Unit
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.w(TAG, "Service unregistration failed: $errorCode")
            }
        }
        try {
            nsd.registerService(service, NsdManager.PROTOCOL_DNS_SD, registrationListener!!)
        } catch (e: Exception) {
            Log.e(TAG, "Could not register NSD service", e)
        }
        beginDiscovery()
    }

    private fun beginDiscovery() {
        if (!running.get()) return
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {
                Log.i(TAG, "Discovery started: $serviceType")
            }
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (!serviceInfo.serviceType.trimEnd('.').equals(SERVICE_TYPE.trimEnd('.'), ignoreCase = true)) return
                val name = serviceInfo.serviceName ?: return
                synchronized(resolving) {
                    if (!resolving.add(name)) return
                }
                try {
                    @Suppress("DEPRECATION")
                    nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                            synchronized(resolving) { resolving.remove(info.serviceName) }
                            Log.w(TAG, "Resolve failed: ${info.serviceName} / $errorCode")
                        }
                        override fun onServiceResolved(info: NsdServiceInfo) {
                            synchronized(resolving) { resolving.remove(info.serviceName) }
                            val host = info.host ?: return
                            val attrs = info.attributes
                            val fingerprint = attrs["fp"]?.toString(Charsets.UTF_8).orEmpty()
                            val displayName = attrs["dn"]?.toString(Charsets.UTF_8).orEmpty().ifBlank { info.serviceName }
                            val username = attrs["un"]?.toString(Charsets.UTF_8).orEmpty()
                            val signalPort = attrs["sp"]?.toString(Charsets.UTF_8)?.toIntOrNull() ?: return
                            if (info.port !in 1..65535 || signalPort !in 1..65535 || fingerprint.isBlank()) return
                            val device = DiscoveredDevice(
                                info.serviceName, displayName, username, host, info.port, signalPort, fingerprint
                            )
                            synchronized(devices) {
                                devices[device.stableId] = device
                                publishDevices()
                            }
                        }
                    })
                } catch (e: Exception) {
                    synchronized(resolving) { resolving.remove(name) }
                    Log.w(TAG, "Resolve exception", e)
                }
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                synchronized(devices) {
                    devices.entries.removeAll { it.value.serviceName == serviceInfo.serviceName }
                    publishDevices()
                }
            }
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "Discovery start failed: $errorCode")
                try { nsd.stopServiceDiscovery(this) } catch (_: Exception) { }
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.w(TAG, "Discovery stop failed: $errorCode")
            }
            override fun onDiscoveryStopped(serviceType: String) {
                if (running.get() && restartAfterStop) {
                    restartAfterStop = false
                    beginDiscovery()
                }
            }
        }
        discoveryListener = listener
        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.e(TAG, "Could not start discovery", e)
        }
    }

    fun refresh() {
        synchronized(devices) { devices.clear(); publishDevices() }
        synchronized(resolving) { resolving.clear() }
        val old = discoveryListener
        if (old == null) {
            beginDiscovery()
        } else {
            restartAfterStop = true
            try {
                nsd.stopServiceDiscovery(old)
            } catch (_: Exception) {
                restartAfterStop = false
                beginDiscovery()
            }
        }
    }

    fun stop() {
        if (!running.compareAndSet(true, false)) return
        discoveryListener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) { } }
        discoveryListener = null
        restartAfterStop = false
        registrationListener?.let { try { nsd.unregisterService(it) } catch (_: Exception) { } }
        registrationListener = null
        synchronized(devices) { devices.clear(); publishDevices() }
        synchronized(resolving) { resolving.clear() }
        try {
            multicastLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) { }
        multicastLock = null
    }

    private fun acquireMulticastLockIfNeeded() {
        // Android 13+ with sufficiently recent T extensions manages foreground multicast reception.
        // On Android 13 and older, extension availability varies; hold a foreground-scoped lock for reliable mDNS reception.
        if (Build.VERSION.SDK_INT <= 33) {
            try {
                multicastLock = wifi.createMulticastLock("HamrahNet-mDNS").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not acquire multicast lock", e)
            }
        }
    }

    private fun publishDevices() {
        onDevicesChanged(devices.values.toList())
    }
}
