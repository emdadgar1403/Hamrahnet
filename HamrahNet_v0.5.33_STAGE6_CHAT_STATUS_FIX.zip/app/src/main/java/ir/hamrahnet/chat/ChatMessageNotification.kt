package ir.hamrahnet.chat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ir.hamrahnet.MainActivity

object ChatMessageNotification {
    private const val CHANNEL_ID = "hamrahnet_chat_messages"

    fun show(context: Context, peerFingerprint: String, peerName: String, body: String) {
        val app = context.applicationContext
        if (Build.VERSION.SDK_INT >= 33 && app.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        createChannel(app)
        val intent = Intent(app, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            action = "ir.hamrahnet.action.OPEN_CHAT"
            putExtra("ir.hamrahnet.extra.CHAT_PEER", peerFingerprint)
        }
        val pending = PendingIntent.getActivity(
            app, peerFingerprint.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(app, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle(peerName.take(80))
            .setContentText(body.take(180))
            .setStyle(NotificationCompat.BigTextStyle().bigText(body.take(500)))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(
                NotificationCompat.Builder(app, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.sym_action_chat)
                    .setContentTitle("پیام جدید همراه‌نت")
                    .setContentText("برای مشاهده، برنامه را باز کنید.")
                    .build()
            )
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        try { NotificationManagerCompat.from(app).notify(5300 + (peerFingerprint.hashCode() and 0x0fff), notification) }
        catch (_: SecurityException) { }
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "پیام‌های همراه‌نت", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "اعلان پیام‌های دریافتی از مخاطبان مورد اعتماد"
                setShowBadge(true)
            }
        )
    }
}
