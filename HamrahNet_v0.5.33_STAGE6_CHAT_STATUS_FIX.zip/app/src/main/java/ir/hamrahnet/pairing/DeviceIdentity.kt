package ir.hamrahnet.pairing

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec

/** Stable per-install signing identity. The private key never leaves Android Keystore. */
class DeviceIdentity {
    companion object {
        private const val KEYSTORE = "AndroidKeyStore"
        private const val ALIAS = "hamrahnet.device.identity.v1"
    }

    fun getOrCreateKeyPair(): KeyPair {
        val keyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        val existing = keyStore.getCertificate(ALIAS)
        if (existing != null) {
            val privateKey = keyStore.getKey(ALIAS, null) as java.security.PrivateKey
            return KeyPair(existing.publicKey, privateKey)
        }
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, KEYSTORE)
        generator.initialize(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
            )
                .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                .setDigests(KeyProperties.DIGEST_SHA256)
                .setUserAuthenticationRequired(false)
                .build()
        )
        return generator.generateKeyPair()
    }

    fun fingerprint(publicKeyBytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(publicKeyBytes)
            .joinToString("") { "%02x".format(it) }

    fun publicKeyBase64(pair: KeyPair): String =
        Base64.encodeToString(pair.public.encoded, Base64.NO_WRAP)

    fun sign(pair: KeyPair, payload: ByteArray): String {
        val signature = Signature.getInstance("SHA256withECDSA")
        signature.initSign(pair.private)
        signature.update(payload)
        return Base64.encodeToString(signature.sign(), Base64.NO_WRAP)
    }

    fun verify(publicKeyBytes: ByteArray, payload: ByteArray, signatureBase64: String): Boolean = try {
        val publicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(publicKeyBytes))
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(publicKey)
        verifier.update(payload)
        verifier.verify(Base64.decode(signatureBase64, Base64.NO_WRAP))
    } catch (_: Exception) {
        false
    }
}
