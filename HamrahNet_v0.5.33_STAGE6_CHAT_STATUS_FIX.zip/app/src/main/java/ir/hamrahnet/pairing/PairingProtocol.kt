package ir.hamrahnet.pairing

import android.util.Base64
import ir.hamrahnet.discovery.DiscoveredDevice
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyPair
import java.security.MessageDigest
import java.security.SecureRandom
import org.json.JSONObject

/**
 * One-time, human-verified pairing handshake. The six-digit SAS is derived from both public keys
 * and fresh nonces. Each identity signs its own hello. A peer is persisted only if both users
 * approve after comparing the same code on both devices.
 */
internal class PairingProtocol(private val identity: DeviceIdentity) {
    companion object {
        private const val PROTOCOL_VERSION = 1
        private const val MAX_LINE_BYTES = 16 * 1024
        private const val SOCKET_TIMEOUT_MS = 120_000
    }

    data class LocalIdentity(val displayName: String, val username: String, val keyPair: KeyPair) {
        val publicKeyBytes: ByteArray get() = keyPair.public.encoded
        val publicKeyBase64: String get() = Base64.encodeToString(publicKeyBytes, Base64.NO_WRAP)
        val fingerprint: String get() = identityFingerprint(publicKeyBytes)
        private fun identityFingerprint(bytes: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    }

    data class Result(val remote: RemoteIdentity, val sasCode: String)

    fun pairAsClient(
        device: DiscoveredDevice,
        local: LocalIdentity,
        decide: (RemoteIdentity, String) -> Boolean
    ): Result {
        Socket().use { socket ->
            socket.connect(InetSocketAddress(device.host, device.port), 7_000)
            socket.soTimeout = 10_000
            val input = socket.getInputStream()
            val output = socket.getOutputStream()
            sendHello(output, local)
            val remote = receiveHello(input)
            validateRemote(remote)
            if (device.advertisedFingerprint.isNotBlank()) {
                require(remote.fingerprint.equals(device.advertisedFingerprint, ignoreCase = true)) { "کلید هویت با دعوت‌نامه یا سرویس کشف‌شده مطابقت ندارد." }
            }
            val transcript = deriveTranscript(local, remote)
            sendTranscriptAuth(output, local, transcript.hashBase64)
            receiveTranscriptAuth(input, remote, transcript.hashBase64)
            socket.soTimeout = SOCKET_TIMEOUT_MS
            val acceptedHere = decide(remote, transcript.sasCode)
            sendDecision(output, acceptedHere, local, transcript.hashBase64)
            val acceptedThere = receiveDecision(input, remote, transcript.hashBase64)
            if (!acceptedHere || !acceptedThere) throw PairingRejectedException()
            return Result(remote, transcript.sasCode)
        }
    }

    fun pairAsServer(
        socket: Socket,
        local: LocalIdentity,
        decide: (RemoteIdentity, String) -> Boolean
    ): Result {
        socket.use {
            it.soTimeout = 10_000
            val input = it.getInputStream()
            val output = it.getOutputStream()
            val remote = receiveHello(input)
            validateRemote(remote)
            sendHello(output, local)
            val transcript = deriveTranscript(local, remote)
            receiveTranscriptAuth(input, remote, transcript.hashBase64)
            sendTranscriptAuth(output, local, transcript.hashBase64)
            it.soTimeout = SOCKET_TIMEOUT_MS
            val acceptedHere = decide(remote, transcript.sasCode)
            sendDecision(output, acceptedHere, local, transcript.hashBase64)
            val acceptedThere = receiveDecision(input, remote, transcript.hashBase64)
            if (!acceptedHere || !acceptedThere) throw PairingRejectedException()
            return Result(remote, transcript.sasCode)
        }
    }

    private fun sendHello(output: OutputStream, local: LocalIdentity) {
        val nonce = ByteArray(32).also { SecureRandom().nextBytes(it) }
        rememberLocalNonce(nonce)
        val nonce64 = Base64.encodeToString(nonce, Base64.NO_WRAP)
        val signaturePayload = signedHelloPayload(local.username, local.displayName, nonce64)
        val signature = identity.sign(local.keyPair, signaturePayload)
        val json = JSONObject()
            .put("type", "hello")
            .put("protocol", PROTOCOL_VERSION)
            .put("displayName", local.displayName.take(48))
            .put("username", local.username.take(32))
            .put("publicKey", local.publicKeyBase64)
            .put("nonce", nonce64)
            .put("signature", signature)
        writeLine(output, json)
    }

    private fun receiveHello(input: InputStream): RemoteIdentity {
        val json = readLine(input)
        require(json.optString("type") == "hello") { "پیام آغاز ارتباط نامعتبر است." }
        require(json.optInt("protocol", -1) == PROTOCOL_VERSION) { "نسخه پروتکل دو دستگاه یکسان نیست." }
        val displayName = json.getString("displayName").take(48)
        val username = json.getString("username").take(32)
        val key64 = json.getString("publicKey")
        val nonce64 = json.getString("nonce")
        val signature = json.getString("signature")
        val keyBytes = Base64.decode(key64, Base64.NO_WRAP)
        val nonce = Base64.decode(nonce64, Base64.NO_WRAP)
        require(keyBytes.size in 64..256 && nonce.size == 32) { "اطلاعات هویت نامعتبر است." }
        require(username.matches(Regex("[a-z0-9._-]{3,32}"))) { "شناسه دستگاه نامعتبر است." }
        require(displayName.isNotBlank()) { "نام دستگاه نامعتبر است." }
        val payload = signedHelloPayload(username, displayName, nonce64)
        require(identity.verify(keyBytes, payload, signature)) { "امضای هویت دستگاه معتبر نیست." }
        return RemoteIdentity(
            displayName = displayName,
            username = username,
            publicKeyBase64 = key64,
            publicKeyBytes = keyBytes,
            fingerprint = identity.fingerprint(keyBytes),
            nonce = nonce
        )
    }

    private fun validateRemote(remote: RemoteIdentity) {
        // Pairing a device with the same key is almost certainly an accidental self-connection.
        // The SAS transcript also rejects equal fingerprints explicitly.
        require(remote.fingerprint.isNotBlank()) { "اثر انگشت کلید نامعتبر است." }
    }

    private data class PairingTranscript(val sasCode: String, val hashBase64: String)

    private fun deriveTranscript(local: LocalIdentity, remote: RemoteIdentity): PairingTranscript {
        require(local.fingerprint != remote.fingerprint) { "نمی‌توان دستگاه را با خودش جفت کرد." }
        val localNonce = findLocalNonceNotAvailableHere()
        val entries = listOf(local.fingerprint to localNonce, remote.fingerprint to remote.nonce).sortedBy { it.first }
        val canonical = buildString {
            append("HamrahNet-SAS-v1\n")
            entries.forEach { (fp, nonce) ->
                append(fp).append('\n')
                append(Base64.encodeToString(nonce, Base64.NO_WRAP)).append('\n')
            }
        }.toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256").digest(canonical)
        val number = BigInteger(1, digest.copyOfRange(0, 4)).mod(BigInteger.valueOf(1_000_000L)).toInt()
        return PairingTranscript(number.toString().padStart(6, '0'), Base64.encodeToString(digest, Base64.NO_WRAP))
    }

    /* Local hello nonce is stored per thread so both sides derive the same canonical transcript. */
    private val localNonceByThread = ThreadLocal<ByteArray>()

    private fun findLocalNonceNotAvailableHere(): ByteArray =
        localNonceByThread.get() ?: throw IllegalStateException("Local pairing nonce was not initialized")

    private fun sendTranscriptAuth(output: OutputStream, local: LocalIdentity, transcriptHash: String) {
        val payload = "HamrahNet-Transcript-Auth-v1\n$transcriptHash".toByteArray(Charsets.UTF_8)
        val signature = identity.sign(local.keyPair, payload)
        writeLine(output, JSONObject().put("type", "transcript_auth").put("signature", signature))
    }

    private fun receiveTranscriptAuth(input: InputStream, remote: RemoteIdentity, transcriptHash: String) {
        val json = readLine(input)
        require(json.optString("type") == "transcript_auth") { "تأیید رمزنگاری‌شده هویت دریافت نشد." }
        val payload = "HamrahNet-Transcript-Auth-v1\n$transcriptHash".toByteArray(Charsets.UTF_8)
        require(identity.verify(remote.publicKeyBytes, payload, json.getString("signature"))) {
            "تأیید هویت برای این نشست معتبر نیست."
        }
    }

    private fun sendDecision(output: OutputStream, accepted: Boolean, local: LocalIdentity, transcriptHash: String) {
        val payload = decisionPayload(transcriptHash, accepted)
        val signature = identity.sign(local.keyPair, payload)
        writeLine(output, JSONObject().put("type", "decision").put("accept", accepted).put("signature", signature))
    }

    private fun receiveDecision(input: InputStream, remote: RemoteIdentity, transcriptHash: String): Boolean {
        val json = readLine(input)
        require(json.optString("type") == "decision") { "پاسخ جفت‌سازی نامعتبر است." }
        val accepted = json.optBoolean("accept", false)
        val signature = json.getString("signature")
        require(identity.verify(remote.publicKeyBytes, decisionPayload(transcriptHash, accepted), signature)) {
            "امضای پاسخ جفت‌سازی معتبر نیست."
        }
        return accepted
    }

    private fun decisionPayload(transcriptHash: String, accepted: Boolean): ByteArray =
        "HamrahNet-Decision-v1\n$transcriptHash\n$accepted".toByteArray(Charsets.UTF_8)

    private fun signedHelloPayload(username: String, displayName: String, nonce64: String): ByteArray =
        "HamrahNet-Hello-v1\n$PROTOCOL_VERSION\n$username\n$displayName\n$nonce64".toByteArray(Charsets.UTF_8)

    private fun writeLine(output: OutputStream, json: JSONObject) {
        val bytes = (json.toString() + "\n").toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_LINE_BYTES) { "پیام بیش از اندازه بزرگ است." }
        output.write(bytes)
        output.flush()
    }

    private fun readLine(input: InputStream): JSONObject {
        val buffer = ByteArrayOutputStream()
        while (true) {
            val next = input.read()
            if (next == -1) throw java.io.EOFException("ارتباط پیش از تکمیل پیام بسته شد.")
            if (next == '\n'.code) break
            if (buffer.size() >= MAX_LINE_BYTES) throw IllegalArgumentException("پیام بیش از اندازه بزرگ است.")
            if (next != '\r'.code) buffer.write(next)
        }
        return JSONObject(buffer.toString(Charsets.UTF_8.name()))
    }

    class PairingRejectedException : Exception("جفت‌سازی توسط یکی از کاربران رد شد.")

    // Called by sendHello before writing so the nonce used for signing is also used in the SAS.
    private fun rememberLocalNonce(nonce: ByteArray) { localNonceByThread.set(nonce) }
}
