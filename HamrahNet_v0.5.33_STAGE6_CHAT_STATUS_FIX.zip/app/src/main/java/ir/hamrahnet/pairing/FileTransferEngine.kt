package ir.hamrahnet.pairing

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.util.Base64
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal object FileTransferEngine {
    const val MAX_FILE_SIZE: Long = 2L * 1024L * 1024L * 1024L
    private const val BUFFER_SIZE = 64 * 1024
    private const val GCM_IV_SIZE = 12

    data class ReceiveResult(val savedPath: String, val bytes: Long)

    fun newKey(): ByteArray = ByteArray(32).also { SecureRandom().nextBytes(it) }

    fun keyToBase64(key: ByteArray): String = Base64.encodeToString(key, Base64.NO_WRAP)
    fun keyFromBase64(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP).also {
        require(it.size == 32) { "کلید انتقال فایل نامعتبر است." }
    }

    suspend fun sha256Uri(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        } ?: throw IllegalArgumentException("فایل انتخاب‌شده قابل خواندن نیست.")
        digest.digest().joinToString("") { "%02x".format(it) }
    }

    suspend fun send(
        context: Context,
        uri: Uri,
        host: InetAddress,
        port: Int,
        key: ByteArray,
        expectedSize: Long,
        onProgress: (Long) -> Unit
    ) = withContext(Dispatchers.IO) {
        require(expectedSize in 0..MAX_FILE_SIZE) { "حداکثر اندازه فایل ۲ گیگابایت است." }
        Socket().use { socket ->
            socket.connect(java.net.InetSocketAddress(host, port), 10_000)
            socket.soTimeout = 120_000
            val iv = ByteArray(GCM_IV_SIZE).also { SecureRandom().nextBytes(it) }
            val output = BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE)
            output.write(iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(BUFFER_SIZE)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    val encrypted = cipher.update(buffer, 0, count)
                    if (encrypted != null && encrypted.isNotEmpty()) output.write(encrypted)
                    total += count
                    if (total > expectedSize || total > MAX_FILE_SIZE) {
                        throw IllegalStateException("اندازه فایل هنگام ارسال تغییر کرده است.")
                    }
                    onProgress(total)
                }
                require(total == expectedSize) { "اندازه فایل هنگام ارسال تغییر کرده است." }
            } ?: throw IllegalArgumentException("فایل انتخاب‌شده قابل خواندن نیست.")
            val finalBytes = cipher.doFinal()
            if (finalBytes.isNotEmpty()) output.write(finalBytes)
            output.flush()
            // Half-close only the sending direction so the receiver can return a verified result.
            socket.shutdownOutput()
            val acknowledgement = DataInputStream(socket.getInputStream()).readUTF()
            if (acknowledgement != "OK") {
                val detail = acknowledgement.removePrefix("ERR:").take(240)
                throw IOException("گیرنده فایل را تأیید نکرد: $detail")
            }
        }
    }

    fun receive(
        context: Context,
        server: ServerSocket,
        key: ByteArray,
        expectedSize: Long,
        expectedSha256: String,
        requestedName: String,
        onProgress: (Long) -> Unit
    ): ReceiveResult {
        val temp = File(context.cacheDir, "incoming-${System.nanoTime()}.part")
        try {
            server.soTimeout = 120_000
            var receiveResult: ReceiveResult? = null
            server.use { listening ->
                listening.accept().use { socket ->
                    socket.soTimeout = 120_000
                    val raw = BufferedInputStream(socket.getInputStream(), BUFFER_SIZE)
                    val iv = ByteArray(GCM_IV_SIZE)
                    var offset = 0
                    while (offset < iv.size) {
                        val count = raw.read(iv, offset, iv.size - offset)
                        if (count < 0) throw java.io.EOFException("انتقال فایل پیش از شروع کامل نشد.")
                        offset += count
                    }
                    try {
                        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
                        val digest = MessageDigest.getInstance("SHA-256")
                        var total = 0L
                        BufferedOutputStream(FileOutputStream(temp), BUFFER_SIZE).use { output ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            while (true) {
                                val count = raw.read(buffer)
                                if (count < 0) break
                                val plain = cipher.update(buffer, 0, count)
                                if (plain != null && plain.isNotEmpty()) {
                                    total += plain.size
                                    if (total > expectedSize || total > MAX_FILE_SIZE) {
                                        throw IllegalStateException("اندازه داده دریافتی بیشتر از مقدار اعلام‌شده است.")
                                    }
                                    digest.update(plain)
                                    output.write(plain)
                                    onProgress(total)
                                }
                            }
                            // doFinal verifies the AES-GCM authentication tag. Truncated/corrupt
                            // streams fail here and must never be reported as successful.
                            val finalPlain = cipher.doFinal()
                            if (finalPlain.isNotEmpty()) {
                                total += finalPlain.size
                                if (total > expectedSize || total > MAX_FILE_SIZE) {
                                    throw IllegalStateException("اندازه داده دریافتی بیشتر از مقدار اعلام‌شده است.")
                                }
                                digest.update(finalPlain)
                                output.write(finalPlain)
                                onProgress(total)
                            }
                        }
                        require(total == expectedSize) { "فایل دریافتی ناقص است؛ اندازه فایل مطابقت ندارد." }
                        val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
                        require(actualHash.equals(expectedSha256, ignoreCase = true)) {
                            "بررسی صحت فایل ناموفق بود؛ فایل ذخیره نشد."
                        }
                        val savedPath = saveToDownloads(context, temp, safeName(requestedName))
                        receiveResult = ReceiveResult(savedPath, temp.length())
                        // Only acknowledge success after authentication, hash validation, and save.
                        try {
                            DataOutputStream(socket.getOutputStream()).apply {
                                writeUTF("OK")
                                flush()
                            }
                        } catch (_: Exception) {
                            // The file is already verified and saved; do not label it incomplete
                            // solely because the peer disappeared before receiving the ACK.
                        }
                    } catch (e: Exception) {
                        try {
                            DataOutputStream(socket.getOutputStream()).apply {
                                writeUTF("ERR:${(e.message ?: "انتقال ناقص است").take(240)}")
                                flush()
                            }
                        } catch (_: Exception) { }
                        throw e
                    }
                }
            }
            return receiveResult ?: throw IOException("نتیجه دریافت فایل ثبت نشد.")
        } finally {
            temp.delete()
        }
    }

    private fun safeName(name: String): String {
        val clean = name.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\u0000-\\u001F\\\\/:*?\"<>|]"), "_")
            .trim().take(180)
        return clean.ifBlank { "hamrahnet-file" }
    }

    private fun saveToDownloads(context: Context, source: File, fileName: String): String {
        // A user-selected SAF folder takes precedence over the default Downloads location.
        val prefs = context.getSharedPreferences("hamrahnet_preferences", Context.MODE_PRIVATE)
        val selectedTree = prefs.getString("received_folder_uri", null)?.takeIf { it.isNotBlank() }
        if (selectedTree != null) {
            val treeUri = Uri.parse(selectedTree)
            val mimeType = "application/octet-stream"
            val documentUri = try {
                DocumentsContract.createDocument(
                    context.contentResolver,
                    DocumentsContract.buildDocumentUriUsingTree(
                        treeUri,
                        DocumentsContract.getTreeDocumentId(treeUri)
                    ),
                    mimeType,
                    fileName
                )
            } catch (e: Exception) {
                throw IOException("ذخیره در پوشه انتخاب‌شده ناموفق بود؛ لطفاً پوشه را دوباره انتخاب کنید.", e)
            } ?: throw IOException("ساخت فایل در پوشه انتخاب‌شده ناموفق بود.")
            try {
                context.contentResolver.openOutputStream(documentUri, "w")?.use { output ->
                    FileInputStream(source).use { input -> input.copyTo(output, BUFFER_SIZE) }
                } ?: throw IOException("نوشتن فایل در پوشه انتخاب‌شده ناموفق بود.")
                return documentUri.toString()
            } catch (e: Exception) {
                try { DocumentsContract.deleteDocument(context.contentResolver, documentUri) } catch (_: Exception) { }
                if (e is IOException) throw e
                throw IOException("نوشتن فایل در پوشه انتخاب‌شده ناموفق بود.", e)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HamrahNet")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("ساخت فایل در پوشه Downloads ناموفق بود.")
            try {
                context.contentResolver.openOutputStream(uri)?.use { output -> FileInputStream(source).use { it.copyTo(output, BUFFER_SIZE) } }
                    ?: throw IllegalStateException("نوشتن فایل دریافتی ناموفق بود.")
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                return "Downloads/HamrahNet/$fileName"
            } catch (e: Exception) {
                context.contentResolver.delete(uri, null, null)
                throw e
            }
        }
        val folder = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "HamrahNet")
        if (!folder.exists() && !folder.mkdirs()) throw IllegalStateException("ساخت پوشه مقصد ناموفق بود.")
        val target = File(folder, fileName)
        FileInputStream(source).use { input -> FileOutputStream(target).use { input.copyTo(it, BUFFER_SIZE) } }
        return target.absolutePath
    }
}
