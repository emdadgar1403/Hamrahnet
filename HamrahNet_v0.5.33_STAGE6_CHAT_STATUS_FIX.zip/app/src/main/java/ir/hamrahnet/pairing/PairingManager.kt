package ir.hamrahnet.pairing

import android.content.Context
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import ir.hamrahnet.MainActivity
import ir.hamrahnet.HamrahNetApplication
import ir.hamrahnet.chat.ChatMessageNotification
import ir.hamrahnet.security.ChatMessageCrypto
import android.net.Uri
import android.database.Cursor
import android.provider.OpenableColumns
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.content.ContextCompat
import ir.hamrahnet.service.HamrahNetService
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import ir.hamrahnet.data.local.TrustedPeerDao
import ir.hamrahnet.data.local.ChatMessageDao
import ir.hamrahnet.data.local.ChatMessageEntity
import ir.hamrahnet.data.local.TrustedPeerEntity
import ir.hamrahnet.call.LocalVoiceCallEngine
import ir.hamrahnet.call.IncomingCallNotification
import ir.hamrahnet.discovery.DiscoveredDevice
import ir.hamrahnet.discovery.LocalDiscoveryManager
import ir.hamrahnet.signaling.SecureSignalingProtocol
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import org.json.JSONObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.runBlocking

data class IncomingFileOffer(
    val id: String,
    val device: DiscoveredDevice,
    val fileName: String,
    val sizeBytes: Long
)

private data class PendingFileDecision(
    val offer: IncomingFileOffer,
    val latch: CountDownLatch,
    val server: ServerSocket,
    val key: ByteArray,
    @Volatile var accepted: Boolean = false
)

data class IncomingVoiceCall(
    val device: DiscoveredDevice,
    val offerSdp: String,
    val isVideo: Boolean = false
)

data class VoiceCallUiState(
    val engineState: LocalVoiceCallEngine.State = LocalVoiceCallEngine.State.IDLE,
    val status: String = "تماس صوتی آماده است.",
    val peer: DiscoveredDevice? = null,
    val incoming: IncomingVoiceCall? = null,
    val muted: Boolean = false,
    val isVideo: Boolean = false,
    val cameraEnabled: Boolean = true
)

class PairingManager(context: Context, private val peerDao: TrustedPeerDao, private val chatDao: ChatMessageDao) {
    companion object {
        private const val TAG = "HamrahNetPairing"
        const val PAIRING_PORT = 43871
        const val SIGNAL_PORT = 43872
        private const val ENDPOINT_PROBE_INTERVAL_MS = 15_000L
    }

    private val appContext = context.applicationContext
    private val identity = DeviceIdentity()
    private val protocol = PairingProtocol(identity)
    private val secureSignaling = SecureSignalingProtocol(identity, peerDao)
    private val running = AtomicBoolean(false)
    private val sessionBusy = AtomicBoolean(false)
    private val activeSockets = ConcurrentHashMap.newKeySet<Socket>()
    private val activeSignalSockets = ConcurrentHashMap.newKeySet<Socket>()
    private val decisions = ConcurrentHashMap<String, PendingDecision>()
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var signalServerSocket: ServerSocket? = null
    @Volatile private var executor: ExecutorService? = null
    @Volatile private var localIdentity: PairingProtocol.LocalIdentity? = null
    @Volatile private var discovery: LocalDiscoveryManager? = null
    @Volatile private var lastDisplayName: String? = null
    @Volatile private var lastUsername: String? = null
    @Volatile private var endpointProbeJob: Job? = null
    @Volatile private var trustedPeersJob: Job? = null
    private val trustedFingerprints = ConcurrentHashMap.newKeySet<String>()
    private val inFlightChatIds = ConcurrentHashMap.newKeySet<String>()
    private val mdnsDevices = ConcurrentHashMap<String, DiscoveredDevice>()
    private val reachableEndpointDevices = ConcurrentHashMap<String, DiscoveredDevice>()

    private val _devices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val devices: StateFlow<List<DiscoveredDevice>> = _devices.asStateFlow()

    private val _pendingPrompt = MutableStateFlow<PairingPrompt?>(null)
    val pendingPrompt: StateFlow<PairingPrompt?> = _pendingPrompt.asStateFlow()

    private val _status = MutableStateFlow("برای ارتباط مستقیم، VPN یا شبکهٔ محلی را وصل کنید؛ همتایان قبلی بدون مدیر مرکزی قابل اتصال‌اند.")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _voiceCall = MutableStateFlow(VoiceCallUiState())
    private val _incomingFileOffer = MutableStateFlow<IncomingFileOffer?>(null)
    val incomingFileOffer: StateFlow<IncomingFileOffer?> = _incomingFileOffer.asStateFlow()
    private val _fileTransferStatus = MutableStateFlow("انتقال فایل آماده است.")
    val fileTransferStatus: StateFlow<String> = _fileTransferStatus.asStateFlow()
    private val pendingFileDecisions = ConcurrentHashMap<String, PendingFileDecision>()
    val voiceCall: StateFlow<VoiceCallUiState> = _voiceCall.asStateFlow()
    private val callScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var voiceEngine: LocalVoiceCallEngine? = null
    @Volatile private var callPeer: DiscoveredDevice? = null
    @Volatile private var callRole: String? = null
    @Volatile private var callIsVideo: Boolean = false
    @Volatile private var callStateJob: Job? = null
    @Volatile private var ringTone: Ringtone? = null
    @Volatile private var ringbackToneGenerator: ToneGenerator? = null
    private val ringHandler = Handler(Looper.getMainLooper())
    private var ringbackRunnable: Runnable? = null

    val trustedPeers = peerDao.observeAll()

    /** Local IPv4/IPv6 addresses, preferring VPN interfaces for cross-network invitations. */
    fun localAddressCandidates(): List<String> {
        data class Candidate(val priority: Int, val address: java.net.InetAddress)
        val connectivity = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val candidates = connectivity.allNetworks.flatMap { network ->
            val capabilities = connectivity.getNetworkCapabilities(network) ?: return@flatMap emptyList()
            val priority = when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> 0
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
                else -> 2
            }
            val properties = connectivity.getLinkProperties(network) ?: return@flatMap emptyList()
            properties.linkAddresses.map { it.address }
                .filter { !it.isLoopbackAddress && !it.isAnyLocalAddress && !it.isLinkLocalAddress }
                .map { Candidate(priority, it) }
        }
        return candidates.sortedWith(
            compareBy<Candidate> { it.priority }.thenByDescending { it.address is java.net.Inet4Address }
        ).map { it.address.hostAddress.substringBefore('%') }.distinct()
    }

    /** Build a signed-identity-pinned invitation payload for a selected local/VPN address. */
    fun createInviteUri(hostAddress: String): String? {
        val local = localIdentity ?: return null
        if (hostAddress.isBlank()) return null
        return Uri.Builder()
            .scheme("hamrahnet")
            .authority("pair")
            .appendQueryParameter("host", hostAddress)
            .appendQueryParameter("port", PAIRING_PORT.toString())
            .appendQueryParameter("signalPort", SIGNAL_PORT.toString())
            .appendQueryParameter("fp", local.fingerprint)
            .appendQueryParameter("name", local.displayName)
            .appendQueryParameter("username", local.username)
            .build().toString()
    }

    /** Import a HamrahNet QR invitation. The QR fingerprint is pinned before SAS approval. */
    fun pairFromInvite(inviteText: String): Boolean {
        return try {
            val uri = Uri.parse(inviteText.trim())
            require(uri.scheme == "hamrahnet" && uri.authority == "pair") { "این QR دعوت‌نامهٔ معتبر همراه‌نت نیست." }
            val host = uri.getQueryParameter("host").orEmpty()
            val pairingPort = uri.getQueryParameter("port")?.toIntOrNull() ?: PAIRING_PORT
            val signalPort = uri.getQueryParameter("signalPort")?.toIntOrNull() ?: SIGNAL_PORT
            val fingerprint = uri.getQueryParameter("fp").orEmpty()
            require(host.isNotBlank()) { "آدرس دستگاه در QR وجود ندارد." }
            require(pairingPort in 1..65535 && signalPort in 1..65535) { "درگاه‌های دعوت‌نامه نامعتبرند." }
            if (fingerprint.isNotBlank()) require(fingerprint.matches(Regex("[0-9a-fA-F]{64}"))) { "اثر انگشت QR نامعتبر است." }
            pairByAddress(host, pairingPort, signalPort, fingerprint)
        } catch (e: Exception) {
            _status.value = e.message ?: "خواندن QR ناموفق بود."
            false
        }
    }

    /** Pair directly over a reachable VPN/LAN IP without relying on mDNS or a central server. */
    fun pairByAddress(hostText: String, pairingPort: Int = PAIRING_PORT, signalPort: Int = SIGNAL_PORT, expectedFingerprint: String = ""): Boolean {
        return try {
            val host = hostText.trim().removePrefix("[").removeSuffix("]")
            require(host.isNotBlank()) { "آدرس IP دستگاه مقابل را وارد کنید." }
            val ipv4 = host.matches(Regex("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) &&
                host.split('.').all { it.toIntOrNull() in 0..255 }
            val ipv6 = host.contains(':') && host.matches(Regex("[0-9a-fA-F:.]+"))
            require(ipv4 || ipv6) { "فقط آدرس IP وارد کنید؛ نام دامنه پذیرفته نمی‌شود." }
            require(pairingPort in 1..65535 && signalPort in 1..65535) { "درگاه شبکه نامعتبر است." }
            val address = java.net.InetAddress.getByName(host)
            if (!running.get()) {
                _status.value = "سرویس همراه‌نت هنوز فعال نیست؛ چند ثانیه صبر کنید و دوباره تلاش کنید."
                return false
            }
            val device = DiscoveredDevice(
                serviceName = "HamrahNet-Manual-${address.hostAddress}",
                displayName = "دستگاه ${address.hostAddress}",
                username = "manual",
                host = address,
                port = pairingPort,
                signalPort = signalPort,
                advertisedFingerprint = expectedFingerprint
            )
            pair(device)
        } catch (e: Exception) {
            _status.value = e.message ?: "آدرس IP معتبر نیست."
            false
        }
    }

    /** Removes a locally trusted peer; future secure signaling must be paired again. */
    fun forgetTrustedPeer(fingerprint: String) {
        callScope.launch {
            peerDao.deleteByFingerprint(fingerprint)
            reachableEndpointDevices.keys.removeAll { it.equals(fingerprint, ignoreCase = true) }
            trustedFingerprints.remove(fingerprint.lowercase())
            publishMergedDevices()
        }
    }

    @Synchronized
    fun start(displayName: String, username: String) {
        lastDisplayName = displayName
        lastUsername = username
        if (running.get()) return

        var createdPairingServer: ServerSocket? = null
        var createdSignalServer: ServerSocket? = null
        try {
            val keyPair = identity.getOrCreateKeyPair()
            val local = PairingProtocol.LocalIdentity(displayName, username, keyPair)
            // Bind wildcard sockets so Android can route inbound connections over Wi-Fi or VPN.
            // Stable ports make IP-only enrollment possible without a directory service.
            createdPairingServer = ServerSocket().apply {
                reuseAddress = true
                bind(java.net.InetSocketAddress(PAIRING_PORT))
                soTimeout = 1_000
            }
            createdSignalServer = ServerSocket().apply {
                reuseAddress = true
                bind(java.net.InetSocketAddress(SIGNAL_PORT))
                soTimeout = 1_000
            }

            localIdentity = local
            serverSocket = createdPairingServer
            signalServerSocket = createdSignalServer
            executor = Executors.newCachedThreadPool { runnable ->
                Thread(runnable, "HamrahNet-network").apply { isDaemon = true }
            }
            running.set(true)
            startTrustedPeerObserver()
            callScope.launch(Dispatchers.IO) { migrateLegacyChatBodies() }
            val localExecutor = executor ?: error("Executor not initialized")
            localExecutor.execute { acceptLoop(createdPairingServer!!) }
            localExecutor.execute { secureAcceptLoop(createdSignalServer!!) }

            val discoveryManager = LocalDiscoveryManager(appContext) { found ->
                mdnsDevices.clear()
                found.filter { it.advertisedFingerprint != local.fingerprint }
                    .forEach { mdnsDevices[it.stableId] = it }
                publishMergedDevices()
            }
            discovery = discoveryManager
            discoveryManager.start(
                displayName = displayName,
                username = username,
                port = createdPairingServer!!.localPort,
                fingerprint = local.fingerprint,
                signalPort = createdSignalServer!!.localPort
            )
            startEndpointProbeLoop()
            _status.value = "سرویس مستقیم شبکه فعال است؛ کشف محلی و اتصال از طریق IP/VPN آماده‌اند."
        } catch (e: Exception) {
            Log.e(TAG, "Could not start local pairing/signaling service", e)
            stop()
            try { createdPairingServer?.close() } catch (_: Exception) { }
            try { createdSignalServer?.close() } catch (_: Exception) { }
            serverSocket = null
            signalServerSocket = null
            _status.value = "راه‌اندازی شبکه ناموفق بود: ${friendlyError(e)}"
        }
    }

    @Synchronized
    fun stop() {
        if (!running.getAndSet(false)) return
        endpointProbeJob?.cancel()
        endpointProbeJob = null
        trustedPeersJob?.cancel()
        trustedPeersJob = null
        trustedFingerprints.clear()
        discovery?.stop()
        discovery = null
        mdnsDevices.clear()
        reachableEndpointDevices.clear()
        try { serverSocket?.close() } catch (_: Exception) { }
        serverSocket = null
        try { signalServerSocket?.close() } catch (_: Exception) { }
        signalServerSocket = null
        activeSockets.toList().forEach { try { it.close() } catch (_: Exception) { } }
        activeSockets.clear()
        activeSignalSockets.toList().forEach { try { it.close() } catch (_: Exception) { } }
        activeSignalSockets.clear()
        decisions.values.forEach { it.accepted.set(false); it.latch.countDown() }
        decisions.clear()
        _pendingPrompt.value = null
        localIdentity = null
        _devices.value = emptyList()
        callStateJob?.cancel()
        callStateJob = null
        stopRinging()
        try { voiceEngine?.release() } catch (_: Exception) { }
        voiceEngine = null
        callPeer = null
        callRole = null
        _voiceCall.value = VoiceCallUiState(status = "سرویس شبکه متوقف شد.")
        executor?.shutdownNow()
        executor = null
        _status.value = "کشف دستگاه‌ها متوقف شد."
    }

    fun refreshDiscovery() {
        val name = lastDisplayName
        val user = lastUsername
        if (name == null || user == null) {
            _status.value = "ابتدا یک حساب محلی بسازید."
            return
        }
        if (sessionBusy.get()) {
            _status.value = "هنگام جفت‌سازی نمی‌توان سرویس شبکه را بازنشانی کرد. ابتدا درخواست جاری را تمام یا رد کنید."
            return
        }
        val local = localIdentity
        if (!running.get() || local == null) {
            start(name, user)
            return
        }
        // Listener sockets are bound to wildcard addresses; only restart NSD here so VPN changes
        // do not tear down the authenticated service or interrupt an active call.
        discovery?.stop()
        val manager = LocalDiscoveryManager(appContext) { found ->
            mdnsDevices.clear()
            found.filter { it.advertisedFingerprint != local.fingerprint }
                .forEach { mdnsDevices[it.stableId] = it }
            publishMergedDevices()
        }
        discovery = manager
        manager.start(name, user, serverSocket?.localPort ?: PAIRING_PORT, local.fingerprint,
            signalServerSocket?.localPort ?: SIGNAL_PORT)
        _status.value = "جست‌وجوی محلی تازه شد؛ اتصال‌های مستقیم VPN حفظ شده‌اند."
        callScope.launch(Dispatchers.IO) { probeTrustedPeersNow() }
    }

    fun pair(device: DiscoveredDevice): Boolean {
        val local = localIdentity
        val pool = executor
        if (!running.get() || local == null || pool == null) {
            _status.value = "ابتدا سرویس شبکه را فعال کنید."
            return false
        }
        if (!sessionBusy.compareAndSet(false, true)) {
            _status.value = "یک فرایند جفت‌سازی در حال انجام است؛ ابتدا آن را تمام کنید."
            return false
        }
        try { pool.execute {
            try {
                _status.value = "در حال اتصال امن به ${device.displayName}…"
                val result = protocol.pairAsClient(device, local) { remote, sas ->
                    awaitUserDecision(remote, sas, PairingDirection.OUTGOING, "${device.host.hostAddress}:${device.port}")
                }
                saveTrustedPeer(result.remote, device.host.hostAddress, device.port, device.signalPort)
                val trustedDevice = device.copy(
                    serviceName = "HamrahNet-${result.remote.username}-${result.remote.fingerprint.take(8)}",
                    displayName = result.remote.displayName,
                    username = result.remote.username,
                    advertisedFingerprint = result.remote.fingerprint
                )
                reachableEndpointDevices[result.remote.fingerprint] = trustedDevice
                publishMergedDevices()
                _status.value = "جفت‌سازی با ${result.remote.displayName} با تأیید دوطرفه انجام شد."
            } catch (e: PairingProtocol.PairingRejectedException) {
                _status.value = "جفت‌سازی رد شد یا در زمان مقرر تأیید نشد."
            } catch (e: Exception) {
                _status.value = "جفت‌سازی انجام نشد: ${friendlyError(e)}"
                Log.w(TAG, "Outgoing pairing failed", e)
            } finally {
                sessionBusy.set(false)
            }
        } } catch (e: Exception) {
            sessionBusy.set(false)
            _status.value = "شروع جفت‌سازی ناموفق بود: ${friendlyError(e)}"
            return false
        }
        return true
    }

    /** Test the encrypted Phase 3 signaling channel with a previously paired device. */
    fun testSecureChannel(device: DiscoveredDevice) {
        val local = localIdentity
        val pool = executor
        if (!running.get() || local == null || pool == null) {
            _status.value = "ابتدا سرویس شبکه محلی را فعال کنید."
            return
        }
        if (sessionBusy.get()) {
            _status.value = "هنگام جفت‌سازی، آزمایش کانال امن را انجام ندهید."
            return
        }
        pool.execute {
            try {
                _status.value = "در حال برقراری کانال رمزنگاری‌شده با ${device.displayName}…"
                val localSignalPort = signalServerSocket?.localPort
                    ?: throw IOException("کانال امن محلی فعال نیست.")
                _status.value = secureSignaling.ping(device, local, localSignalPort)
            } catch (e: Exception) {
                _status.value = "آزمایش کانال امن ناموفق بود: ${friendlyError(e)}"
                Log.w(TAG, "Secure signaling probe failed", e)
            }
        }
    }

    fun startOutgoingVoiceCall(device: DiscoveredDevice) = startOutgoingCall(device, false)

    fun startOutgoingVideoCall(device: DiscoveredDevice) = startOutgoingCall(device, true)

    private fun startOutgoingCall(device: DiscoveredDevice, video: Boolean) {
        val local = localIdentity
        if (!running.get() || local == null) {
            _voiceCall.value = _voiceCall.value.copy(status = "ابتدا سرویس شبکه محلی را فعال کنید.")
            return
        }
        if (voiceEngine != null || _voiceCall.value.incoming != null) {
            _voiceCall.value = _voiceCall.value.copy(status = "تماس دیگری در حال اجرا یا انتظار است.")
            return
        }
        callPeer = device
        callRole = "outgoing"
        callIsVideo = video
        Log.i(TAG, "CALL_DIAG role=caller action=start peer=${device.displayName} video=$video fingerprint=${device.advertisedFingerprint.take(12)}")
        startOutgoingRingback() // simple local beep; selected ringtone is only for incoming calls
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            HamrahNetService.setCallActive(appContext, true)
        }
        _voiceCall.value = VoiceCallUiState(
            engineState = LocalVoiceCallEngine.State.PREPARING,
            status = if (video) "در حال آماده‌سازی تماس تصویری با ${device.displayName}…" else "در حال آماده‌سازی تماس با ${device.displayName}…",
            peer = device,
            isVideo = video
        )
        try {
            val engine = createVoiceEngine()
            engine.startOutgoingCall()
        } catch (e: Exception) {
            Log.e(TAG, "Could not start outgoing voice call", e)
            closeVoiceEngine()
            _voiceCall.value = VoiceCallUiState(
                engineState = LocalVoiceCallEngine.State.FAILED,
                status = "شروع تماس ناموفق بود: ${friendlyError(e)}"
            )
        }
    }

    fun acceptIncomingVoiceCall() = acceptIncomingCall()

    fun acceptIncomingVideoCall() = acceptIncomingCall()

    private fun acceptIncomingCall() {
        val incoming = _voiceCall.value.incoming ?: return
        if (voiceEngine != null) {
            _voiceCall.value = _voiceCall.value.copy(status = "تماس دیگری در حال اجراست.")
            return
        }
        stopRinging()
        callPeer = incoming.device
        callRole = "answer"
        callIsVideo = incoming.isVideo
        Log.i(TAG, "CALL_DIAG role=callee action=accept peer=${incoming.device.displayName} video=${incoming.isVideo} sdpChars=${incoming.offerSdp.length} offerVideoM=${Regex("(?m)^m=video ").findAll(incoming.offerSdp).count()} offerCandidates=${Regex("(?m)^a=candidate:").findAll(incoming.offerSdp).count()}")
        HamrahNetService.setCallActive(appContext, true)
        _voiceCall.value = VoiceCallUiState(
            engineState = LocalVoiceCallEngine.State.PREPARING,
            status = "در حال پاسخ‌دادن به ${incoming.device.displayName}…",
            peer = incoming.device,
            isVideo = incoming.isVideo
        )
        try {
            createVoiceEngine().acceptOffer(incoming.offerSdp)
        } catch (e: Exception) {
            Log.e(TAG, "Could not accept incoming voice call", e)
            closeVoiceEngine()
            _voiceCall.value = VoiceCallUiState(
                engineState = LocalVoiceCallEngine.State.FAILED,
                status = "پاسخ به تماس ناموفق بود: ${friendlyError(e)}"
            )
        }
    }

    fun rejectIncomingVoiceCall() {
        val incoming = _voiceCall.value.incoming ?: return
        stopRinging()
        sendCallSignal(incoming.device, JSONObject().put("type", "call_reject"))
        _voiceCall.value = VoiceCallUiState(status = "تماس ورودی رد شد.")
    }

    fun endVoiceCall() {
        stopRinging()
        val device = callPeer
        if (device != null && voiceEngine != null) {
            sendCallSignal(device, JSONObject().put("type", "call_end"))
        }
        closeVoiceEngine()
        _voiceCall.value = VoiceCallUiState(status = "تماس پایان یافت.")
    }

    fun attachVideoRenderers(local: org.webrtc.SurfaceViewRenderer?, remote: org.webrtc.SurfaceViewRenderer?) {
        voiceEngine?.attachRenderers(local, remote)
    }

    fun switchCamera(): Boolean = voiceEngine?.switchCamera() ?: false

    fun toggleCamera() {
        val enabled = !_voiceCall.value.cameraEnabled
        voiceEngine?.setVideoEnabled(enabled)
        _voiceCall.value = _voiceCall.value.copy(cameraEnabled = enabled,
            status = if (enabled) "دوربین فعال است." else "تصویر دوربین متوقف شد.")
    }

    fun toggleVoiceMute() {
        val nextMuted = !_voiceCall.value.muted
        voiceEngine?.setMuted(nextMuted)
        _voiceCall.value = _voiceCall.value.copy(muted = nextMuted,
            status = if (nextMuted) "میکروفون بی‌صداست." else "میکروفون فعال است.")
    }

    private fun createVoiceEngine(): LocalVoiceCallEngine {
        voiceEngine?.let { return it }
        val engine = LocalVoiceCallEngine(appContext, videoEnabled = callIsVideo)
        voiceEngine = engine
        callStateJob?.cancel()
        callStateJob = callScope.launch {
            engine.state.collect { state ->
                _voiceCall.value = _voiceCall.value.copy(engineState = state)
                if (state == LocalVoiceCallEngine.State.CONNECTED) {
                    stopRinging()
                    _voiceCall.value = _voiceCall.value.copy(status = if (callIsVideo) "تماس تصویری برقرار است." else "تماس صوتی برقرار است.")
                } else if (state == LocalVoiceCallEngine.State.DISCONNECTED) {
                    _voiceCall.value = _voiceCall.value.copy(status = "ارتباط شبکه ناپایدار یا قطع شده است؛ در انتظار بازیابی اتصال صوتی…")
                } else if (state == LocalVoiceCallEngine.State.FAILED) {
                    stopRinging()
                    _voiceCall.value = _voiceCall.value.copy(status = "اتصال صوتی ناموفق بود.")
                }
            }
        }
        engine.onError = { error ->
            _voiceCall.value = _voiceCall.value.copy(
                engineState = LocalVoiceCallEngine.State.FAILED,
                status = error
            )
        }
        engine.onLocalDescriptionReady = { description ->
            Log.i(TAG, "CALL_DIAG local_description_ready role=$callRole type=${description.type} sdpChars=${description.description.length} videoM=${Regex("(?m)^m=video ").findAll(description.description).count()} candidates=${Regex("(?m)^a=candidate:").findAll(description.description).count()}")
            val device = callPeer
            val role = callRole
            if (device != null && role != null) {
                val type = if (role == "outgoing") "call_offer" else "call_answer"
                val signal = JSONObject().put("type", type).put("sdp", description.description).put("isVideo", callIsVideo)
                Log.i(TAG, "CALL_DIAG signaling_send type=$type peer=${device.displayName} video=$callIsVideo")
                sendCallSignal(device, signal)
                val waitingStatus = if (callIsVideo) "درخواست تماس تصویری ارسال شد؛ منتظر پاسخ هستیم." else "درخواست تماس ارسال شد؛ منتظر پاسخ هستیم."
                val answerStatus = if (callIsVideo) "پاسخ ارسال شد؛ در حال اتصال تصویری…" else "پاسخ ارسال شد؛ در حال اتصال صوتی…"
                _voiceCall.value = _voiceCall.value.copy(status = if (type == "call_offer") waitingStatus else answerStatus)
            }
        }
        return engine
    }

    private fun sendCallSignal(device: DiscoveredDevice, message: JSONObject) {
        Log.i(TAG, "CALL_DIAG signaling_send_queued type=${message.optString("type")} peer=${device.displayName}")
        val local = localIdentity ?: return
        val pool = executor ?: return
        val localSignalPort = signalServerSocket?.localPort ?: return
        pool.execute {
            try {
                val response = secureSignaling.sendMessage(device, local, localSignalPort, message)
                Log.i(TAG, "CALL_DIAG signaling_response sentType=${message.optString("type")} responseType=${response.optString("type")} accepted=${response.optBoolean("accepted", response.optString("type") == "pong")} reason=${response.optString("reason")}")
                if (!response.optBoolean("accepted", response.optString("type") == "pong")) {
                    _voiceCall.value = _voiceCall.value.copy(status =
                        "دستگاه مقابل پیام تماس را نپذیرفت: ${response.optString("reason", "نامشخص")}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "CALL_DIAG signaling_failed type=${message.optString("type")} peer=${device.displayName}", e)
                _voiceCall.value = _voiceCall.value.copy(status = "ارسال پیام تماس ناموفق بود: ${friendlyError(e)}")
            }
        }
    }

    /** Queue locally even while the peer is offline; delivery is retried after authenticated reachability returns. */
    fun sendChatMessage(device: DiscoveredDevice?, peerFingerprint: String, body: String): String? {
        val clean = body.trim()
        val fingerprint = peerFingerprint.lowercase()
        if (clean.isEmpty() || clean.length > 4000 || fingerprint.isBlank()) return null
        val messageId = UUID.randomUUID().toString()
        val entity = ChatMessageEntity(
            messageId = messageId,
            peerFingerprint = fingerprint,
            direction = "OUTGOING",
            body = clean,
            createdAtEpochMs = System.currentTimeMillis(),
            status = "QUEUED"
        )
        callScope.launch(Dispatchers.IO) {
            try {
                // Persist first so the sender immediately sees the outgoing bubble and QUEUED state.
                val encryptedEntity = entity.copy(body = ChatMessageCrypto.encrypt(clean))
                chatDao.insertIfAbsent(encryptedEntity)
                peerDao.findByFingerprint(fingerprint)
                    ?: throw SecurityException("مخاطب دیگر در فهرست اعتماد نیست.")
                val target = device?.takeIf { it.advertisedFingerprint.equals(fingerprint, true) }
                    ?: reachableEndpointDevices.entries.firstOrNull { it.key.equals(fingerprint, true) }?.value
                if (target != null) sendQueuedMessage(encryptedEntity, target)
            } catch (e: Exception) {
                Log.w(TAG, "Could not queue chat message messageId=$messageId", e)
                try { chatDao.updateStatus(messageId, "FAILED", friendlyError(e)) } catch (_: Exception) { }
            }
        }
        return messageId
    }

    private suspend fun migrateLegacyChatBodies() {
        try {
            chatDao.getAllForEncryptionMigration().forEach { item ->
                if (!ChatMessageCrypto.isEncrypted(item.body)) {
                    chatDao.updateEncryptedBody(item.messageId, ChatMessageCrypto.encrypt(item.body))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Chat history encryption migration failed", e)
        }
    }

    private suspend fun sendQueuedMessage(message: ChatMessageEntity, device: DiscoveredDevice) {
        if (!inFlightChatIds.add(message.messageId)) return
        try {
            val local = localIdentity ?: return
            val localSignalPort = signalServerSocket?.localPort ?: return
            val plainBody = ChatMessageCrypto.decrypt(message.body)
            chatDao.updateStatus(message.messageId, "SENDING", null)
            val payload = JSONObject()
                .put("type", "chat_message")
                .put("messageId", message.messageId)
                .put("body", plainBody)
                .put("createdAtEpochMs", message.createdAtEpochMs)
            val response = secureSignaling.sendMessage(device, local, localSignalPort, payload)
            if (response.optString("type") == "chat_ack" &&
                response.optString("messageId") == message.messageId && response.optBoolean("accepted")) {
                chatDao.updateStatus(message.messageId, "DELIVERED", null)
            } else {
                // Keep it queued: a negative ACK may be transient (e.g. receiver database busy).
                chatDao.updateStatus(message.messageId, "QUEUED", response.optString("reason", "تأیید دریافت معتبر نبود"))
            }
        } catch (e: Exception) {
            Log.w(TAG, "Chat send deferred messageId=${message.messageId}", e)
            try { chatDao.updateStatus(message.messageId, "QUEUED", friendlyError(e)) } catch (_: Exception) { }
        } finally {
            inFlightChatIds.remove(message.messageId)
        }
    }

    private suspend fun retryPendingChatForPeer(device: DiscoveredDevice) {
        val fingerprint = device.advertisedFingerprint.lowercase()
        chatDao.getPendingOutgoing().filter { it.peerFingerprint == fingerprint }.forEach { sendQueuedMessage(it, device) }
        retryPendingReadReceipts(device)
    }

    /** Mark the visible conversation read and send authenticated per-message read receipts. */
    fun markConversationRead(peerFingerprint: String, device: DiscoveredDevice?) {
        callScope.launch(Dispatchers.IO) {
            val fingerprint = peerFingerprint.lowercase()
            chatDao.markConversationRead(fingerprint)
            val target = device ?: reachableEndpointDevices[fingerprint]
            if (target != null) retryPendingReadReceipts(target)
        }
    }

    private suspend fun retryPendingReadReceipts(device: DiscoveredDevice) {
        val local = localIdentity ?: return
        val localSignalPort = signalServerSocket?.localPort ?: return
        val fingerprint = device.advertisedFingerprint.lowercase()
        chatDao.getPendingReadReceipts().filter { it.peerFingerprint == fingerprint }.forEach { item ->
            try {
                val response = secureSignaling.sendMessage(
                    device, local, localSignalPort,
                    JSONObject().put("type", "chat_read").put("messageId", item.messageId)
                )
                if (response.optString("type") == "chat_read_ack" && response.optString("messageId") == item.messageId && response.optBoolean("accepted")) {
                    chatDao.updateStatus(item.messageId, "READ", null)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Read receipt deferred messageId=${item.messageId}", e)
            }
        }
    }

    /** Send a file only to an already trusted peer. The file content is AES-GCM encrypted. */
    fun sendFileToPeer(device: DiscoveredDevice, uri: Uri, fileName: String, sizeBytes: Long) {
        if (sizeBytes !in 0..FileTransferEngine.MAX_FILE_SIZE) {
            _fileTransferStatus.value = "اندازه فایل باید کمتر از ۲ گیگابایت باشد."
            return
        }
        val local = localIdentity
        val localSignalPort = signalServerSocket?.localPort
        if (local == null || localSignalPort == null) {
            _fileTransferStatus.value = "سرویس شبکه محلی آماده نیست."
            return
        }
        _fileTransferStatus.value = "در حال آماده‌سازی فایل برای ${device.displayName}…"
        callScope.launch {
            try {
                val sha256 = FileTransferEngine.sha256Uri(appContext, uri)
                val requestId = UUID.randomUUID().toString()
                val response = secureSignaling.sendMessage(
                    device, local, localSignalPort,
                    JSONObject()
                        .put("type", "file_offer")
                        .put("requestId", requestId)
                        .put("fileName", fileName.take(180))
                        .put("sizeBytes", sizeBytes)
                        .put("sha256", sha256)
                )
                if (!response.optBoolean("accepted", false)) {
                    _fileTransferStatus.value = "${device.displayName} درخواست دریافت فایل را رد کرد یا پاسخ نداد."
                    return@launch
                }
                val port = response.optInt("transferPort", -1)
                val key = FileTransferEngine.keyFromBase64(response.getString("transferKey"))
                require(port in 1..65535) { "درگاه انتقال فایل نامعتبر است." }
                _fileTransferStatus.value = "در حال ارسال به ${device.displayName}: 0٪"
                FileTransferEngine.send(appContext, uri, device.host, port, key, sizeBytes) { sent ->
                    val percent = if (sizeBytes == 0L) 100 else ((sent * 100) / sizeBytes).toInt().coerceIn(0, 100)
                    _fileTransferStatus.value = "در حال ارسال به ${device.displayName}: $percent٪ (${formatBytes(sent)} از ${formatBytes(sizeBytes)})"
                }
                _fileTransferStatus.value = "ارسال فایل به ${device.displayName} کامل شد."
            } catch (e: Exception) {
                Log.e(TAG, "File transfer failed", e)
                _fileTransferStatus.value = "ارسال فایل ناموفق بود: ${friendlyError(e)}"
            }
        }
    }

    fun respondToFileOffer(id: String, accepted: Boolean) {
        val pending = pendingFileDecisions[id] ?: return
        pending.accepted = accepted
        pending.latch.countDown()
        _incomingFileOffer.value = null
    }

    /** Notifies the user when a trusted peer offers a file while the app is backgrounded. */
    private fun showIncomingFileNotification(offer: IncomingFileOffer) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                    appContext, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.w(TAG, "Incoming file notification skipped: POST_NOTIFICATIONS not granted")
                return
            }
            val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "hamrahnet_file_transfer"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(channelId) == null) {
                manager.createNotificationChannel(
                    NotificationChannel(channelId, "درخواست‌های انتقال فایل", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = "اعلان دریافت فایل از مخاطبان مورد اعتماد همراه‌نت"
                    }
                )
            }
            val openIntent = Intent(appContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                appContext, offer.id.hashCode(), openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(appContext, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("درخواست دریافت فایل")
                .setContentText("${offer.device.displayName} می‌خواهد «${offer.fileName}» را ارسال کند.")
                .setStyle(NotificationCompat.BigTextStyle().bigText(
                    "${offer.device.displayName} می‌خواهد فایل «${offer.fileName}» (${formatBytes(offer.sizeBytes)}) را ارسال کند. برای بررسی و تأیید، لمس کنید."
                ))
                .setContentIntent(pendingIntent)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            manager.notify(offer.id.hashCode(), notification)
        } catch (e: Exception) {
            Log.w(TAG, "Could not show incoming file notification", e)
        }
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes بایت"
        bytes < 1024 * 1024 -> "${bytes / 1024} کیلوبایت"
        bytes < 1024L * 1024L * 1024L -> "${bytes / (1024L * 1024L)} مگابایت"
        else -> "${bytes / (1024L * 1024L * 1024L)} گیگابایت"
    }

    private fun handleSecureSignal(
        fingerprint: String,
        username: String,
        remoteSignalPort: Int,
        remoteHost: java.net.InetAddress,
        message: JSONObject
    ): JSONObject {
        val type = message.optString("type")
        // SecureSignalingProtocol validates the cryptographic identity before this callback.
        // Still validate the trusted record and advertised return port before accepting a ping.
        val trusted = runBlocking { peerDao.findByFingerprint(fingerprint.lowercase()) }
            ?: runBlocking { peerDao.findByFingerprint(fingerprint) }
            ?: return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "untrusted_peer")
        if (trusted.username != username || remoteSignalPort !in 1..65535) {
            return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "invalid_peer_endpoint")
        }
        if (type == "ping") {
            // VERSION is 1 in SecureSignalingProtocol. Returning 2 made every valid probe fail,
            // so trusted peers appeared offline and the reconnect loop could never succeed.
            val observedHost = remoteHost.hostAddress.substringBefore('%')
            callScope.launch(Dispatchers.IO) {
                try {
                    // Learn the peer's current VPN/LAN source address from an authenticated ping.
                    // No directory or central service is involved.
                    peerDao.updateEndpoint(trusted.fingerprint, observedHost, PAIRING_PORT, remoteSignalPort)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not refresh endpoint from authenticated ping", e)
                }
            }
            return JSONObject().put("type", "pong").put("protocol", 1)
        }
        // Discovery is advisory and can temporarily disappear while the screen is off.
        // Use the authenticated trusted-peer record and the signed endpoint in the handshake.
        val device = DiscoveredDevice(
            serviceName = "HamrahNet-${trusted.username}-${trusted.fingerprint.take(8)}",
            displayName = trusted.displayName,
            username = trusted.username,
            host = remoteHost,
            port = remoteSignalPort,
            signalPort = remoteSignalPort,
            advertisedFingerprint = trusted.fingerprint
        )

        when (type) {
            "chat_message" -> {
                val messageId = message.optString("messageId")
                val body = message.optString("body")
                if (messageId.length !in 16..64 || !messageId.matches(Regex("[A-Za-z0-9-]+")) || body.isBlank() || body.length > 4000) {
                    return JSONObject().put("type", "chat_ack").put("accepted", false)
                        .put("messageId", messageId).put("reason", "invalid_message")
                }
                return try {
                    // Encrypt and persist before ACK. IGNORE makes retries idempotent.
                    val insertedRow = runBlocking {
                        chatDao.insertIfAbsent(ChatMessageEntity(
                            messageId = messageId,
                            peerFingerprint = trusted.fingerprint.lowercase(),
                            direction = "INCOMING",
                            body = ChatMessageCrypto.encrypt(body),
                            createdAtEpochMs = message.optLong("createdAtEpochMs", System.currentTimeMillis()),
                            status = "RECEIVED"
                        ))
                    }
                    val app = appContext as? HamrahNetApplication
                    if (insertedRow != -1L && app?.isAppInForeground == false) {
                        ChatMessageNotification.show(appContext, trusted.fingerprint, trusted.displayName, body)
                    }
                    JSONObject().put("type", "chat_ack").put("accepted", true).put("messageId", messageId)
                } catch (e: Exception) {
                    Log.e(TAG, "Could not persist incoming chat message", e)
                    JSONObject().put("type", "chat_ack").put("accepted", false)
                        .put("messageId", messageId).put("reason", "storage_failed")
                }
            }
            "chat_read" -> {
                val messageId = message.optString("messageId")
                if (messageId.length !in 16..64 || !messageId.matches(Regex("[A-Za-z0-9-]+"))) {
                    return JSONObject().put("type", "chat_read_ack").put("accepted", false).put("messageId", messageId)
                }
                val updated = runBlocking {
                    val existing = chatDao.findById(messageId)
                    if (existing != null && existing.peerFingerprint == trusted.fingerprint.lowercase() && existing.direction == "OUTGOING") {
                        chatDao.updateStatus(messageId, "READ", null)
                        true
                    } else false
                }
                return JSONObject().put("type", "chat_read_ack").put("accepted", updated).put("messageId", messageId)
            }
            "file_offer" -> {
                val requestId = message.optString("requestId")
                val fileName = message.optString("fileName").substringAfterLast('/').substringAfterLast('\\')
                val sizeBytes = message.optLong("sizeBytes", -1L)
                val sha256 = message.optString("sha256")
                if (requestId.isBlank() || fileName.isBlank() || sizeBytes !in 0..FileTransferEngine.MAX_FILE_SIZE || !sha256.matches(Regex("[0-9a-fA-F]{64}"))) {
                    return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "invalid_file_offer")
                }
                if (_incomingFileOffer.value != null) {
                    return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "busy")
                }
                val transferServer = try { ServerSocket(0) } catch (e: Exception) {
                    return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "transfer_server_failed")
                }
                val key = FileTransferEngine.newKey()
                val offer = IncomingFileOffer(requestId, device, fileName, sizeBytes)
                val pending = PendingFileDecision(offer, CountDownLatch(1), transferServer, key)
                pendingFileDecisions[requestId] = pending
                _incomingFileOffer.value = offer
                _fileTransferStatus.value = "درخواست دریافت فایل از ${device.displayName} در انتظار تأیید است."
                showIncomingFileNotification(offer)
                val decided = try { pending.latch.await(90, TimeUnit.SECONDS) } catch (_: InterruptedException) { false }
                pendingFileDecisions.remove(requestId)
                _incomingFileOffer.value = null
                if (!decided || !pending.accepted) {
                    try { transferServer.close() } catch (_: Exception) { }
                    _fileTransferStatus.value = if (decided) "درخواست فایل رد شد." else "مهلت پاسخ به درخواست فایل تمام شد."
                    return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "declined_or_timeout")
                }
                val transferPort = transferServer.localPort
                _fileTransferStatus.value = "در حال دریافت ${offer.fileName} از ${device.displayName}…"
                callScope.launch {
                    try {
                        val result = FileTransferEngine.receive(appContext, transferServer, key, sizeBytes, sha256, fileName) { received ->
                            val percent = if (sizeBytes == 0L) 100 else ((received * 100) / sizeBytes).toInt().coerceIn(0, 100)
                            _fileTransferStatus.value = "در حال دریافت فایل: $percent٪ (${formatBytes(received)} از ${formatBytes(sizeBytes)})"
                        }
                        _fileTransferStatus.value = "دریافت فایل کامل شد: ${result.savedPath}"
                    } catch (e: Exception) {
                        Log.e(TAG, "Incoming file transfer failed", e)
                        _fileTransferStatus.value = "دریافت فایل ناموفق بود: ${friendlyError(e)}"
                    }
                }
                return JSONObject().put("type", "signal_ack").put("accepted", true)
                    .put("transferPort", transferPort)
                    .put("transferKey", FileTransferEngine.keyToBase64(key))
            }
            "call_offer" -> {
                val receivedOfferSdp = message.optString("sdp")
                Log.i(TAG, "CALL_DIAG signaling_received type=call_offer peer=${device.displayName} sdpChars=${receivedOfferSdp.length} videoM=${Regex("(?m)^m=video ").findAll(receivedOfferSdp).count()} candidates=${Regex("(?m)^a=candidate:").findAll(receivedOfferSdp).count()}")
                if (voiceEngine != null || _voiceCall.value.incoming != null) {
                    return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "busy")
                }
                val sdp = message.optString("sdp")
                val isVideo = message.optBoolean("isVideo", false)
                if (sdp.isBlank()) return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "empty_offer")
                startRinging()
                IncomingCallNotification.show(appContext, device.displayName)
                _voiceCall.value = VoiceCallUiState(
                    status = if (isVideo) "تماس تصویری ورودی از ${device.displayName}." else "تماس صوتی ورودی از ${device.displayName}؛ برای پاسخ، مجوز میکروفون لازم است.",
                    peer = device,
                    incoming = IncomingVoiceCall(device, sdp, isVideo),
                    isVideo = isVideo
                )
            }
            "call_answer" -> {
                val receivedAnswerSdp = message.optString("sdp")
                Log.i(TAG, "CALL_DIAG signaling_received type=call_answer peer=${device.displayName} sdpChars=${receivedAnswerSdp.length} videoM=${Regex("(?m)^m=video ").findAll(receivedAnswerSdp).count()} candidates=${Regex("(?m)^a=candidate:").findAll(receivedAnswerSdp).count()}")
                if (callPeer?.advertisedFingerprint?.equals(fingerprint, ignoreCase = true) != true || voiceEngine == null) {
                    return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "no_pending_call")
                }
                try {
                    voiceEngine?.acceptAnswer(message.getString("sdp"))
                    _voiceCall.value = _voiceCall.value.copy(status = "پاسخ تماس دریافت شد؛ در حال اتصال صوتی…")
                } catch (e: Exception) {
                    _voiceCall.value = _voiceCall.value.copy(status = "ثبت پاسخ تماس ناموفق بود: ${friendlyError(e)}")
                    return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "invalid_answer")
                }
            }
            "call_reject" -> {
                if (callPeer?.advertisedFingerprint?.equals(fingerprint, ignoreCase = true) == true) {
                    stopRinging()
                    closeVoiceEngine()
                    _voiceCall.value = VoiceCallUiState(status = "طرف مقابل تماس را رد کرد.")
                }
            }
            "call_end" -> {
                if (callPeer?.advertisedFingerprint?.equals(fingerprint, ignoreCase = true) == true) {
                    stopRinging()
                    closeVoiceEngine()
                    _voiceCall.value = VoiceCallUiState(status = "تماس توسط طرف مقابل پایان یافت.")
                }
            }
            else -> return JSONObject().put("type", "signal_ack").put("accepted", false).put("reason", "unsupported")
        }
        return JSONObject().put("type", "signal_ack").put("accepted", true)
    }

    /** Plays a short, simple beep for the caller while waiting for the remote side to answer. */
    private fun startOutgoingRingback() {
        synchronized(this) {
            if (ringbackToneGenerator != null) return
            try {
                val generator = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 70)
                ringbackToneGenerator = generator
                val beep = object : Runnable {
                    override fun run() {
                        synchronized(this@PairingManager) {
                            if (ringbackToneGenerator !== generator) return
                            try {
                                generator.startTone(ToneGenerator.TONE_PROP_BEEP, 180)
                                ringHandler.postDelayed(this, 2000L)
                            } catch (e: Exception) {
                                Log.w(TAG, "Could not play caller ringback beep", e)
                            }
                        }
                    }
                }
                ringbackRunnable = beep
                beep.run()
            } catch (e: Exception) {
                Log.w(TAG, "Could not initialize caller ringback beep", e)
            }
        }
    }

    private fun startRinging() {
        synchronized(this) {
            if (ringTone != null) return
            try {
                val prefs = appContext.getSharedPreferences("hamrahnet_preferences", Context.MODE_PRIVATE)
                // If the user explicitly chose "silent", ringtone_uri is present but empty.
                val hasCustomChoice = prefs.contains("ringtone_uri")
                val savedUri = prefs.getString("ringtone_uri", null)
                val uri = when {
                    hasCustomChoice && savedUri.isNullOrBlank() -> null
                    !savedUri.isNullOrBlank() -> Uri.parse(savedUri)
                    else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                }
                if (uri == null) return
                val ringtone = RingtoneManager.getRingtone(appContext, uri)
                if (ringtone == null) {
                    Log.w(TAG, "Selected ringtone could not be loaded; using system default")
                    val fallback = RingtoneManager.getRingtone(
                        appContext, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                    ) ?: return
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                        fallback.audioAttributes = android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    } else {
                        @Suppress("DEPRECATION")
                        fallback.streamType = AudioManager.STREAM_RING
                    }
                    ringTone = fallback
                    fallback.play()
                    return
                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    ringtone.audioAttributes = android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                } else {
                    @Suppress("DEPRECATION")
                    ringtone.streamType = AudioManager.STREAM_RING
                }
                ringTone = ringtone
                ringtone.play()
            } catch (e: Exception) {
                Log.w(TAG, "Could not play selected ringtone", e)
            }
        }
    }

    private fun stopRinging() {
        synchronized(this) {
            ringbackRunnable?.let { ringHandler.removeCallbacks(it) }
            ringbackRunnable = null
            try { ringbackToneGenerator?.stopTone() } catch (_: Exception) { }
            try { ringbackToneGenerator?.release() } catch (_: Exception) { }
            ringbackToneGenerator = null
            try { ringTone?.stop() } catch (_: Exception) { }
            ringTone = null
        }
        IncomingCallNotification.cancel(appContext)
    }

    private fun closeVoiceEngine() {
        stopRinging()
        HamrahNetService.setCallActive(appContext, false)
        callStateJob?.cancel()
        callStateJob = null
        try { voiceEngine?.release() } catch (_: Exception) { }
        voiceEngine = null
        callPeer = null
        callRole = null
        callIsVideo = false
    }

    fun respondToPairing(promptId: String, accept: Boolean) {
        val pending = decisions[promptId] ?: return
        pending.accepted.set(accept)
        pending.latch.countDown()
    }

    private fun acceptLoop(server: ServerSocket) {
        while (running.get() && !server.isClosed) {
            try {
                val socket = server.accept()
                if (!running.get()) { socket.close(); break }
                if (!sessionBusy.compareAndSet(false, true)) {
                    socket.close()
                    continue
                }
                activeSockets.add(socket)
                val pool = executor
                if (pool == null) { socket.close(); sessionBusy.set(false); continue }
                pool.execute {
                    try {
                        val local = localIdentity ?: return@execute
                        val result = protocol.pairAsServer(socket, local) { remote, sas ->
                            awaitUserDecision(remote, sas, PairingDirection.INCOMING, socket.inetAddress.hostAddress ?: "شبکه محلی")
                        }
                        saveTrustedPeer(result.remote, socket.inetAddress.hostAddress, PAIRING_PORT, SIGNAL_PORT)
                        _status.value = "جفت‌سازی با ${result.remote.displayName} با تأیید دوطرفه انجام شد."
                    } catch (e: PairingProtocol.PairingRejectedException) {
                        _status.value = "درخواست جفت‌سازی رد شد یا منقضی شد."
                    } catch (e: Exception) {
                        if (running.get()) {
                            _status.value = "درخواست ورودی ناموفق بود: ${friendlyError(e)}"
                            Log.w(TAG, "Incoming pairing failed", e)
                        }
                    } finally {
                        activeSockets.remove(socket)
                        try { socket.close() } catch (_: Exception) { }
                        sessionBusy.set(false)
                    }
                }
            } catch (_: java.net.SocketTimeoutException) {
                // Periodically re-check running flag.
            } catch (e: IOException) {
                if (running.get()) Log.w(TAG, "Local accept loop error", e)
                break
            }
        }
    }

    private fun secureAcceptLoop(server: ServerSocket) {
        while (running.get() && !server.isClosed) {
            try {
                val socket = server.accept()
                if (!running.get()) {
                    socket.close()
                    break
                }
                // Do not impose a device-count/concurrent-peer ceiling here; authenticated peers
                // are validated by SecureSignalingProtocol before any action is accepted.
                activeSignalSockets.add(socket)
                val pool = executor
                if (pool == null) {
                    activeSignalSockets.remove(socket)
                    socket.close()
                    continue
                }
                pool.execute {
                    try {
                        val local = localIdentity ?: return@execute
                        val localSignalPort = signalServerSocket?.localPort ?: return@execute
                        secureSignaling.serve(socket, local, localSignalPort, ::handleSecureSignal)
                    } catch (e: Exception) {
                        if (running.get()) Log.w(TAG, "Secure signaling request rejected", e)
                    } finally {
                        activeSignalSockets.remove(socket)
                        try { socket.close() } catch (_: Exception) { }
                    }
                }
            } catch (_: java.net.SocketTimeoutException) {
                // Periodically re-check running flag.
            } catch (e: IOException) {
                if (running.get()) Log.w(TAG, "Secure signaling accept loop error", e)
                break
            }
        }
    }

    private fun awaitUserDecision(
        remote: RemoteIdentity,
        sas: String,
        direction: PairingDirection,
        address: String
    ): Boolean {
        val id = UUID.randomUUID().toString()
        val pending = PendingDecision()
        decisions[id] = pending
        _pendingPrompt.value = PairingPrompt(id, remote.displayName, remote.username, sas, direction, address)
        _status.value = "کد شش‌رقمی را با دستگاه مقابل مقایسه کنید؛ تا تأیید کاربر ارتباط ادامه نمی‌یابد."
        return try {
            val signaled = pending.latch.await(120, TimeUnit.SECONDS)
            signaled && pending.accepted.get()
        } finally {
            decisions.remove(id)
            if (_pendingPrompt.value?.id == id) _pendingPrompt.value = null
        }
    }

    private fun saveTrustedPeer(remote: RemoteIdentity, hostAddress: String?, pairingPort: Int?, signalPort: Int?) {
        runBlocking {
            val previous = peerDao.findByFingerprint(remote.fingerprint)
            peerDao.upsert(
                TrustedPeerEntity(
                    fingerprint = remote.fingerprint,
                    displayName = remote.displayName,
                    username = remote.username,
                    publicKeyBase64 = remote.publicKeyBase64,
                    pairedAtEpochMs = previous?.pairedAtEpochMs ?: System.currentTimeMillis(),
                    lastHostAddress = hostAddress ?: previous?.lastHostAddress,
                    lastPairingPort = pairingPort ?: previous?.lastPairingPort,
                    lastSignalPort = signalPort ?: previous?.lastSignalPort
                )
            )
        }
    }

    private fun startTrustedPeerObserver() {
        trustedPeersJob?.cancel()
        trustedPeersJob = callScope.launch(Dispatchers.IO) {
            peerDao.observeAll().collect { peers ->
                trustedFingerprints.clear()
                trustedFingerprints.addAll(peers.map { it.fingerprint.lowercase() })
                publishMergedDevices()
            }
        }
    }

    private fun publishMergedDevices() {
        // A stale NSD/mDNS entry must not keep a trusted contact marked online after its
        // authenticated secure-channel probe fails (commonly seen after screen-off/Doze).
        // Unpaired nearby devices remain discoverable through mDNS.
        val untrustedNearby = mdnsDevices.values.filter { device ->
            device.advertisedFingerprint.isNotBlank() &&
                device.advertisedFingerprint.lowercase() !in trustedFingerprints
        }
        val combined = (reachableEndpointDevices.values.toList() + untrustedNearby)
            .filter { it.advertisedFingerprint.isNotBlank() }
            .distinctBy { it.advertisedFingerprint.lowercase() }
        _devices.value = combined
    }

    private fun startEndpointProbeLoop() {
        endpointProbeJob?.cancel()
        endpointProbeJob = callScope.launch(Dispatchers.IO) {
            while (running.get()) {
                try { probeTrustedPeersNow() }
                catch (e: Exception) { Log.w(TAG, "Trusted endpoint probe cycle failed", e) }
                delay(ENDPOINT_PROBE_INTERVAL_MS)
            }
        }
    }

    private suspend fun probeTrustedPeersNow() {
        val local = localIdentity ?: return
        val localSignalPort = signalServerSocket?.localPort ?: return
        val peers = try { peerDao.observeAll().first() } catch (_: Exception) { emptyList() }
        coroutineScope {
            peers.map { peer -> async(Dispatchers.IO) {
                if (!running.get()) return@async
                val storedAddress = peer.lastHostAddress
                val storedDevice = storedAddress?.let { address ->
                    try {
                        DiscoveredDevice(
                            serviceName = "HamrahNet-${peer.username}-${peer.fingerprint.take(8)}",
                            displayName = peer.displayName,
                            username = peer.username,
                            host = java.net.InetAddress.getByName(address),
                            port = peer.lastPairingPort ?: PAIRING_PORT,
                            signalPort = peer.lastSignalPort ?: SIGNAL_PORT,
                            advertisedFingerprint = peer.fingerprint
                        )
                    } catch (_: Exception) { null }
                }
                val mdnsDevice = mdnsDevices.values.firstOrNull { it.advertisedFingerprint.equals(peer.fingerprint, true) }
                val candidates = listOfNotNull(storedDevice, mdnsDevice).distinctBy { "${it.host.hostAddress}:${it.signalPort}" }
                var success: DiscoveredDevice? = null
                var lastFailure: Exception? = null
                for (candidate in candidates) {
                    try {
                        // ping() validates the authenticated pong response and protocol version itself.
                        secureSignaling.ping(candidate, local, localSignalPort)
                        success = candidate.copy(
                            serviceName = "HamrahNet-${peer.username}-${peer.fingerprint.take(8)}",
                            displayName = peer.displayName,
                            username = peer.username,
                            advertisedFingerprint = peer.fingerprint
                        )
                        val currentAddress = candidate.host.hostAddress.substringBefore('%')
                        if (currentAddress != storedAddress || candidate.signalPort != (peer.lastSignalPort ?: SIGNAL_PORT)) {
                            try { peerDao.updateEndpoint(peer.fingerprint, currentAddress, candidate.port, candidate.signalPort) }
                            catch (e: Exception) { Log.w(TAG, "Could not persist refreshed peer endpoint", e) }
                        }
                        break
                    } catch (e: Exception) { lastFailure = e }
                }
                val wasReachable = reachableEndpointDevices.containsKey(peer.fingerprint)
                if (success != null) {
                    reachableEndpointDevices[peer.fingerprint] = success!!
                    try { retryPendingChatForPeer(success!!) }
                    catch (e: Exception) { Log.w(TAG, "Pending chat retry failed for ${peer.username}", e) }
                    if (!wasReachable) Log.i(TAG, "PRESENCE online username=${peer.username} fingerprint=${peer.fingerprint.take(12)}")
                } else {
                    reachableEndpointDevices.remove(peer.fingerprint)
                    if (wasReachable) Log.w(TAG, "PRESENCE offline username=${peer.username} fingerprint=${peer.fingerprint.take(12)} reason=${lastFailure?.javaClass?.simpleName}:${lastFailure?.message?.take(100)}")
                }
            } }.awaitAll()
        }
        publishMergedDevices()
    }

    private fun friendlyError(e: Exception): String = when (e) {
        is java.net.BindException -> "درگاه ثابت همراه‌نت اشغال است؛ نسخهٔ دیگری از برنامه یا سرویس دیگری از همین درگاه استفاده می‌کند."
        is java.net.ConnectException -> "دستگاه پاسخ نمی‌دهد یا ارتباط بین گوشی‌ها مسدود است."
        is java.net.SocketTimeoutException -> "زمان اتصال یا تأیید تمام شد."
        is SecurityException -> "دسترسی شبکه یا کلید امن مجاز نیست."
        else -> e.message?.take(140) ?: "خطای ارتباطی"
    }

    private class PendingDecision {
        val latch = CountDownLatch(1)
        val accepted = AtomicReference(false)
    }
}
