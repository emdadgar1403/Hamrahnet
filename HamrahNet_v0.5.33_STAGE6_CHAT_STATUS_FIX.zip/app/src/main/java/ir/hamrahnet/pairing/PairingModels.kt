package ir.hamrahnet.pairing

import ir.hamrahnet.discovery.DiscoveredDevice

/** This code must be compared on both physical devices before either user accepts. */
data class PairingPrompt(
    val id: String,
    val displayName: String,
    val username: String,
    val sasCode: String,
    val direction: PairingDirection,
    val address: String
)

enum class PairingDirection { INCOMING, OUTGOING }

data class RemoteIdentity(
    val displayName: String,
    val username: String,
    val publicKeyBase64: String,
    val publicKeyBytes: ByteArray,
    val fingerprint: String,
    val nonce: ByteArray
)

data class PairingRequest(val device: DiscoveredDevice)
