import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Encrypts a UTF-8 CSV into node_directory.enc for HamrahNet v0.5.22. */
public final class NodeDirectoryEncryptor {
  private static final byte[] KEY = new byte[] {0x4a,0x6d,0x31,0x72,0x38,0x51,0x70,0x33,0x58,0x76,0x36,0x4b,0x32,0x6e,0x39,0x54,0x35,0x62,0x37,0x57,0x63,0x31,0x4a,0x38,0x71,0x34,0x5a,0x70,0x36,0x48,0x73,0x32};
  public static void main(String[] args) throws Exception {
    if (args.length != 2) { System.err.println("Usage: java NodeDirectoryEncryptor input.csv output.enc"); System.exit(2); }
    byte[] plain = Files.readAllBytes(Path.of(args[0]));
    byte[] nonce = new byte[12]; new SecureRandom().nextBytes(nonce);
    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
    c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(KEY, "AES"), new GCMParameterSpec(128, nonce));
    c.updateAAD("HamrahNet-NodeDirectory-v1".getBytes(StandardCharsets.UTF_8));
    byte[] encrypted = c.doFinal(plain);
    byte[] packed = new byte[nonce.length + encrypted.length];
    System.arraycopy(nonce, 0, packed, 0, nonce.length); System.arraycopy(encrypted, 0, packed, nonce.length, encrypted.length);
    Files.write(Path.of(args[1]), ("HNENC1:" + Base64.getMimeEncoder(76, new byte[] {'\n'}).encodeToString(packed)).getBytes(StandardCharsets.US_ASCII));
    System.out.println("Encrypted directory written: " + args[1]);
  }
}
