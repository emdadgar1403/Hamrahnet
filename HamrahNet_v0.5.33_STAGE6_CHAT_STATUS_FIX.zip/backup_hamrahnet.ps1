# ============================================================
# HamrahNet - Source Files Backup
# Project : F:\Hamrahnet_Project\HamrahnetVPN\HamrahNet_v0.5.22_UI_Contacts_ChatReview\hn
# Output  : F:\AI\Backups\HamrahnetVPN
# ============================================================

$ErrorActionPreference = "Stop"

# ---------- Configuration ----------
$ProjectPath = "F:\Hamrahnet_Project\HamrahnetVPN\HamrahNet_v0.5.22_UI_Contacts_ChatReview\hn"
$BackupDirectory = "F:\AI\Backups\HamrahnetVPN"

# Directories excluded from backup
$ExcludedDirectories = @(
    ".gradle",
    ".idea",
    ".git",
    "build",
    ".kotlin",
    ".cxx",
    ".externalNativeBuild",
    "captures",
    "out",
    "tmp"
)

# Exact file names excluded from backup
$ExcludedFileNames = @(
    "local.properties"
)

# File patterns excluded from backup
$ExcludedFilePatterns = @(
    "*.iml",
    "*.hprof",
    "*.log"
)

# ---------- Validate project ----------
if (-not (Test-Path -LiteralPath $ProjectPath -PathType Container)) {
    Write-Host "ERROR: Project directory not found:" -ForegroundColor Red
    Write-Host $ProjectPath
    exit 1
}

$ProjectPath = (Resolve-Path -LiteralPath $ProjectPath).Path.TrimEnd('\')

# ---------- Prepare backup directory ----------
try {
    New-Item -ItemType Directory -Path $BackupDirectory -Force |
        Out-Null

    $BackupDirectory = (Resolve-Path -LiteralPath $BackupDirectory).Path
}
catch {
    Write-Host "ERROR: Cannot create backup directory." -ForegroundColor Red
    Write-Host $_.Exception.Message
    exit 1
}

# Prevent accidentally backing up the destination inside the project
if ($BackupDirectory.StartsWith(
    $ProjectPath + "\",
    [System.StringComparison]::OrdinalIgnoreCase
)) {
    Write-Host "ERROR: Backup directory must be outside the project." -ForegroundColor Red
    exit 1
}

# ---------- Create backup file name ----------
$Timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$BackupPath = Join-Path $BackupDirectory "HamrahNetVPN_$Timestamp.zip"

# ---------- Load ZIP support ----------
try {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
}
catch {
    Write-Host "ERROR: ZIP libraries could not be loaded." -ForegroundColor Red
    Write-Host $_.Exception.Message
    exit 1
}

# ---------- Collect files and create ZIP ----------
$ZipStream = $null
$Archive = $null
$FileCount = 0
[long]$TotalBytes = 0

try {
    $ZipStream = [System.IO.File]::Open(
        $BackupPath,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::ReadWrite,
        [System.IO.FileShare]::None
    )

    $Archive = [System.IO.Compression.ZipArchive]::new(
        $ZipStream,
        [System.IO.Compression.ZipArchiveMode]::Create,
        $false
    )

    # Traverse folders manually so excluded directories
    # are never entered.
    $PendingDirectories = [System.Collections.Generic.Stack[string]]::new()
    $PendingDirectories.Push($ProjectPath)

    while ($PendingDirectories.Count -gt 0) {
        $CurrentDirectory = $PendingDirectories.Pop()

        $Items = Get-ChildItem `
            -LiteralPath $CurrentDirectory `
            -Force `
            -ErrorAction Stop

        foreach ($Item in $Items) {

            # Skip excluded directories
            if ($Item.PSIsContainer) {
                if ($ExcludedDirectories -contains $Item.Name) {
                    continue
                }

                # Avoid following directory junctions/symbolic links
                if (($Item.Attributes -band
                    [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                    continue
                }

                $PendingDirectories.Push($Item.FullName)
                continue
            }

            # Skip excluded file names
            if ($ExcludedFileNames -contains $Item.Name) {
                continue
            }

            # Skip excluded file patterns
            $SkipFile = $false

            foreach ($Pattern in $ExcludedFilePatterns) {
                if ($Item.Name -like $Pattern) {
                    $SkipFile = $true
                    break
                }
            }

            if ($SkipFile) {
                continue
            }

            # Calculate relative ZIP path without Regex
            $RelativePath = $Item.FullName.Substring($ProjectPath.Length)
            $RelativePath = $RelativePath.TrimStart(
                [char[]]@([char]'\', [char]'/')
            )

            # ZIP entry paths must use forward slashes
            $EntryName = $RelativePath.Replace('\', '/')

            # Add file to archive
            $Entry = $Archive.CreateEntry(
                $EntryName,
                [System.IO.Compression.CompressionLevel]::Optimal
            )

            $InputStream = $null
            $OutputStream = $null

            try {
                $InputStream = [System.IO.File]::OpenRead($Item.FullName)
                $OutputStream = $Entry.Open()

                $InputStream.CopyTo($OutputStream)

                $FileCount++
                $TotalBytes += $Item.Length
            }
            finally {
                if ($OutputStream -ne $null) {
                    $OutputStream.Dispose()
                }

                if ($InputStream -ne $null) {
                    $InputStream.Dispose()
                }
            }
        }
    }

    if ($FileCount -eq 0) {
        throw "No project files were found for backup."
    }
}
catch {
    Write-Host ""
    Write-Host "BACKUP FAILED!" -ForegroundColor Red
    Write-Host $_.Exception.Message

    if (Test-Path -LiteralPath $BackupPath) {
        Remove-Item -LiteralPath $BackupPath -Force `
            -ErrorAction SilentlyContinue
    }

    exit 1
}
finally {
    if ($Archive -ne $null) {
        $Archive.Dispose()
    }

    if ($ZipStream -ne $null) {
        $ZipStream.Dispose()
    }
}

# ---------- Verify backup ----------
try {
    if (-not (Test-Path -LiteralPath $BackupPath -PathType Leaf)) {
        throw "Backup ZIP file was not created."
    }

    $ZipFile = [System.IO.Compression.ZipFile]::OpenRead($BackupPath)

    try {
        if ($ZipFile.Entries.Count -eq 0) {
            throw "Backup ZIP is empty."
        }

        $ArchivedFileCount = $ZipFile.Entries.Count
    }
    finally {
        $ZipFile.Dispose()
    }

    $BackupSizeMB = [math]::Round(
        (Get-Item -LiteralPath $BackupPath).Length / 1MB,
        2
    )

    $SourceSizeMB = [math]::Round($TotalBytes / 1MB, 2)

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "       BACKUP COMPLETED SUCCESSFULLY" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "Project       : $ProjectPath"
    Write-Host "Backup file   : $BackupPath"
    Write-Host "Files added   : $FileCount"
    Write-Host "Files in ZIP  : $ArchivedFileCount"
    Write-Host "Source size   : $SourceSizeMB MB"
    Write-Host "ZIP size      : $BackupSizeMB MB"
    Write-Host "========================================" -ForegroundColor Green
}
catch {
    Write-Host ""
    Write-Host "WARNING: Backup was created but verification failed." -ForegroundColor Yellow
    Write-Host $_.Exception.Message
    exit 1
}
