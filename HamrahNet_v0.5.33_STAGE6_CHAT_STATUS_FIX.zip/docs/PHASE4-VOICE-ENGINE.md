# HamrahNet Phase 4 — first UI/signaling integration

This patch builds on the supplied project snapshot and adds:
- A runtime `RECORD_AUDIO` permission prompt when the user starts or answers a call.
- A voice-call button on discovered, trusted device cards.
- Incoming-call answer/reject dialog, mute and hang-up controls, and call state/status.
- Encrypted authenticated one-message call signaling (`call_offer`, `call_answer`, `call_reject`, `call_end`) over the existing trusted-device handshake.
- SDP is sent after ICE gathering completes so gathered host candidates are included in the SDP. No STUN/TURN servers are configured.

## Limitations and test notes
- This has not been built on the user's Android SDK or tested on two physical devices in this environment.
- The other phone must be online in HamrahNet, discovered by mDNS, and already trusted. Both devices must be on the same LAN and the Wi-Fi/router must allow peer-to-peer client traffic.
- The implementation uses a one-request encrypted connection for each signaling message; it is not a persistent general-purpose signaling session.
- Audio media is WebRTC; call signaling messages are protected by the app's existing signed ECDH/AES-GCM handshake.
- Test first with two physical devices and granted microphone permission. If the call remains at "در حال اتصال", capture Logcat for `org.webrtc` and `HamrahNetPairing`.
