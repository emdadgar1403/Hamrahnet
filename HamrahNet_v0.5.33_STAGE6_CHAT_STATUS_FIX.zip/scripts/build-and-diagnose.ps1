param(
    [string]$ProxyHost = "127.0.0.1",
    [int]$ProxyPort = 2080,
    [switch]$NoProxy
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
try {
    if (-not $NoProxy) {
        $proxy = "-Dhttp.proxyHost=$ProxyHost -Dhttp.proxyPort=$ProxyPort -Dhttps.proxyHost=$ProxyHost -Dhttps.proxyPort=$ProxyPort"
        $env:JAVA_TOOL_OPTIONS = $proxy
        $env:GRADLE_OPTS = $proxy
        Write-Host "Using HTTP/HTTPS proxy $ProxyHost`:$ProxyPort for Gradle downloads."
    }

    $logPath = Join-Path $projectRoot "build-v0.5.17.log"
    Write-Host "Building HamrahNet v0.5.17; log: $logPath"
    $output = & ".\gradlew.bat" clean assembleDebug --stacktrace 2>&1
    $exitCode = $LASTEXITCODE
    $output | Tee-Object -FilePath $logPath

    if ($exitCode -ne 0) {
        Write-Host "Gradle failed with exit code $exitCode. Inspect build-v0.5.17.log; the stable v0.5.14 project was not touched."
        exit $exitCode
    }

    $apkPath = Join-Path $projectRoot "app\build\outputs\apk\debug\app-debug.apk"
    if (-not (Test-Path $apkPath)) {
        Write-Host "Gradle reported success, but the expected APK was not found at $apkPath"
        exit 2
    }

    $apk = Get-Item $apkPath
    $hash = Get-FileHash $apkPath -Algorithm SHA256
    Write-Host "APK created: $($apk.FullName)"
    Write-Host "Size bytes: $($apk.Length)"
    Write-Host "SHA-256: $($hash.Hash)"
    Write-Host "Next: install on two phones and follow VPN-DIRECT-PAIRING-v0.5.17-FA.md."
}
finally {
    Pop-Location
}
