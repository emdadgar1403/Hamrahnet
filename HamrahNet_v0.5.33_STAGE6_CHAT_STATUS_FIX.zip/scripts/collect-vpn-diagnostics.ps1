param(
    [string]$OutputRoot = ".\vpn-diagnostics"
)

$ErrorActionPreference = "Stop"
$adbCommand = Get-Command adb -ErrorAction SilentlyContinue
if (-not $adbCommand) {
    throw "ADB پیدا نشد. Android SDK > platform-tools را به PATH اضافه کنید یا اسکریپت را در ترمینالی اجرا کنید که adb در آن قابل دسترسی است."
}

$deviceLines = & adb devices | Select-Object -Skip 1 | Where-Object { $_ -match "^\S+\s+device$" }
if (-not $deviceLines) {
    throw "هیچ گوشی مجاز و متصل از طریق ADB پیدا نشد. USB debugging را فعال و مجوز اتصال را روی گوشی تأیید کنید."
}

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$root = Join-Path (Get-Location) (Join-Path $OutputRoot $stamp)
New-Item -ItemType Directory -Path $root -Force | Out-Null
$deviceList = @()
foreach ($line in $deviceLines) {
    $serial = ($line -split "\s+")[0]
    $deviceList += $serial
}
$deviceList | Set-Content -Encoding UTF8 (Join-Path $root "devices.txt")

foreach ($serial in $deviceList) {
    $safeSerial = $serial -replace "[^A-Za-z0-9._-]", "_"
    $folder = Join-Path $root $safeSerial
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    Write-Host "Collecting diagnostics from $serial ..."

    & adb -s $serial shell getprop ro.product.manufacturer 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "manufacturer.txt")
    & adb -s $serial shell getprop ro.product.model 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "model.txt")
    & adb -s $serial shell getprop ro.build.version.release 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "android-version.txt")
    & adb -s $serial shell getprop ro.build.version.sdk 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "android-api.txt")
    & adb -s $serial shell dumpsys package ir.hamrahnet 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "package.txt")
    & adb -s $serial shell dumpsys connectivity 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "connectivity.txt")
    & adb -s $serial shell ip addr show 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "interfaces.txt")
    & adb -s $serial shell dumpsys deviceidle 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "device-idle.txt")
    & adb -s $serial shell dumpsys power 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "power.txt")
    & adb -s $serial shell dumpsys activity services ir.hamrahnet 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "services.txt")
    & adb -s $serial logcat -d -v threadtime "HamrahNetPairing:V" "HamrahNetService:V" "HamrahNetNSD:V" "AndroidRuntime:E" "*:S" 2>&1 | Set-Content -Encoding UTF8 (Join-Path $folder "hamrahnet-logcat.txt")
}

@"
HamrahNet VPN diagnostic bundle
Created: $(Get-Date -Format o)
Devices: $($deviceList -join ', ')

IMPORTANT: This bundle can contain VPN/LAN IP addresses, device model details, account names, and identity fingerprints. Review and redact sensitive values before sharing it.

Suggested capture sequence:
1. Run this script while both phones are connected by USB and HamrahNet is running.
2. Reproduce the issue (especially screen-off or VPN reconnect).
3. Run the script again to create a second bundle, then compare connectivity.txt, device-idle.txt, services.txt, and hamrahnet-logcat.txt.
"@ | Set-Content -Encoding UTF8 (Join-Path $root "README-FA.txt")

Write-Host "Diagnostics saved to: $root"
Write-Host "Review and redact IP addresses, usernames, and fingerprints before sharing the folder."
